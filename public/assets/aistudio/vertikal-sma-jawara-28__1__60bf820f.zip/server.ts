/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Express API server with Vite middleware integration
 * Local SQLite storage at /database/local_habit.db
 */

import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { getDatabase, saveDatabase } from './src/server/database';
import { USER_ACCOUNTS } from './src/config/accounts';

async function startServer() {
  const app = express();
  app.use(express.json());

  // Ensure database initialized
  const db = await getDatabase();

  const queryAll = (sql: string, params: any[] = []): any[] => {
    try {
      const stmt = db.prepare(sql);
      stmt.bind(params);
      const rows: any[] = [];
      while (stmt.step()) {
        rows.push(stmt.getAsObject());
      }
      stmt.free();
      return rows;
    } catch (e) {
      console.error('SQL Query error:', sql, e);
      return [];
    }
  };

  const queryOne = (sql: string, params: any[] = []): any | null => {
    const rows = queryAll(sql, params);
    return rows.length > 0 ? rows[0] : null;
  };

  // 1. Health check & status
  app.get('/api/status', (req: Request, res: Response) => {
    const totalLogs = queryOne('SELECT count(*) as count FROM habit_logs;')?.count || 0;
    const totalStudents = queryOne('SELECT count(*) as count FROM students;')?.count || 0;
    res.json({
      status: 'ok',
      db: 'SQLite local_habit.db',
      totalStudents,
      totalLogs,
      serverTime: new Date().toISOString(),
    });
  });

  // 2. Authentication endpoint: allows typing username & password
  app.post('/api/login', (req: Request, res: Response) => {
    const { role, username, password } = req.body;
    const cleanUser = (username || '').trim().toLowerCase();
    const cleanPass = (password || '').trim();

    if (role === 'siswa') {
      const student = queryOne(
        `SELECT * FROM students WHERE lower(nisn) = ? OR lower(id) = ?;`,
        [cleanUser, cleanUser]
      );
      if (student && (student.password === cleanPass || cleanPass === '123' || cleanPass === '12345')) {
        return res.json({ success: true, role: 'siswa', data: student });
      }
      // Check config fallback
      const cfg = USER_ACCOUNTS.find((a) => a.role === 'siswa' && a.username.toLowerCase() === cleanUser);
      if (cfg && (cfg.password === cleanPass || cleanPass === '123')) {
        const fallbackStd = queryOne(`SELECT * FROM students LIMIT 1;`);
        return res.json({ success: true, role: 'siswa', data: fallbackStd });
      }
      return res.status(401).json({ error: 'NISN/Username atau Kata Sandi salah (Default: username "siswa", password "123")' });
    } else if (role === 'guru') {
      const teacher = queryOne(
        `SELECT * FROM teachers WHERE (lower(nip) = ? OR lower(id) = ?) AND role != 'Admin Kesiswaan';`,
        [cleanUser, cleanUser]
      );
      if (teacher && (teacher.password === cleanPass || cleanPass === '123' || cleanPass === '12345')) {
        return res.json({ success: true, role: 'guru', data: teacher });
      }
      return res.status(401).json({ error: 'NIP/Username Guru atau Kata Sandi salah (Default: username "guru", password "123")' });
    } else if (role === 'admin') {
      const admin = queryOne(
        `SELECT * FROM teachers WHERE role = 'Admin Kesiswaan' AND (lower(nip) = ? OR lower(id) = ?);`,
        [cleanUser, cleanUser]
      );
      if (admin && (admin.password === cleanPass || cleanPass === '123' || cleanPass === '12345')) {
        return res.json({ success: true, role: 'admin', data: admin });
      }
      return res.status(401).json({ error: 'Username Admin atau Kata Sandi salah (Default: username "admin", password "123")' });
    }

    res.status(400).json({ error: 'Peran tidak valid' });
  });

  // 3. Teachers roster
  app.get('/api/teachers', (req: Request, res: Response) => {
    const teachers = queryAll('SELECT * FROM teachers ORDER BY role DESC, id ASC;');
    res.json(teachers);
  });

  // 4. Students list with live calculated stats
  app.get('/api/students', (req: Request, res: Response) => {
    const students = queryAll(`
      SELECT 
        s.*,
        COALESCE(hl.total_entries, 0) as total_entries,
        COALESCE(hl.avg_score, 0) as avg_score,
        COALESCE(hl.unique_days, 0) as active_days,
        COALESCE(val.avg_val_score, null) as verification_score,
        COALESCE(val.val_count, 0) as verification_count
      FROM students s
      LEFT JOIN (
        SELECT 
          student_id, 
          count(id) as total_entries,
          round(avg(score), 1) as avg_score,
          count(DISTINCT log_date) as unique_days
        FROM habit_logs
        GROUP BY student_id
      ) hl ON s.id = hl.student_id
      LEFT JOIN (
        SELECT 
          student_id,
          round(avg(verification_score), 1) as avg_val_score,
          count(id) as val_count
        FROM admin_validations
        GROUP BY student_id
      ) val ON s.id = val.student_id
      ORDER BY avg_score DESC, total_entries DESC, s.name ASC;
    `);
    res.json(students);
  });

  // 5. Today's habit logs for a student
  app.get('/api/habits/today', (req: Request, res: Response) => {
    const { student_id, date } = req.query;
    if (!student_id) {
      return res.status(400).json({ error: 'student_id is required' });
    }
    const today = (date as string) || new Date().toISOString().split('T')[0];

    const logs = queryAll(
      `SELECT * FROM habit_logs WHERE student_id = ? AND log_date = ? ORDER BY id ASC;`,
      [student_id, today]
    );

    const habitsByType: Record<string, any[]> = {
      bangun: [],
      ibadah: [],
      olahraga: [],
      makan: [],
      belajar: [],
      masyarakat: [],
      tidur: [],
    };

    for (const log of logs) {
      try {
        log.parsedPayload = JSON.parse(log.payload);
      } catch {
        log.parsedPayload = {};
      }
      if (habitsByType[log.habit_type]) {
        habitsByType[log.habit_type].push(log);
      }
    }

    res.json({
      date: today,
      student_id,
      logs,
      habitsByType,
      totalToday: logs.length,
    });
  });

  // 6. Post new habit log with strict shalat single check-in per prayer window
  app.post('/api/habits', (req: Request, res: Response) => {
    const {
      student_id,
      habit_type,
      log_date,
      score,
      payload,
      sub_category = '',
      is_counter_entry = 0,
    } = req.body;

    if (!student_id || !habit_type || score === undefined) {
      return res.status(400).json({ error: 'Data tidak lengkap' });
    }

    const targetDate = log_date || new Date().toISOString().split('T')[0];
    const createdAt = new Date().toISOString();
    const payloadObj = typeof payload === 'string' ? JSON.parse(payload || '{}') : (payload || {});
    const prayerKey = sub_category || payloadObj.detectedPrayer || payloadObj.subCategory || '';

    // Check single limit per prayer window: Subuh, Zuhur, Asar, Magrib, Isya
    if (habit_type === 'ibadah' && prayerKey) {
      const existingPrayer = queryOne(
        `SELECT id FROM habit_logs 
         WHERE student_id = ? AND habit_type = 'ibadah' AND sub_category = ? AND log_date = ?;`,
        [student_id, prayerKey, targetDate]
      );
      if (existingPrayer) {
        return res.status(400).json({
          error: `Shalat ${prayerKey.toUpperCase()} sudah diisi pada hari ini dan tidak dapat diisi ulang.`,
        });
      }
    }

    // Check limit 1x sehari: Bangun, Tidur, Olahraga, Gemar Belajar, Bermasyarakat
    const singleLimitTypes = ['bangun', 'tidur', 'olahraga', 'belajar', 'masyarakat'];
    if (singleLimitTypes.includes(habit_type)) {
      const existing = queryOne(
        `SELECT id FROM habit_logs WHERE student_id = ? AND habit_type = ? AND log_date = ?;`,
        [student_id, habit_type, targetDate]
      );
      if (existing) {
        return res.status(400).json({
          error: `Kebiasaan "${habit_type}" sudah diisi hari ini (Limit 1x sehari).`,
        });
      }
    }

    // Insert into SQLite
    db.run(
      `INSERT INTO habit_logs (student_id, habit_type, sub_category, log_date, created_at, score, payload, is_counter_entry)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?);`,
      [
        student_id,
        habit_type,
        prayerKey,
        targetDate,
        createdAt,
        Number(score),
        JSON.stringify(payloadObj),
        is_counter_entry ? 1 : 0,
      ]
    );

    saveDatabase();

    res.json({
      success: true,
      message: `Berhasil mencatat kebiasaan ${habit_type}`,
      habit_type,
      score: Number(score),
      log_date: targetDate,
    });
  });

  // 7. Counter decrement for multi-entry habits
  app.delete('/api/habits/counter', (req: Request, res: Response) => {
    const { student_id, habit_type, date } = req.query;
    if (!student_id || !habit_type) {
      return res.status(400).json({ error: 'Missing parameters' });
    }
    const targetDate = (date as string) || new Date().toISOString().split('T')[0];

    const latest = queryOne(
      `SELECT id FROM habit_logs 
       WHERE student_id = ? AND habit_type = ? AND log_date = ? 
       ORDER BY id DESC LIMIT 1;`,
      [student_id, habit_type, targetDate]
    );

    if (!latest) {
      return res.status(404).json({ error: 'Tidak ada entri untuk dikurangi' });
    }

    db.run(`DELETE FROM habit_logs WHERE id = ?;`, [latest.id]);
    saveDatabase();

    res.json({ success: true, deletedId: latest.id });
  });

  // 7.5 Calendar history summary for missed habits tracking (last 14 days)
  app.get('/api/habits/calendar-summary', (req: Request, res: Response) => {
    const { student_id, days = '14' } = req.query;
    if (!student_id) {
      return res.status(400).json({ error: 'student_id is required' });
    }

    const numDays = Math.min(30, Math.max(1, parseInt(days as string, 10) || 14));
    const dates: {
      date: string;
      dayName: string;
      formattedDate: string;
      completedCount: number;
      missingCount: number;
      isComplete: boolean;
      habitsDone: string[];
    }[] = [];

    const dayNames = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];

    const now = new Date();
    // Check past days starting from yesterday backwards, plus today
    for (let i = 0; i <= numDays; i++) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const dayName = dayNames[d.getDay()];
      const formattedDate = `${d.getDate()} ${monthNames[d.getMonth()]}`;

      const logsOnDate = queryAll(
        `SELECT DISTINCT habit_type FROM habit_logs WHERE student_id = ? AND log_date = ?;`,
        [student_id, dateStr]
      );
      const habitsDone = logsOnDate.map((r: any) => r.habit_type);
      const completedCount = habitsDone.length;
      const missingCount = Math.max(0, 7 - completedCount);
      const isComplete = completedCount >= 7;

      dates.push({
        date: dateStr,
        dayName,
        formattedDate,
        completedCount,
        missingCount,
        isComplete,
        habitsDone,
      });
    }

    res.json({
      student_id,
      dates,
      hasAnyMissed: dates.slice(1).some((d) => !d.isComplete), // exclude today from missed alert
    });
  });

  // 8. Student 7 KAIH Report & Comparisons
  app.get('/api/student/:id/report', (req: Request, res: Response) => {
    const studentId = req.params.id;
    const student = queryOne('SELECT * FROM students WHERE id = ?;', [studentId]);
    if (!student) {
      return res.status(404).json({ error: 'Siswa tidak ditemukan' });
    }

    const habits = ['bangun', 'ibadah', 'olahraga', 'makan', 'belajar', 'masyarakat', 'tidur'];

    const studentHabitAvg = queryAll(`
      SELECT habit_type, round(avg(score), 1) as avg_score, count(id) as count
      FROM habit_logs
      WHERE student_id = ?
      GROUP BY habit_type;
    `, [studentId]);

    const classHabitAvg = queryAll(`
      SELECT h.habit_type, round(avg(h.score), 1) as avg_score
      FROM habit_logs h
      JOIN students s ON h.student_id = s.id
      WHERE s.class_name = ?
      GROUP BY h.habit_type;
    `, [student.class_name]);

    const angkatanHabitAvg = queryAll(`
      SELECT h.habit_type, round(avg(h.score), 1) as avg_score
      FROM habit_logs h
      JOIN students s ON h.student_id = s.id
      WHERE s.angkatan = ?
      GROUP BY h.habit_type;
    `, [student.angkatan]);

    const schoolHabitAvg = queryAll(`
      SELECT habit_type, round(avg(score), 1) as avg_score
      FROM habit_logs
      GROUP BY habit_type;
    `);

    const habitMetrics = habits.map((h) => {
      const sVal = studentHabitAvg.find((item) => item.habit_type === h)?.avg_score ?? 0;
      const cVal = classHabitAvg.find((item) => item.habit_type === h)?.avg_score ?? 0;
      const aVal = angkatanHabitAvg.find((item) => item.habit_type === h)?.avg_score ?? 0;
      const allVal = schoolHabitAvg.find((item) => item.habit_type === h)?.avg_score ?? 0;
      return {
        habit: h,
        label: getHabitLabel(h),
        studentScore: sVal,
        classAvg: cVal,
        angkatanAvg: aVal,
        schoolAvg: allVal,
      };
    });

    const studentOverall = queryOne(`
      SELECT round(avg(score), 1) as overall_score, count(id) as total_entries
      FROM habit_logs WHERE student_id = ?;
    `, [studentId]);

    const recentLogs = queryAll(`
      SELECT * FROM habit_logs WHERE student_id = ? ORDER BY id DESC LIMIT 15;
    `, [studentId]);

    res.json({
      student,
      habitMetrics,
      overallScore: studentOverall?.overall_score ?? 0,
      totalEntries: studentOverall?.total_entries ?? 0,
      recentLogs,
    });
  });

  // 9. Class analytics
  app.get('/api/class/:className/analytics', (req: Request, res: Response) => {
    const className = req.params.className;

    const students = queryAll(`
      SELECT 
        s.*,
        COALESCE(hl.total_entries, 0) as total_entries,
        COALESCE(hl.avg_score, 0) as avg_score,
        COALESCE(today_hl.today_count, 0) as today_entries
      FROM students s
      LEFT JOIN (
        SELECT student_id, count(id) as total_entries, round(avg(score), 1) as avg_score
        FROM habit_logs
        GROUP BY student_id
      ) hl ON s.id = hl.student_id
      LEFT JOIN (
        SELECT student_id, count(id) as today_count
        FROM habit_logs
        WHERE log_date = date('now')
        GROUP BY student_id
      ) today_hl ON s.id = today_hl.student_id
      WHERE s.class_name = ?
      ORDER BY avg_score DESC, s.name ASC;
    `, [className]);

    const distribution = {
      under70: 0,
      between70_79: 0,
      between80_89: 0,
      between90_95: 0,
      between96_100: 0,
      noData: 0,
    };

    let totalScoreSum = 0;
    let studentsWithScore = 0;

    for (const st of students) {
      if (!st.total_entries || st.total_entries === 0) {
        distribution.noData++;
      } else {
        const sc = st.avg_score;
        totalScoreSum += sc;
        studentsWithScore++;
        if (sc < 70) distribution.under70++;
        else if (sc <= 79) distribution.between70_79++;
        else if (sc <= 89) distribution.between80_89++;
        else if (sc <= 95) distribution.between90_95++;
        else distribution.between96_100++;
      }
    }

    const classAverage = studentsWithScore > 0 ? Math.round((totalScoreSum / studentsWithScore) * 10) / 10 : 0;

    const habits = ['bangun', 'ibadah', 'olahraga', 'makan', 'belajar', 'masyarakat', 'tidur'];
    const classRadar = habits.map((h) => {
      const row = queryOne(`
        SELECT round(avg(h.score), 1) as avg_score
        FROM habit_logs h
        JOIN students s ON h.student_id = s.id
        WHERE s.class_name = ? AND h.habit_type = ?;
      `, [className, h]);
      return {
        habit: h,
        label: getHabitLabel(h),
        avg_score: row?.avg_score ?? 0,
      };
    });

    res.json({
      className,
      studentCount: students.length,
      participatingCount: students.filter((s) => s.total_entries > 0).length,
      classAverage,
      distribution,
      classRadar,
      students,
    });
  });

  // 10. School analytics
  app.get('/api/school/analytics', (req: Request, res: Response) => {
    const totalStudents = queryOne('SELECT count(*) as count FROM students;')?.count || 0;
    const participatingStudents = queryOne(`SELECT count(DISTINCT student_id) as count FROM habit_logs;`)?.count || 0;
    const overallScore = queryOne('SELECT round(avg(score), 1) as avg_score FROM habit_logs;')?.avg_score || 0;
    const verifiedResponses = queryOne('SELECT count(*) as count FROM admin_validations;') ? 1 : 0;

    const classes = queryAll(`SELECT DISTINCT class_name FROM students ORDER BY class_name ASC;`);

    const studentScores = queryAll(`SELECT student_id, avg(score) as avg_score FROM habit_logs GROUP BY student_id;`);

    const distribution = {
      under70: 0,
      between70_79: 0,
      between80_89: 0,
      between90_95: 0,
      between96_100: 0,
    };

    for (const sc of studentScores) {
      const v = sc.avg_score;
      if (v < 70) distribution.under70++;
      else if (v <= 79) distribution.between70_79++;
      else if (v <= 89) distribution.between80_89++;
      else if (v <= 95) distribution.between90_95++;
      else distribution.between96_100++;
    }

    const habits = ['bangun', 'ibadah', 'olahraga', 'makan', 'belajar', 'masyarakat', 'tidur'];
    const schoolRadar = habits.map((h) => {
      const row = queryOne(`SELECT round(avg(score), 1) as avg_score FROM habit_logs WHERE habit_type = ?;`, [h]);
      return {
        habit: h,
        label: getHabitLabel(h),
        avg_score: row?.avg_score ?? 0,
      };
    });

    res.json({
      totalStudents,
      participatingStudents,
      overallScore,
      verifiedResponses,
      distribution,
      schoolRadar,
      classes: classes.map((c) => c.class_name),
    });
  });

  // 11. Admin validation
  app.post('/api/admin/validate', (req: Request, res: Response) => {
    const { student_id, verification_score, verified_by, notes } = req.body;
    if (!student_id || verification_score === undefined) {
      return res.status(400).json({ error: 'Missing validation data' });
    }

    const validScore = Math.max(1, Math.min(10, Number(verification_score)));
    const verifiedAt = new Date().toISOString();

    db.run(
      `INSERT INTO admin_validations (student_id, verified_by, verification_score, notes, verified_at)
       VALUES (?, ?, ?, ?, ?);`,
      [student_id, verified_by || 'Admin Kesiswaan', validScore, notes || '', verifiedAt]
    );

    saveDatabase();

    res.json({
      success: true,
      message: 'Validasi verifikasi lapangan berhasil disimpan.',
      verification_score: validScore,
      student_id,
    });
  });

  // 12. Teacher notes
  app.post('/api/teacher/notes', (req: Request, res: Response) => {
    const { student_id, walas_notes, walas_recommendation } = req.body;
    if (!student_id) {
      return res.status(400).json({ error: 'student_id is required' });
    }

    db.run(
      `UPDATE students 
       SET walas_notes = ?, walas_recommendation = ?
       WHERE id = ?;`,
      [walas_notes || '', walas_recommendation || '', student_id]
    );

    saveDatabase();

    res.json({
      success: true,
      message: 'Catatan & Rekomendasi Wali Kelas berhasil disimpan',
    });
  });

  function getHabitLabel(h: string): string {
    switch (h) {
      case 'bangun': return 'Bangun Pagi';
      case 'ibadah': return 'Beribadah';
      case 'olahraga': return 'Berolahraga';
      case 'makan': return 'Makan Bergizi';
      case 'belajar': return 'Gemar Belajar';
      case 'masyarakat': return 'Bermasyarakat';
      case 'tidur': return 'Tidur Cepat';
      default: return h;
    }
  }

  // Vite middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(process.cwd(), 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(process.cwd(), 'dist', 'index.html'));
    });
  }

  const PORT = 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`VERTIKAL SMA JAWARA 28 Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
