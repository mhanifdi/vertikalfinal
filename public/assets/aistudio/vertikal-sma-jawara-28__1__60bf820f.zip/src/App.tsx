/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Student, Teacher, Role } from './types';
import { api } from './utils/api';
import { PublicDashboard } from './components/public/PublicDashboard';
import { LoginPage } from './components/auth/LoginPage';
import { StudentDashboard } from './components/student/StudentDashboard';
import { TeacherDashboard } from './components/teacher/TeacherDashboard';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { StudentReportModal } from './components/common/StudentReportModal';

type AppView = 'public' | 'login' | 'student' | 'teacher' | 'admin';

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>('login');
  const [students, setStudents] = useState<Student[]>([]);
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [loading, setLoading] = useState(true);

  // Active authenticated user
  const [currentStudent, setCurrentStudent] = useState<Student | null>(null);
  const [currentTeacher, setCurrentTeacher] = useState<Teacher | null>(null);
  const [currentAdmin, setCurrentAdmin] = useState<Teacher | null>(null);

  // Global report modal (can be opened from any view)
  const [openedReportStudentId, setOpenedReportStudentId] = useState<string | null>(null);

  const loadData = async () => {
    try {
      const [stList, tchList] = await Promise.all([
        api.getStudents(),
        api.getTeachers(),
      ]);
      setStudents(stList);
      setTeachers(tchList);
      if (stList.length > 0 && !currentStudent) {
        setCurrentStudent(stList[0]);
      }
      const regTeacher = tchList.find((t) => t.role !== 'Admin Kesiswaan');
      if (regTeacher && !currentTeacher) {
        setCurrentTeacher(regTeacher);
      }
      const adm = tchList.find((t) => t.role === 'Admin Kesiswaan');
      if (adm && !currentAdmin) {
        setCurrentAdmin(adm);
      }
    } catch (e) {
      console.error('Failed to load initial school data:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleStudentLogin = (s: Student) => {
    setCurrentStudent(s);
    setCurrentView('student');
  };

  const handleTeacherLogin = (t: Teacher) => {
    setCurrentTeacher(t);
    setCurrentView('teacher');
  };

  const handleAdminLogin = (a: Teacher) => {
    setCurrentAdmin(a);
    setCurrentView('admin');
  };

  const handleLogout = () => {
    setCurrentView('login');
    loadData();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-kebaya-pattern flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-xl text-center space-y-4 max-w-sm w-full">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#1c5ddc] to-[#0000fe] text-white flex items-center justify-center font-black text-xl mx-auto shadow-md">
            28
          </div>
          <div>
            <h2 className="text-lg font-black text-slate-900 tracking-tight">
              VERTIKAL SMA JAWARA 28
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-1">
              Memuat database lokal SQLite (/database/local_habit.db)...
            </p>
          </div>
          <div className="w-6 h-6 border-2 border-[#1c5ddc] border-t-transparent rounded-full animate-spin mx-auto" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {currentView === 'public' && (
        <PublicDashboard
          students={students}
          onGoToLogin={() => setCurrentView('login')}
          onOpenReport={(id) => setOpenedReportStudentId(id)}
        />
      )}

      {currentView === 'login' && (
        <LoginPage
          students={students}
          teachers={teachers}
          onLoginStudent={handleStudentLogin}
          onLoginTeacher={handleTeacherLogin}
          onLoginAdmin={handleAdminLogin}
          onBackToPublic={() => setCurrentView('public')}
        />
      )}

      {currentView === 'student' && currentStudent && (
        <StudentDashboard
          student={currentStudent}
          allStudents={students}
          onLogout={handleLogout}
          onOpenReport={(id) => setOpenedReportStudentId(id)}
        />
      )}

      {currentView === 'teacher' && currentTeacher && (
        <TeacherDashboard
          teacher={currentTeacher}
          allStudents={students}
          onLogout={handleLogout}
        />
      )}

      {currentView === 'admin' && currentAdmin && (
        <AdminDashboard
          admin={currentAdmin}
          allStudents={students}
          onLogout={handleLogout}
          onRefreshStudents={loadData}
        />
      )}

      {/* Global Student Report Inspection Modal */}
      {openedReportStudentId && (
        <StudentReportModal
          studentId={openedReportStudentId}
          canEditNotes={currentView === 'teacher' || currentView === 'admin'}
          onClose={() => {
            setOpenedReportStudentId(null);
            loadData();
          }}
        />
      )}
    </div>
  );
}
