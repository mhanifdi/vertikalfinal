/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Role = 'siswa' | 'guru' | 'admin';

export interface Student {
  id: string;
  nisn: string;
  name: string;
  gender: 'L' | 'P';
  class_name: string;
  angkatan: string;
  religion: 'Islam' | 'Kristen' | 'Katolik' | 'Hindu';
  avatar_seed?: string;
  walas_name: string;
  walas_nip: string;
  walas_notes: string;
  walas_recommendation: string;
  total_entries?: number;
  avg_score?: number;
  active_days?: number;
  verification_score?: number | null;
  verification_count?: number;
}

export interface Teacher {
  id: string;
  nip: string;
  name: string;
  class_name: string;
  subject: string;
  role: string;
}

export interface HabitLog {
  id: number;
  student_id: string;
  habit_type: 'bangun' | 'ibadah' | 'olahraga' | 'makan' | 'belajar' | 'masyarakat' | 'tidur';
  log_date: string;
  created_at: string;
  score: number;
  payload: string;
  is_counter_entry: number;
  parsedPayload?: any;
}

export interface HabitMetricComparison {
  habit: string;
  label: string;
  studentScore: number;
  classAvg: number;
  angkatanAvg: number;
  schoolAvg: number;
}

export interface ClassAnalytics {
  className: string;
  studentCount: number;
  participatingCount: number;
  classAverage: number;
  distribution: {
    under70: number;
    between70_79: number;
    between80_89: number;
    between90_95: number;
    between96_100: number;
    noData: number;
  };
  classRadar: {
    habit: string;
    label: string;
    avg_score: number;
  }[];
  students: (Student & { today_entries?: number })[];
}

export interface SchoolAnalytics {
  totalStudents: number;
  participatingStudents: number;
  overallScore: number;
  verifiedResponses: number;
  distribution: {
    under70: number;
    between70_79: number;
    between80_89: number;
    between90_95: number;
    between96_100: number;
  };
  schoolRadar: {
    habit: string;
    label: string;
    avg_score: number;
  }[];
  classes: string[];
}
