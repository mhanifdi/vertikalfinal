/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * VERTIKAL SMA JAWARA 28
 * Rumus Penilaian 7 Kebiasaan Anak Indonesia Hebat (7 KAIH)
 * Sesuai skema penilaian terbaru SMAN 28 Jakarta
 */

import { PRAYER_SCHEDULE, SCORING_RULES } from '../config/scoringConfig';
import { timeToMinutes } from './timeClassifier';

// ============================================================================
// 1. BANGUN PAGI
// ============================================================================
export interface BangunPagiInput {
  timeStr?: string; // e.g. "04:15"
  timeSlot?: string; // e.g. "04.00-04.20"
  isMissed?: boolean;
}

export function classifyBangunPagiTime(timeStr: string): { slotId: string; score: number; label: string } {
  let min = timeToMinutes(timeStr);
  // Jam bangun pagi: jika sebelum jam 04.00 (misal 03.45), beri nilai sempurna 100
  if (min < 240) {
    return { slotId: '04.00-04.20', score: 100, label: '04.00 – 04.20 WIB (Sangat Awal)' };
  }
  for (const b of SCORING_RULES.bangunPagi.brackets) {
    if (min >= b.minMin && min <= b.maxMin) {
      return { slotId: b.id, score: b.score, label: b.label };
    }
  }
  return { slotId: '>06.40', score: 50, label: '> 06.40 WIB' };
}

export function calculateBangunPagiScore(input: BangunPagiInput): number {
  let baseScore = 50;
  if (input.timeStr) {
    baseScore = classifyBangunPagiTime(input.timeStr).score;
  } else if (input.timeSlot) {
    const found = SCORING_RULES.bangunPagi.brackets.find((b) => b.id === input.timeSlot);
    if (found) baseScore = found.score;
  }
  if (input.isMissed) {
    baseScore = Math.max(0, baseScore - SCORING_RULES.bangunPagi.missedPenalty);
  }
  return baseScore;
}

// ============================================================================
// 2. BERIBADAH (ISLAM, KRISTEN/KATOLIK, HINDU)
// ============================================================================
export interface ShalatDetailResult {
  score: number;
  menitLewat: number;
  waktuSisa: number;
  waktuToleransi: number;
  selangTotal: number;
  formulaText: string;
}

/**
 * Hitung skor sholat:
 * Waktu toleransi = waktu selang total dr azan ke shalat berikutnya - 15 menit
 * Skor = waktu sisa / waktu toleransi * 100
 * Cap terendah 50, tidak isi = 0
 */
export function calculateShalatScoreDetailed(
  prayerKey: 'subuh' | 'zuhur' | 'asar' | 'magrib' | 'isya',
  checkInTimeStr: string,
  isMissed = false
): ShalatDetailResult {
  const sched = PRAYER_SCHEDULE[prayerKey];
  const adzanMin = timeToMinutes(sched.adzanTime);
  let checkInMin = timeToMinutes(checkInTimeStr);

  // Handle Isya melewati tengah malam
  if (prayerKey === 'isya' && checkInMin < 240) {
    checkInMin += 1440;
  }

  const selangTotal = sched.totalMinutes;
  // T total = selang adzan ke shalat berikutnya - 15 menit toleransi
  const waktuToleransi = Math.max(1, selangTotal - SCORING_RULES.shalat.toleranceDeductionMinutes);

  // Waktu sisa = sisa menit dari waktu check in hingga akhir waktu shalat
  const akhirShalatMin = adzanMin + selangTotal;
  const menitLewat = Math.max(0, checkInMin - adzanMin);
  const waktuSisa = Math.max(0, akhirShalatMin - checkInMin);

  // Rumus: (Tsisa / Ttotal) * 100
  // Jika check in di awal (misal Tsisa 89, Ttotal 85), skor >= 100 dan dicap tetap 100!
  const rawScore = (waktuSisa / waktuToleransi) * 100;
  let clampedScore = Math.min(
    SCORING_RULES.shalat.maxScore,
    Math.max(SCORING_RULES.shalat.minCapScore, Math.round(rawScore * 10) / 10)
  );

  if (isMissed) {
    clampedScore = Math.max(45, clampedScore - SCORING_RULES.shalat.missedPenalty);
  }

  const formulaText = `(Sisa ${waktuSisa}m / Toleransi ${waktuToleransi}m) × 100 = ${rawScore.toFixed(1)} pt (Cap maks 100 pt, min 50 pt)${isMissed ? ' [-5 penalti terlewat]' : ''}`;

  return {
    score: clampedScore,
    menitLewat,
    waktuSisa,
    waktuToleransi,
    selangTotal,
    formulaText,
  };
}

export interface IslamIbadahInput {
  isHalangan?: boolean;
  prayersDone?: ('subuh' | 'zuhur' | 'asar' | 'magrib' | 'isya')[];
  prayerScores?: Record<string, number>;
  quranPages?: number;
  surahName?: string;
  isMissed?: boolean;
}

export function calculateIslamScore(input: IslamIbadahInput): number {
  if (input.isHalangan) {
    return 100;
  }

  const prayers = ['subuh', 'zuhur', 'asar', 'magrib', 'isya'] as const;
  const scores: number[] = [];

  for (const p of prayers) {
    if (input.prayersDone?.includes(p)) {
      const sc = input.prayerScores?.[p] !== undefined ? input.prayerScores[p] : 100;
      scores.push(Math.max(45, Math.min(100, sc)));
    } else {
      scores.push(0);
    }
  }

  // Rata-rata 5 shalat (jika 0 tetap dihitung pembagi 5 jika hari itu tuntas atau parsial)
  const completedPrayers = scores.filter((s) => s > 0);
  const avgPrayer = completedPrayers.length > 0
    ? scores.reduce((a, b) => a + b, 0) / 5
    : 0;

  // Mengaji/Murajaah: Additional Poin +1 / halaman
  const quranBonus = Math.max(0, (input.quranPages || 0) * SCORING_RULES.shalat.quranPageBonus);

  if (avgPrayer === 0 && quranBonus === 0) {
    return 0;
  }

  let total = Math.min(100, Math.round((avgPrayer + quranBonus) * 10) / 10);
  if (input.isMissed) {
    total = Math.max(0, total - SCORING_RULES.shalat.missedPenalty);
  }
  return total;
}

export interface KristenIbadahInput {
  prayers: ('bangun' | 'makan' | 'pergi' | 'pulang' | 'tidur')[];
  prayerNotes?: Record<string, string>;
  otherWorship?: boolean;
  notes?: string;
  isMissed?: boolean;
}

export function calculateKristenScore(input: KristenIbadahInput): number {
  const prayerScore = (input.prayers || []).length * 20; // 5 x 20 = 100
  const bonus = input.otherWorship ? 3 : 0;
  let total = Math.min(100, prayerScore + bonus);
  if (input.isMissed) {
    total = Math.max(0, total - 5);
  }
  return total;
}

export interface HinduIbadahInput {
  triSandhya: ('pagi' | 'siang' | 'sore')[];
  triSandhyaNotes?: Record<string, string>;
  otherWorship?: boolean;
  notes?: string;
  isMissed?: boolean;
}

export function calculateHinduScore(input: HinduIbadahInput): number {
  const count = (input.triSandhya || []).length;
  let sandhyaScore = 0;
  if (count === 1) sandhyaScore = 33.3;
  else if (count === 2) sandhyaScore = 66.6;
  else if (count >= 3) sandhyaScore = 100;

  const bonus = input.otherWorship ? 3 : 0;
  let total = Math.min(100, Math.round((sandhyaScore + bonus) * 10) / 10);
  if (input.isMissed) {
    total = Math.max(0, total - 5);
  }
  return total;
}

// ============================================================================
// 3. BEROLAHRAGA
// ============================================================================
export interface OlahragaInput {
  duration: '<15' | '15-30' | '31-60' | '>60';
  activities: string[];
  notes?: string;
  isMissed?: boolean;
}

export function calculateOlahragaScore(input: OlahragaInput): number {
  if (!input.activities || input.activities.length === 0) {
    return 0;
  }

  // Aktivitas Poin
  let actScore = 0;
  input.activities.forEach((act) => {
    if (act === 'mandiri') actScore += SCORING_RULES.olahraga.actMandiri; // 10
    else if (act === 'kelompok') actScore += SCORING_RULES.olahraga.actKelompok; // 10
    else if (act === 'jalanTangga') actScore += SCORING_RULES.olahraga.actJalanTangga; // 10
    else if (act === 'stretching') actScore += SCORING_RULES.olahraga.actStretching; // 10
    else if (act === 'sepedaJalanSekolah') actScore += SCORING_RULES.olahraga.actKeSekolahEco; // 10
  });

  // Durasi Poin
  let durScore = 0;
  switch (input.duration) {
    case '<15':
      durScore = SCORING_RULES.olahraga.durLess15; // 25
      break;
    case '15-30':
      durScore = SCORING_RULES.olahraga.dur15to30; // 35
      break;
    case '31-60':
      durScore = SCORING_RULES.olahraga.dur31to60; // 45
      break;
    case '>60':
      durScore = SCORING_RULES.olahraga.durOver60; // 60
      break;
  }

  let total = Math.min(100, actScore + durScore);
  if (input.isMissed) {
    total = Math.max(0, total - SCORING_RULES.olahraga.missedPenalty);
  }
  return total;
}

// ============================================================================
// 4. MAKAN BERGIZI
// ============================================================================
export interface MakanSingleMealInput {
  mealType: 'sarapan' | 'siang' | 'malam';
  timeStr?: string;
  isPuasa?: boolean;
  hasKarbo?: boolean;
  hasLauk?: boolean;
  hasSayur?: boolean;
  hasBuah?: boolean;
  waterGlasses?: '>=2' | '1' | '0_manis';
  kotakMakanEco?: boolean;
  tumblerEco?: boolean;
  isMissed?: boolean;
}

export function calculateSingleMealScore(input: MakanSingleMealInput): number {
  if (input.isPuasa) {
    // Puasa: jika mengisi sahur/berbuka dengan gizi lengkap
    let gizi = 0;
    if (input.hasKarbo) gizi += 10;
    if (input.hasLauk) gizi += 10;
    if (input.hasSayur) gizi += 10;
    if (input.hasBuah) gizi += 10;
    const air = input.waterGlasses === '>=2' ? 15 : input.waterGlasses === '1' ? 5 : 0;
    const eco = (input.kotakMakanEco ? 5 : 0) + (input.tumblerEco ? 5 : 0);
    const raw = 15 + gizi + air + eco; // 15 ketepatan + 40 gizi + 15 air + 10 eco = 80
    const scaled = Math.min(100, Math.round((raw / 80) * 100));
    return input.isMissed ? Math.max(0, scaled - 5) : scaled;
  }

  // Ketepatan Waktu:
  // Sarapan: 06.00 - 08.00 = 15, > 08.00 = 5
  // Siang: 11.30 - 13.00 = 15, > 13.00 = 5
  // Malam: 18.00 - 19.30 = 15, > 19.30 = 5
  let timeScore = 5;
  if (input.timeStr) {
    const min = timeToMinutes(input.timeStr);
    if (input.mealType === 'sarapan') {
      timeScore = min >= 360 && min <= 480 ? 15 : 5;
    } else if (input.mealType === 'siang') {
      timeScore = min >= 690 && min <= 780 ? 15 : 5;
    } else if (input.mealType === 'malam') {
      timeScore = min >= 1080 && min <= 1170 ? 15 : 5;
    }
  } else {
    timeScore = 15; // default on-time jika tidak ada timestamp spesifik
  }

  // Isi Piringku (Max 40)
  let giziScore = 0;
  if (input.hasKarbo) giziScore += SCORING_RULES.makan.karbo;
  if (input.hasLauk) giziScore += SCORING_RULES.makan.lauk;
  if (input.hasSayur) giziScore += SCORING_RULES.makan.sayur;
  if (input.hasBuah) giziScore += SCORING_RULES.makan.buah;

  // Air Minum (Max 15)
  let waterScore = 0;
  if (input.waterGlasses === '>=2') waterScore = SCORING_RULES.makan.air2Gelas;
  else if (input.waterGlasses === '1') waterScore = SCORING_RULES.makan.air1Gelas;
  else waterScore = SCORING_RULES.makan.air0Gelas;

  // Eco-Friendly (Max 10)
  let ecoScore = 0;
  if (input.kotakMakanEco) ecoScore += SCORING_RULES.makan.kotakMakanEco;
  if (input.tumblerEco) ecoScore += SCORING_RULES.makan.tumblerEco;

  const rawTotal = timeScore + giziScore + waterScore + ecoScore; // Max 15 + 40 + 15 + 10 = 80
  let finalScore = Math.min(100, Math.round((rawTotal / 80) * 100));

  if (input.isMissed) {
    finalScore = Math.max(0, finalScore - SCORING_RULES.makan.missedPenalty);
  }
  return finalScore;
}

export interface MakanDailySummaryInput {
  sarapan?: MakanSingleMealInput;
  siang?: MakanSingleMealInput;
  malam?: MakanSingleMealInput;
  isPuasa?: boolean;
}

export function calculateMakanDailyScore(input: MakanDailySummaryInput): number {
  if (input.isPuasa) {
    const sScore = input.sarapan ? calculateSingleMealScore(input.sarapan) : 100;
    const mScore = input.malam ? calculateSingleMealScore(input.malam) : 100;
    return Math.round((sScore + mScore) / 2);
  }

  const sScore = input.sarapan ? calculateSingleMealScore(input.sarapan) : 0;
  const lScore = input.siang ? calculateSingleMealScore(input.siang) : 0;
  const dScore = input.malam ? calculateSingleMealScore(input.malam) : 0;

  // Rata-rata 3 sesi makan (sarapan, makan siang, makan malam)
  // Sesuai instruksi: jika belum isi atau 0, tetap dirata-ratakan dari 3!
  return Math.round(((sScore + lScore + dScore) / 3) * 10) / 10;
}

// ============================================================================
// 5. GEMAR BELAJAR
// ============================================================================
export interface GemarBelajarInput {
  duration: '0' | '<15' | '15-30' | '30-60' | '1-2h' | '2-3h' | '>3h';
  activities: string[];
  outputDescription?: string;
  isMissed?: boolean;
}

export function calculateGemarBelajarScore(input: GemarBelajarInput): number {
  // 1. Durasi Mandiri (Max 60)
  let durScore = 0;
  switch (input.duration) {
    case '>3h':
      durScore = SCORING_RULES.belajar.durOver3h; // 60
      break;
    case '2-3h':
      durScore = SCORING_RULES.belajar.dur2to3h; // 50
      break;
    case '1-2h':
      durScore = SCORING_RULES.belajar.dur1to2h; // 40
      break;
    case '30-60':
      durScore = SCORING_RULES.belajar.dur30to60m; // 30
      break;
    case '15-30':
      durScore = SCORING_RULES.belajar.dur15to30m; // 20
      break;
    case '<15':
      durScore = SCORING_RULES.belajar.durLess15m; // 10
      break;
    default:
      durScore = SCORING_RULES.belajar.dur0m; // 0
      break;
  }

  // 2. Bentuk Kegiatan (Max 30)
  const actCount = (input.activities || []).length;
  let actScore = 0;
  if (actCount >= 3) actScore = SCORING_RULES.belajar.act3OrMore; // 30
  else if (actCount === 2) actScore = SCORING_RULES.belajar.act2; // 20
  else if (actCount === 1) actScore = SCORING_RULES.belajar.act1; // 10
  else actScore = 0;

  // 3. Akuntabilitas & Kejelasan Output (Max 10)
  const desc = (input.outputDescription || '').trim();
  let descScore = 0;
  if (desc.length >= 10) {
    descScore = SCORING_RULES.belajar.descDetailed; // 10
  } else if (desc.length > 0) {
    descScore = SCORING_RULES.belajar.descShort; // 5
  } else {
    descScore = SCORING_RULES.belajar.descEmpty; // 0
  }

  if (durScore === 0 && actScore === 0 && descScore === 0) {
    return 0;
  }

  let total = Math.min(100, durScore + actScore + descScore);
  if (input.isMissed) {
    total = Math.max(0, total - SCORING_RULES.belajar.missedPenalty);
  }
  return total;
}

// ============================================================================
// 6. BERMASYARAKAT
// ============================================================================
export interface BermasyarakatInput {
  actions: string[];
  description?: string;
  isMissed?: boolean;
}

export function calculateBermasyarakatScore(input: BermasyarakatInput): number {
  const actCount = (input.actions || []).length;

  // 1. Bentuk Aksi Sosial (Max 90)
  let actScore = 0;
  if (actCount >= 4) actScore = SCORING_RULES.masyarakat.act4OrMore; // 90
  else if (actCount === 3) actScore = SCORING_RULES.masyarakat.act3; // 80
  else if (actCount === 2) actScore = SCORING_RULES.masyarakat.act2; // 70
  else if (actCount === 1) actScore = SCORING_RULES.masyarakat.act1; // 60
  else actScore = 0;

  // Piket / Lingkungan Adiwiyata Bonus (+5)
  if (input.actions && input.actions.includes('piket')) {
    actScore += SCORING_RULES.masyarakat.piketEcoBonus;
  }

  // 2. Kejelasan Deskripsi (Max 10)
  const desc = (input.description || '').trim();
  let descScore = 0;
  if (desc.length >= 10) {
    descScore = SCORING_RULES.masyarakat.descDetailed; // 10
  } else if (desc.length > 0) {
    descScore = SCORING_RULES.masyarakat.descShort; // 5
  } else {
    descScore = SCORING_RULES.masyarakat.descEmpty; // 0
  }

  if (actScore === 0 && descScore === 0) {
    return 0;
  }

  let total = Math.min(100, actScore + descScore);
  if (input.isMissed) {
    total = Math.max(0, total - SCORING_RULES.masyarakat.missedPenalty);
  }
  return total;
}

// ============================================================================
// 7. TIDUR CEPAT
// ============================================================================
export interface TidurCepatInput {
  bedtimeSlot?: '<21.30' | '21.30-22.30' | '22.31-23.30' | '>23.30';
  timeStr?: string;
  turnOffLightsEco?: boolean;
  sleepQuality: number; // 1-5
  reasonOrReport?: string;
  isMissed?: boolean;
}

export function classifyTidurTime(timeStr: string): { slot: '<21.30' | '21.30-22.30' | '22.31-23.30' | '>23.30'; score: number; label: string } {
  const min = timeToMinutes(timeStr);
  // Jam tidur malam: 21.30 = 1290m, 22.30 = 1350m, 23.30 = 1410m
  // Sebelum 21.30 WIB: min < 1290 (atau jika tidur siang/sore dianggap awal)
  if (min < 1290 && min >= 1200) {
    return { slot: '<21.30', score: SCORING_RULES.tidur.before2130, label: 'Sebelum 21.30 WIB' };
  }
  if (min >= 1290 && min <= 1350) {
    return { slot: '21.30-22.30', score: SCORING_RULES.tidur.between2130_2230, label: '21.30 – 22.30 WIB' };
  }
  if (min > 1350 && min <= 1410) {
    return { slot: '22.31-23.30', score: SCORING_RULES.tidur.between2231_2330, label: '22.31 – 23.30 WIB' };
  }
  return { slot: '>23.30', score: SCORING_RULES.tidur.after2330, label: 'Setelah 23.30 WIB' };
}

export function calculateTidurCepatScore(input: TidurCepatInput): number {
  // 1. Ketepatan Waktu Check-In (Max 75)
  let timeScore = SCORING_RULES.tidur.before2130;
  if (input.timeStr) {
    timeScore = classifyTidurTime(input.timeStr).score;
  } else if (input.bedtimeSlot) {
    if (input.bedtimeSlot === '<21.30') timeScore = SCORING_RULES.tidur.before2130;
    else if (input.bedtimeSlot === '21.30-22.30') timeScore = SCORING_RULES.tidur.between2130_2230;
    else if (input.bedtimeSlot === '22.31-23.30') timeScore = SCORING_RULES.tidur.between2231_2330;
    else timeScore = SCORING_RULES.tidur.after2330;
  }

  // 2. Eco-Friendly Matikan Lampu (Max 5)
  const ecoScore = input.turnOffLightsEco ? SCORING_RULES.tidur.matikanLampuEco : 0;

  // 3. Kualitas Tidur & Kesiapan Bangun (Max 25)
  let qualScore = 15;
  switch (input.sleepQuality) {
    case 5:
      qualScore = SCORING_RULES.tidur.quality5; // 25 (Sangat Segar)
      break;
    case 4:
      qualScore = SCORING_RULES.tidur.quality4; // 20 (Segar)
      break;
    case 3:
      qualScore = SCORING_RULES.tidur.quality3; // 15 (Lumayan Segar)
      break;
    case 2:
      qualScore = SCORING_RULES.tidur.quality2; // 10 (Cukup Ngantuk)
      break;
    case 1:
    default:
      qualScore = SCORING_RULES.tidur.quality1; // 5 (Sangat Lemas)
      break;
  }

  let total = Math.min(100, timeScore + ecoScore + qualScore);
  if (input.isMissed) {
    total = Math.max(0, total - SCORING_RULES.tidur.missedPenalty);
  }
  return total;
}
