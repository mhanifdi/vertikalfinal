/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Student, Teacher, HabitLog, HabitMetricComparison, ClassAnalytics, SchoolAnalytics } from '../types';

export const api = {
  async getStatus() {
    const res = await fetch('/api/status');
    return res.json();
  },

  async getTeachers(): Promise<Teacher[]> {
    const res = await fetch('/api/teachers');
    return res.json();
  },

  async getStudents(): Promise<Student[]> {
    const res = await fetch('/api/students');
    return res.json();
  },

  async getStudent(id: string): Promise<Student> {
    const res = await fetch(`/api/students/${id}`);
    return res.json();
  },

  async getTodayHabits(studentId: string, date?: string): Promise<{
    date: string;
    student_id: string;
    logs: HabitLog[];
    habitsByType: Record<string, HabitLog[]>;
    totalToday: number;
  }> {
    const url = `/api/habits/today?student_id=${studentId}${date ? `&date=${date}` : ''}`;
    const res = await fetch(url);
    return res.json();
  },

  async getCalendarSummary(studentId: string, days = 14): Promise<{
    student_id: string;
    hasAnyMissed: boolean;
    dates: {
      date: string;
      dayName: string;
      formattedDate: string;
      completedCount: number;
      missingCount: number;
      isComplete: boolean;
      habitsDone: string[];
    }[];
  }> {
    const res = await fetch(`/api/habits/calendar-summary?student_id=${studentId}&days=${days}`);
    return res.json();
  },

  async submitHabit(data: {
    student_id: string;
    habit_type: string;
    score: number;
    payload: any;
    sub_category?: string;
    is_counter_entry?: number;
    log_date?: string;
  }) {
    const res = await fetch('/api/habits', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Gagal mencatat kebiasaan' }));
      throw new Error(err.error || 'Gagal mencatat');
    }
    return res.json();
  },

  async decrementCounter(studentId: string, habitType: string, date?: string) {
    const url = `/api/habits/counter?student_id=${studentId}&habit_type=${habitType}${date ? `&date=${date}` : ''}`;
    const res = await fetch(url, { method: 'DELETE' });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Gagal mengurangi counter' }));
      throw new Error(err.error || 'Gagal mengurangi');
    }
    return res.json();
  },

  async getStudentReport(id: string): Promise<{
    student: Student;
    habitMetrics: HabitMetricComparison[];
    overallScore: number;
    totalEntries: number;
    recentLogs: HabitLog[];
  }> {
    const res = await fetch(`/api/student/${id}/report`);
    return res.json();
  },

  async getClassAnalytics(className: string): Promise<ClassAnalytics> {
    const res = await fetch(`/api/class/${encodeURIComponent(className)}/analytics`);
    return res.json();
  },

  async getSchoolAnalytics(): Promise<SchoolAnalytics> {
    const res = await fetch('/api/school/analytics');
    return res.json();
  },

  async saveAdminValidation(data: {
    student_id: string;
    verification_score: number;
    verified_by?: string;
    notes?: string;
  }) {
    const res = await fetch('/api/admin/validate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return res.json();
  },

  async saveTeacherNotes(data: {
    student_id: string;
    walas_notes: string;
    walas_recommendation: string;
  }) {
    const res = await fetch('/api/teacher/notes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return res.json();
  },
};
