/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateBangunPagiScore,
  calculateShalatScoreDetailed,
  calculateIslamScore,
  calculateKristenScore,
  calculateHinduScore,
  calculateOlahragaScore,
  calculateSingleMealScore,
  calculateGemarBelajarScore,
  calculateBermasyarakatScore,
  calculateTidurCepatScore,
} from './scoring';

test('Shalat calculation with tolerance (total - 15m) and remaining time', () => {
  // Subuh: 04:00 to 05:30. Selang = 90 min. Toleransi = 90 - 15 = 75 min.
  // Check-in at 04:10 -> lewat 10 min. Waktu Sisa = 80 min.
  // Raw = (80 / 75) * 100 = 106.7 pt -> Cap tetap 100 pt!
  const r1 = calculateShalatScoreDetailed('subuh', '04:10');
  assert.equal(r1.menitLewat, 10);
  assert.equal(r1.waktuSisa, 80);
  assert.equal(r1.score, 100);

  // Check-in at 04:30 -> lewat 30 min. Waktu Sisa = 60 min.
  // Raw = (60 / 75) * 100 = 80 pt
  const r2 = calculateShalatScoreDetailed('subuh', '04:30');
  assert.equal(r2.menitLewat, 30);
  assert.equal(r2.waktuSisa, 60);
  assert.equal(r2.score, 80);

  // Check-in very late (> tolerance) -> capped at lowest 50
  const r3 = calculateShalatScoreDetailed('subuh', '05:25');
  assert.equal(r3.score, 50);

  // Late/missed penalty
  const r4 = calculateShalatScoreDetailed('subuh', '05:25', true);
  assert.equal(r4.score, 45); // 50 - 5
});

test('Bangun Pagi brackets and penalty', () => {
  // 04:15 -> 04.00-04.20 = 100
  assert.equal(calculateBangunPagiScore({ timeStr: '04:15' }), 100);
  // 04:30 -> 04.21-04.40 = 90
  assert.equal(calculateBangunPagiScore({ timeStr: '04:30' }), 90);
  // 05:30 -> 05.01-06.20 = 70
  assert.equal(calculateBangunPagiScore({ timeStr: '05:30' }), 70);
  // Missed penalty -5
  assert.equal(calculateBangunPagiScore({ timeStr: '04:15', isMissed: true }), 95);
});

test('Empty output comment in Gemar Belajar gives 0 pt, NOT 100', () => {
  const s1 = calculateGemarBelajarScore({
    duration: '30-60', // 30
    activities: ['Membaca buku'], // 10
    outputDescription: '', // 0
  });
  assert.equal(s1, 40);

  // With detailed description >= 10 chars (+10 pt)
  const s2 = calculateGemarBelajarScore({
    duration: '30-60', // 30
    activities: ['Membaca buku'], // 10
    outputDescription: 'Mengerjakan soal fisika bab termodinamika', // 10
  });
  assert.equal(s2, 50);
});
