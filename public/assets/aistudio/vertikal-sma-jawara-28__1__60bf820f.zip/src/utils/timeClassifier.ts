/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Auto-classifier based on stamped time for 7 KAIH
 */

export interface TimeClassificationResult {
  detectedTime: string;
  category: string;
  bracket: string;
  score: number;
  description: string;
  isOnTime: boolean;
}

/** Convert "HH:mm" to minutes from midnight */
export function timeToMinutes(timeStr: string): number {
  const parts = timeStr.split(':').map((p) => parseInt(p, 10));
  const hours = isNaN(parts[0]) ? 0 : parts[0];
  const minutes = isNaN(parts[1]) ? 0 : parts[1];
  return hours * 60 + minutes;
}

/** Get current local time string in "HH:mm" format */
export function getCurrentTimeString(): string {
  const now = new Date();
  return now.toTimeString().slice(0, 5); // "HH:mm"
}

/** 1. Bangun Pagi: Panduan baku 04.00 - 06.00 */
export function classifyBangunPagiTime(timeStr: string): TimeClassificationResult {
  const m = timeToMinutes(timeStr);
  // 04:00 = 240, 05:00 = 300, 06:00 = 360
  if (m >= 240 && m <= 300) {
    return {
      detectedTime: timeStr,
      category: 'Bangun Pagi',
      bracket: '04.00-05.00',
      score: 100,
      description: 'Sangat Ideal (Pukul 04.00 – 05.00 WIB)',
      isOnTime: true,
    };
  } else if (m > 300 && m <= 360) {
    return {
      detectedTime: timeStr,
      category: 'Bangun Pagi',
      bracket: '05.00-06.00',
      score: 70,
      description: 'Standar Cukup (Pukul 05.00 – 06.00 WIB)',
      isOnTime: true,
    };
  } else {
    return {
      detectedTime: timeStr,
      category: 'Bangun Pagi',
      bracket: '>06.00',
      score: 50,
      description: m > 360 ? 'Melewati Batas Ideal (> 06.00 WIB)' : 'Sebelum Jam Baku (< 04.00 WIB)',
      isOnTime: false,
    };
  }
}

/** 2. Shalat Islam berdasarkan jendela waktu */
export function classifyShalatTime(timeStr: string): {
  prayer: 'subuh' | 'zuhur' | 'asar' | 'magrib' | 'isya';
  prayerLabel: string;
  windowLabel: string;
  score: number;
} {
  const m = timeToMinutes(timeStr);

  // Subuh: 04.00 - 05.30 (240 - 330)
  if (m >= 240 && m <= 330) {
    return {
      prayer: 'subuh',
      prayerLabel: 'Shalat Subuh',
      windowLabel: '04.00 – 05.30 WIB',
      score: 100,
    };
  }
  // Zuhur: 11.40 - 14.55 (700 - 895)
  if (m >= 700 && m < 895) {
    return {
      prayer: 'zuhur',
      prayerLabel: 'Shalat Zuhur',
      windowLabel: '11.40 – 14.55 WIB',
      score: 100,
    };
  }
  // Asar: 14.55 - 17.50 (895 - 1070)
  if (m >= 895 && m < 1070) {
    return {
      prayer: 'asar',
      prayerLabel: 'Shalat Asar',
      windowLabel: '14.55 – 17.50 WIB',
      score: 100,
    };
  }
  // Magrib: 17.50 - 19.05 (1070 - 1145)
  if (m >= 1070 && m < 1145) {
    return {
      prayer: 'magrib',
      prayerLabel: 'Shalat Magrib',
      windowLabel: '17.50 – 19.05 WIB',
      score: 100,
    };
  }
  // Isya: 19.05 - 04.00 (>= 1145 or < 240)
  return {
    prayer: 'isya',
    prayerLabel: 'Shalat Isya',
    windowLabel: '19.05 – 04.00 WIB',
    score: 100,
  };
}

/** 3. Makan Bergizi: Sarapan (06.00-07.30), Siang (11.30-13.00), Malam (18.00-19.30) */
export function classifyMakanTime(timeStr: string): {
  mealSlot: 'sarapan' | 'siang' | 'malam';
  mealLabel: string;
  idealWindow: string;
  isOnTime: boolean;
} {
  const m = timeToMinutes(timeStr);

  // Before 10:30 is breakfast range
  if (m < 660) {
    const isStrict = m >= 360 && m <= 450; // 06.00 - 07.30
    return {
      mealSlot: 'sarapan',
      mealLabel: 'Sarapan Pagi',
      idealWindow: '06.00 – 07.30 WIB',
      isOnTime: isStrict,
    };
  }
  // Between 10:30 and 16:00 is lunch range
  if (m >= 660 && m < 960) {
    const isStrict = m >= 690 && m <= 780; // 11.30 - 13.00
    return {
      mealSlot: 'siang',
      mealLabel: 'Makan Siang',
      idealWindow: '11.30 – 13.00 WIB',
      isOnTime: isStrict,
    };
  }
  // Evening/night
  const isStrict = m >= 1080 && m <= 1170; // 18.00 - 19.30
  return {
    mealSlot: 'malam',
    mealLabel: 'Makan Malam',
    idealWindow: '18.00 – 19.30 WIB',
    isOnTime: isStrict,
  };
}

/** 4. Tidur Cepat */
export function classifyTidurCepatTime(timeStr: string): TimeClassificationResult {
  const m = timeToMinutes(timeStr);
  // Sebelum 21.30 WIB (e.g. 19.00 - 21.30, 1140 - 1290)
  // 21.30 = 1290 min
  // 22.30 = 1350 min
  // 23.30 = 1410 min

  if (m >= 1140 && m <= 1290) {
    return {
      detectedTime: timeStr,
      category: 'Tidur Cepat',
      bracket: '<21.30',
      score: 80,
      description: 'Sebelum 21.30 WIB (Sangat Ideal)',
      isOnTime: true,
    };
  } else if (m > 1290 && m <= 1350) {
    return {
      detectedTime: timeStr,
      category: 'Tidur Cepat',
      bracket: '21.30-22.30',
      score: 75,
      description: '21.30 – 22.30 WIB (Standar Ideal Remaja 28)',
      isOnTime: true,
    };
  } else if (m > 1350 && m <= 1410) {
    return {
      detectedTime: timeStr,
      category: 'Tidur Cepat',
      bracket: '22.31-23.30',
      score: 40,
      description: '22.31 – 23.30 WIB (Mulai Larut)',
      isOnTime: false,
    };
  } else {
    return {
      detectedTime: timeStr,
      category: 'Tidur Cepat',
      bracket: '>23.30',
      score: 15,
      description: 'Setelah 23.30 WIB (Kategori Begadang)',
      isOnTime: false,
    };
  }
}
