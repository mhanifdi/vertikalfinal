/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  classifyBangunPagiTime,
  classifyShalatTime,
  classifyMakanTime,
  classifyTidurCepatTime,
} from './timeClassifier';

test('classifyBangunPagiTime brackets', () => {
  // 04:30 -> 100 pt
  const b1 = classifyBangunPagiTime('04:30');
  assert.equal(b1.bracket, '04.00-05.00');
  assert.equal(b1.score, 100);

  // 05:45 -> 70 pt
  const b2 = classifyBangunPagiTime('05:45');
  assert.equal(b2.bracket, '05.00-06.00');
  assert.equal(b2.score, 70);

  // 06:15 -> 50 pt
  const b3 = classifyBangunPagiTime('06:15');
  assert.equal(b3.bracket, '>06.00');
  assert.equal(b3.score, 50);
});

test('classifyShalatTime prayer detection', () => {
  assert.equal(classifyShalatTime('04:45').prayer, 'subuh');
  assert.equal(classifyShalatTime('12:15').prayer, 'zuhur');
  assert.equal(classifyShalatTime('15:30').prayer, 'asar');
  assert.equal(classifyShalatTime('18:10').prayer, 'magrib');
  assert.equal(classifyShalatTime('19:45').prayer, 'isya');
});

test('classifyMakanTime meal detection', () => {
  assert.equal(classifyMakanTime('06:45').mealSlot, 'sarapan');
  assert.equal(classifyMakanTime('06:45').isOnTime, true);

  assert.equal(classifyMakanTime('12:15').mealSlot, 'siang');
  assert.equal(classifyMakanTime('12:15').isOnTime, true);

  assert.equal(classifyMakanTime('18:30').mealSlot, 'malam');
  assert.equal(classifyMakanTime('18:30').isOnTime, true);
});

test('classifyTidurCepatTime bedtime brackets', () => {
  // 21:15 -> <21.30
  const t1 = classifyTidurCepatTime('21:15');
  assert.equal(t1.bracket, '<21.30');
  assert.equal(t1.score, 80);

  // 22:00 -> 21.30-22.30
  const t2 = classifyTidurCepatTime('22:00');
  assert.equal(t2.bracket, '21.30-22.30');
  assert.equal(t2.score, 75);

  // 23:00 -> 22.31-23.30
  const t3 = classifyTidurCepatTime('23:00');
  assert.equal(t3.bracket, '22.31-23.30');
  assert.equal(t3.score, 40);

  // 00:15 -> >23.30
  const t4 = classifyTidurCepatTime('00:15');
  assert.equal(t4.bracket, '>23.30');
  assert.equal(t4.score, 15);
});
