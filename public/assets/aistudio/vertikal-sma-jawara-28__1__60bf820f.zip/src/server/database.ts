/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Local SQLite database manager for VERTIKAL SMA JAWARA 28
 * Stored at /database/local_habit.db
 */

import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';
import { USER_ACCOUNTS } from '../config/accounts';

const DB_DIR = path.resolve(process.cwd(), 'database');
const DB_FILE = path.resolve(DB_DIR, 'local_habit.db');

let dbInstance: Database | null = null;

export async function getDatabase(forceReset = false): Promise<Database> {
  if (dbInstance && !forceReset) return dbInstance;

  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }

  const SQL = await initSqlJs();

  // If force reset or file doesn't exist, create fresh
  if (forceReset && fs.existsSync(DB_FILE)) {
    try {
      fs.unlinkSync(DB_FILE);
    } catch {}
  }

  if (fs.existsSync(DB_FILE)) {
    const fileBuffer = fs.readFileSync(DB_FILE);
    dbInstance = new SQL.Database(fileBuffer);
  } else {
    dbInstance = new SQL.Database();
  }

  initTables(dbInstance);
  saveDatabase();

  return dbInstance;
}

export function saveDatabase(): void {
  if (!dbInstance) return;
  try {
    const data = dbInstance.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_FILE, buffer);
  } catch (err) {
    console.error('Failed to save SQLite database to disk:', err);
  }
}

function initTables(db: Database) {
  // 1. Students table
  db.run(`
    CREATE TABLE IF NOT EXISTS students (
      id TEXT PRIMARY KEY,
      nisn TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL DEFAULT '123',
      name TEXT NOT NULL,
      gender TEXT NOT NULL,
      class_name TEXT NOT NULL,
      angkatan TEXT NOT NULL,
      religion TEXT NOT NULL,
      avatar_seed TEXT,
      walas_name TEXT NOT NULL,
      walas_nip TEXT NOT NULL,
      walas_notes TEXT DEFAULT '',
      walas_recommendation TEXT DEFAULT ''
    );
  `);

  // 2. Habit Logs table (strictly recorded from user clicks)
  // Initially EMPTY (0)
  db.run(`
    CREATE TABLE IF NOT EXISTS habit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id TEXT NOT NULL,
      habit_type TEXT NOT NULL,
      sub_category TEXT DEFAULT '',
      log_date TEXT NOT NULL,
      created_at TEXT NOT NULL,
      score REAL NOT NULL,
      payload TEXT NOT NULL,
      is_counter_entry INTEGER DEFAULT 0,
      FOREIGN KEY (student_id) REFERENCES students(id)
    );
  `);

  // 3. Teachers table
  db.run(`
    CREATE TABLE IF NOT EXISTS teachers (
      id TEXT PRIMARY KEY,
      nip TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL DEFAULT '123',
      name TEXT NOT NULL,
      class_name TEXT NOT NULL,
      subject TEXT NOT NULL,
      role TEXT NOT NULL
    );
  `);

  // 4. Admin / Teacher Validations table
  db.run(`
    CREATE TABLE IF NOT EXISTS admin_validations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id TEXT NOT NULL,
      verified_by TEXT NOT NULL,
      verification_score INTEGER NOT NULL,
      notes TEXT,
      verified_at TEXT NOT NULL,
      FOREIGN KEY (student_id) REFERENCES students(id)
    );
  `);

  // Column safety migrations if existing db was from earlier version
  try {
    db.run(`ALTER TABLE students ADD COLUMN password TEXT NOT NULL DEFAULT '123';`);
  } catch {}
  try {
    db.run(`ALTER TABLE teachers ADD COLUMN password TEXT NOT NULL DEFAULT '12345';`);
  } catch {}
  try {
    db.run(`ALTER TABLE habit_logs ADD COLUMN sub_category TEXT DEFAULT '';`);
  } catch {}

  const studentIds = USER_ACCOUNTS.filter((a) => a.role === 'siswa').map((a) => `'${a.id}'`).join(',');
  db.run(`DELETE FROM students WHERE id NOT IN (${studentIds});`);
  db.run(`DELETE FROM teachers WHERE id NOT IN ('tch-guru', 'adm-admin');`);

  for (const studentAcc of USER_ACCOUNTS.filter((a) => a.role === 'siswa')) {
    db.run(
      `INSERT OR REPLACE INTO students (id, nisn, password, name, gender, class_name, angkatan, religion, avatar_seed, walas_name, walas_nip, walas_notes, walas_recommendation)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        studentAcc.id,
        studentAcc.username,
        studentAcc.password,
        studentAcc.name,
        studentAcc.gender || 'L',
        studentAcc.class_name,
        studentAcc.angkatan || '2025/2026',
        studentAcc.religion || 'Islam',
        studentAcc.username,
        studentAcc.walas_name || 'Dra. Hj. Nurhidayah, M.Pd.',
        studentAcc.walas_nip || '197405101999032001',
        'Pertahankan konsistensi 7 kebiasaan unggul Jawara 28.',
        'Tingkatkan keterlibatan aktif dalam kegiatan Adiwiyata sekolah.',
      ]
    );
  }

  const guruAcc = USER_ACCOUNTS.find((a) => a.role === 'guru');
  if (guruAcc) {
    db.run(
      `INSERT OR REPLACE INTO teachers (id, nip, password, name, class_name, subject, role)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        guruAcc.id,
        guruAcc.username,
        guruAcc.password,
        guruAcc.name,
        guruAcc.class_name,
        'Wali Kelas & Guru Pembimbing',
        'Guru Wali Kelas',
      ]
    );
  }

  const adminAcc = USER_ACCOUNTS.find((a) => a.role === 'admin');
  if (adminAcc) {
    db.run(
      `INSERT OR REPLACE INTO teachers (id, nip, password, name, class_name, subject, role)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        adminAcc.id,
        adminAcc.username,
        adminAcc.password,
        adminAcc.name,
        adminAcc.class_name,
        'Kepala Sekolah / Tim Kesiswaan 7 KAIH',
        'Admin Kesiswaan',
      ]
    );
  }
}
