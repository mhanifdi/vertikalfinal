/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Lock, User, Shield, GraduationCap, School, KeyRound, Info, AlertCircle } from 'lucide-react';
import { Student, Teacher, Role } from '../../types';
import sman28Photo from '../../assets/images/sman28_campus_exterior_1792928761292.jpg';

interface LoginPageProps {
  students: Student[];
  teachers: Teacher[];
  onLoginStudent: (student: Student) => void;
  onLoginTeacher: (teacher: Teacher) => void;
  onLoginAdmin: (admin: Teacher) => void;
  onBackToPublic?: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  students,
  teachers,
  onLoginStudent,
  onLoginTeacher,
  onLoginAdmin,
  onBackToPublic,
}) => {
  const [role, setRole] = useState<Role>('siswa');
  const [usernameInput, setUsernameInput] = useState('siswa');
  const [passwordInput, setPasswordInput] = useState('123');
  const [rememberMe, setRememberMe] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);

  const handleRoleChange = (newRole: Role) => {
    setRole(newRole);
    setErrorMsg('');
    if (newRole === 'siswa') {
      setUsernameInput('siswa');
      setPasswordInput('123');
    } else if (newRole === 'guru') {
      setUsernameInput('guru');
      setPasswordInput('123');
    } else {
      setUsernameInput('admin');
      setPasswordInput('123');
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);

    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          role,
          username: usernameInput.trim(),
          password: passwordInput.trim(),
        }),
      });

      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.error || 'Login gagal');
      }

      if (role === 'siswa') {
        onLoginStudent(json.data);
      } else if (role === 'guru') {
        onLoginTeacher(json.data);
      } else {
        onLoginAdmin(json.data);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Username atau Kata Sandi salah');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-kebaya-pattern flex items-center justify-center p-4 sm:p-6 md:p-10">
      <div className="w-full max-w-5xl bg-white rounded-3xl shadow-xl border border-slate-200/90 overflow-hidden grid grid-cols-1 md:grid-cols-12 min-h-[580px]">
        {/* Left Container (Bevel, minimalist login form) */}
        <div className="md:col-span-6 p-6 sm:p-10 flex flex-col justify-between bg-white relative">
          <div>
            {onBackToPublic && (
              <button
                type="button"
                onClick={onBackToPublic}
                className="mb-4 text-xs font-bold text-[#1c5ddc] hover:underline inline-flex items-center gap-1 cursor-pointer"
              >
                ← Balik ke Dashboard Publik
              </button>
            )}
            <div className="mb-5">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[10px] font-black uppercase tracking-wider text-[#1c5ddc] bg-blue-50 px-2 py-0.5 rounded-md">
                  Portal Masuk Jawara 28
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#eb30a2]" />
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                VERTIKAL SMA JAWARA 28
              </h1>
              <p className="text-xs text-slate-500 font-medium mt-1">
                Sistem Evaluasi 7 Kebiasaan Anak Indonesia Hebat (7 KAIH) SMAN 28 Jakarta.
              </p>
            </div>

            {/* Role Switcher */}
            <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 rounded-2xl mb-5">
              {[
                { id: 'siswa' as const, label: 'Siswa', icon: GraduationCap },
                { id: 'guru' as const, label: 'Guru', icon: School },
                { id: 'admin' as const, label: 'Admin', icon: Shield },
              ].map((r) => {
                const Icon = r.icon;
                const active = role === r.id;
                return (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => handleRoleChange(r.id)}
                    className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                      active
                        ? 'bg-white text-slate-900 shadow-xs ring-1 ring-slate-200'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <Icon className={`w-3.5 h-3.5 ${active ? 'text-[#1c5ddc]' : ''}`} />
                    <span>{r.label}</span>
                  </button>
                );
              })}
            </div>

            {errorMsg && (
              <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleFormSubmit} className="space-y-4">
              {/* Username / NISN text input */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {role === 'siswa'
                    ? 'NISN / Username Siswa:'
                    : role === 'guru'
                    ? 'NIP / Username Guru:'
                    : 'Username Admin:'}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={usernameInput}
                    onChange={(e) => setUsernameInput(e.target.value)}
                    placeholder={role === 'siswa' ? 'Ketik NISN / siswa' : role === 'guru' ? 'Ketik NIP / guru' : 'admin'}
                    className="w-full px-3.5 py-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#1c5ddc]"
                    required
                  />
                  <User className="w-3.5 h-3.5 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
                </div>
              </div>

              {/* Password text input */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Kata Sandi (Password):
                </label>
                <div className="relative">
                  <input
                    type="password"
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    placeholder="Ketik kata sandi..."
                    className="w-full px-3.5 py-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#1c5ddc]"
                    required
                  />
                  <Lock className="w-3.5 h-3.5 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
                </div>
              </div>

              {/* Quick Fill Demo Credential Pill */}
              <div className="p-2.5 bg-blue-50/60 rounded-xl border border-blue-100 space-y-1.5 text-[11px]">
                <div className="flex items-center justify-between">
                  <span className="text-slate-600 font-medium">Akun Demo Resmi:</span>
                  <span className="font-mono font-bold text-[#1c5ddc]">password: 123</span>
                </div>
                {role === 'siswa' ? (
                  <div className="flex flex-wrap gap-1.5 pt-0.5">
                    <button
                      type="button"
                      onClick={() => {
                        setUsernameInput('siswa');
                        setPasswordInput('123');
                      }}
                      className="px-2 py-0.5 rounded-lg bg-white border border-blue-200 text-[#1c5ddc] font-bold hover:bg-blue-50 cursor-pointer text-[10px]"
                    >
                      siswa (Islam L)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setUsernameInput('siswai');
                        setPasswordInput('123');
                      }}
                      className="px-2 py-0.5 rounded-lg bg-white border border-pink-200 text-pink-700 font-bold hover:bg-pink-50 cursor-pointer text-[10px]"
                    >
                      siswai (Islam P)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setUsernameInput('siswak');
                        setPasswordInput('123');
                      }}
                      className="px-2 py-0.5 rounded-lg bg-white border border-purple-200 text-purple-700 font-bold hover:bg-purple-50 cursor-pointer text-[10px]"
                    >
                      siswak (Kristen)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setUsernameInput('siswah');
                        setPasswordInput('123');
                      }}
                      className="px-2 py-0.5 rounded-lg bg-white border border-amber-200 text-amber-700 font-bold hover:bg-amber-50 cursor-pointer text-[10px]"
                    >
                      siswah (Hindu)
                    </button>
                  </div>
                ) : (
                  <div className="font-mono font-bold text-[#1c5ddc]">
                    {role === 'guru' ? 'guru / 123' : 'admin / 123'}
                  </div>
                )}
              </div>

              {/* Remember Me */}
              <div className="flex items-center justify-between text-xs pt-1">
                <label className="flex items-center gap-2 text-slate-600 cursor-pointer font-medium">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 rounded text-[#1c5ddc] focus:ring-[#1c5ddc]"
                  />
                  <span>Ingat Saya (Remember Me)</span>
                </label>
                <span className="text-[11px] text-slate-400">Database SQL Lokal</span>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={loading}
                className="btn-interactive w-full py-3 bg-[#1c5ddc] hover:bg-blue-700 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-md transition-colors cursor-pointer mt-2 disabled:opacity-50"
              >
                {loading ? 'Memverifikasi...' : `Masuk ke Instrumen ${role === 'siswa' ? 'Siswa' : role === 'guru' ? 'Guru' : 'Admin'}`}
              </button>
            </form>
          </div>

          {/* Footnote info on where credentials file is located */}
          <div className="pt-4 border-t border-slate-100 text-[11px] text-slate-400 space-y-1">
            <div className="flex items-center gap-1.5 text-slate-500 font-medium">
              <Info className="w-3.5 h-3.5 text-[#1c5ddc]" />
              <span>Lokasi File Data Akun: <code>/src/config/accounts.ts</code></span>
            </div>
            <p className="text-[10px] text-slate-400">
              SMAN 28 Jakarta • SQLite <code>/database/local_habit.db</code>
            </p>
          </div>
        </div>

        {/* Right Container: Minimalist Modern photo of SMAN 28 */}
        <div className="hidden md:block md:col-span-6 relative bg-slate-900 overflow-hidden">
          <img
            src={sman28Photo}
            alt="SMAN 28 Jakarta Modern Campus"
            className="w-full h-full object-cover opacity-90 transition-transform duration-700 hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-transparent" />

          <div className="absolute bottom-8 left-8 right-8 text-white space-y-2">
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-[11px] font-bold border border-white/30">
              <span className="w-2 h-2 rounded-full bg-[#feb52b]" />
              SMAN 28 JAKARTA • SEKOLAH ADIWIYATA MANDIRI
            </div>
            <h3 className="text-xl font-black tracking-tight leading-tight">
              Membangun Generasi Jawara dengan Karakter Luhur &amp; Kebiasaan Hebat.
            </h3>
            <p className="text-xs text-slate-300 font-normal leading-relaxed">
              Jujur, Berwawasan, Tangguh, dan Peduli Sesama melalui implementasi harian 7 Kebiasaan Anak Indonesia Hebat.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
