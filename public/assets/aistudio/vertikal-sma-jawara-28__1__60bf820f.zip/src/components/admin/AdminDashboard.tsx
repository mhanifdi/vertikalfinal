/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Award,
  Users,
  CheckCircle2,
  Trophy,
  BarChart3,
  Building2,
  Sparkles,
  ChevronRight,
  Search,
  CheckCheck,
  Star,
  FileCheck,
} from 'lucide-react';
import { Teacher, Student, SchoolAnalytics, ClassAnalytics } from '../../types';
import { api } from '../../utils/api';
import { RadarChart } from '../charts/RadarChart';
import { GaugeChart } from '../charts/GaugeChart';
import { ScoreDistributionBar } from '../charts/ScoreDistributionBar';
import { LeaderboardTable } from '../common/LeaderboardTable';
import { StudentReportModal } from '../common/StudentReportModal';

interface AdminDashboardProps {
  admin: Teacher;
  allStudents: Student[];
  onLogout: () => void;
  onRefreshStudents?: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  admin,
  allStudents,
  onLogout,
  onRefreshStudents,
}) => {
  const [activeTab, setActiveTab] = useState<'sekolah' | 'leaderboard' | 'validasi'>('sekolah');
  const [chartMode, setChartMode] = useState<'radar' | 'progress'>('radar');
  const [schoolData, setSchoolData] = useState<SchoolAnalytics | null>(null);
  const [selectedClassDetail, setSelectedClassDetail] = useState<string | null>(null);
  const [classDetailData, setClassDetailData] = useState<ClassAnalytics | null>(null);
  const [selectedStudentForReport, setSelectedStudentForReport] = useState<string | null>(null);

  // Validation state
  const [validationForm, setValidationForm] = useState<{
    studentId: string;
    score: number;
    notes: string;
  }>({
    studentId: '',
    score: 9,
    notes: 'Konsisten bangun pagi dan aktif dalam piket kebersihan SMAN 28.',
  });
  const [validationSuccess, setValidationSuccess] = useState(false);

  const loadSchoolAnalytics = async () => {
    try {
      const data = await api.getSchoolAnalytics();
      setSchoolData(data);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadSchoolAnalytics();
  }, []);

  const handleInspectClass = async (className: string) => {
    try {
      setSelectedClassDetail(className);
      const data = await api.getClassAnalytics(className);
      setClassDetailData(data);
    } catch (e) {
      console.error(e);
    }
  };

  const handleSaveValidation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validationForm.studentId) return;

    try {
      await api.saveAdminValidation({
        student_id: validationForm.studentId,
        verification_score: validationForm.score,
        verified_by: `${admin.name} (${admin.role})`,
        notes: validationForm.notes,
      });
      setValidationSuccess(true);
      setTimeout(() => setValidationSuccess(false), 3000);
      onRefreshStudents?.();
      await loadSchoolAnalytics();
    } catch (e) {
      console.error(e);
    }
  };

  const top10Students = allStudents.slice(0, 10);

  return (
    <div className="min-h-screen bg-kebaya-pattern flex flex-col pb-12">
      {/* Top Header */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 sm:px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#0000fe] to-[#1c5ddc] text-white flex items-center justify-center font-black text-sm shadow-sm">
            28
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-sm sm:text-base text-slate-900 tracking-tight">
                VERTIKAL SMA JAWARA 28
              </span>
              <span className="text-[10px] bg-blue-100 text-[#0000fe] px-2 py-0.5 rounded-full font-black">
                Instrumen Admin Kesiswaan
              </span>
            </div>
            <span className="text-[11px] text-slate-500">
              SMAN 28 Jakarta • Pengawasan &amp; Validasi Karakter Sekolah
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <span className="text-xs font-bold text-slate-900 block">{admin.name}</span>
            <span className="text-[10px] text-slate-500">{admin.role} • NIP {admin.nip}</span>
          </div>
          <button
            type="button"
            onClick={onLogout}
            className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors cursor-pointer"
          >
            Keluar
          </button>
        </div>
      </header>

      {/* Main Container */}
      <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6 flex-1">
        {/* Profile Card & KPI Header */}
        <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm relative overflow-hidden">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-[#0000fe] text-white flex items-center justify-center font-black text-2xl shadow-md ring-4 ring-indigo-50">
                ADM
              </div>
              <div>
                <h2 className="text-lg sm:text-xl font-extrabold text-slate-900">{admin.name}</h2>
                <p className="text-xs text-slate-500 font-medium">
                  NIP: {admin.nip} • {admin.subject}
                </p>
                <span className="text-[11px] text-[#0000fe] font-semibold bg-indigo-50 px-2.5 py-0.5 rounded-full inline-block mt-1">
                  Otoritas Validasi Kesiswaan SMAN 28 Jakarta
                </span>
              </div>
            </div>

            {/* Admin Tab Switcher */}
            <div className="flex bg-slate-100 p-1 rounded-xl">
              <button
                type="button"
                onClick={() => setActiveTab('sekolah')}
                className={`px-4 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  activeTab === 'sekolah'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Analitik Sekolah
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('leaderboard')}
                className={`px-4 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  activeTab === 'leaderboard'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Papan Peringkat
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('validasi')}
                className={`px-4 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'validasi'
                    ? 'bg-[#19ae5d] text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                Validasi Top 10
              </button>
            </div>
          </div>

          {/* 3 KPI Cards: Siswa Berpartisipasi, Rata-rata Skor, Rata-rata Respon Terverifikasi */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 bg-blue-50/70 border border-blue-100 rounded-2xl">
              <span className="text-xs font-bold text-slate-600 block">Siswa Berpartisipasi (Sekolah)</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-3xl font-black text-[#1c5ddc]">
                  {schoolData?.participatingStudents || 0}
                </span>
                <span className="text-xs font-bold text-slate-500">
                  / {schoolData?.totalStudents || 0} total siswa
                </span>
              </div>
              <span className="text-[11px] text-blue-700 font-medium block mt-1">
                Tercatat aktif di database lokal SQLite
              </span>
            </div>

            <div className="p-4 bg-emerald-50/70 border border-emerald-100 rounded-2xl">
              <span className="text-xs font-bold text-slate-600 block">Rata-Rata Skor Sekolah</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-3xl font-black text-[#19ae5d]">
                  {schoolData?.overallScore ? schoolData.overallScore.toFixed(1) : '0'}
                </span>
                <span className="text-xs font-bold text-slate-500">/ 100 pt</span>
              </div>
              <span className="text-[11px] text-emerald-700 font-medium block mt-1">
                Indeks Karakter SMAN 28 Jakarta
              </span>
            </div>

            <div className="p-4 bg-indigo-50/70 border border-indigo-100 rounded-2xl">
              <span className="text-xs font-bold text-slate-600 block">Respon Terverifikasi Lapangan</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-3xl font-black text-[#0000fe]">
                  {allStudents.filter((s) => s.verification_score).length}
                </span>
                <span className="text-xs font-bold text-slate-500">siswa tervalidasi</span>
              </div>
              <span className="text-[11px] text-indigo-700 font-medium block mt-1">
                Skor kebenaran 1–10 hasil pantauan sekolah
              </span>
            </div>
          </div>
        </div>

        {/* TAB 1: ANALITIK SEKOLAH & DAFTAR KELAS */}
        {activeTab === 'sekolah' && (
          <div className="space-y-6">
            {/* Analitik Sekolah: Capaian 7 KAIH, Gauge, Distribusi */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Capaian 7 KAIH Sekolah (Radar / Progress Bar Switch) */}
              <div className="lg:col-span-5 bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col justify-between">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-sm sm:text-base">
                      Capaian 7 KAIH SMAN 28 Jakarta
                    </h3>
                    <p className="text-xs text-slate-500">Rerata seluruh pilar karakter se-sekolah</p>
                  </div>

                  <div className="flex bg-slate-100 p-0.5 rounded-lg text-xs">
                    <button
                      type="button"
                      onClick={() => setChartMode('radar')}
                      className={`px-2.5 py-1 rounded font-bold cursor-pointer transition-all ${
                        chartMode === 'radar' ? 'bg-white text-[#1c5ddc] shadow-xs' : 'text-slate-600'
                      }`}
                    >
                      Radar
                    </button>
                    <button
                      type="button"
                      onClick={() => setChartMode('progress')}
                      className={`px-2.5 py-1 rounded font-bold cursor-pointer transition-all ${
                        chartMode === 'progress' ? 'bg-white text-[#1c5ddc] shadow-xs' : 'text-slate-600'
                      }`}
                    >
                      Bar
                    </button>
                  </div>
                </div>

                {chartMode === 'radar' ? (
                  <RadarChart
                    data={(schoolData?.schoolRadar || []).map((r) => ({
                      habit: r.habit,
                      label: r.label,
                      score: r.avg_score,
                    }))}
                    size={270}
                  />
                ) : (
                  <div className="space-y-2.5 my-2">
                    {(schoolData?.schoolRadar || []).map((r) => (
                      <div key={r.habit} className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="font-bold text-slate-700">{r.label}</span>
                          <span className="font-black text-[#1c5ddc]">{r.avg_score} pt</span>
                        </div>
                        <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-[#1c5ddc] via-[#feb52b] to-[#19ae5d] rounded-full transition-all duration-500"
                            style={{ width: `${Math.min(100, Math.max(0, r.avg_score))}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <div className="text-[11px] text-slate-400 text-center mt-2">
                  Dihitung dari riwayat klik SQLite lokal_habit.db
                </div>
              </div>

              {/* Gauge Rata-rata Skor Sekolah */}
              <div className="lg:col-span-3 bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col justify-center items-center">
                <h3 className="font-extrabold text-slate-900 text-sm mb-2 text-center">
                  Gauge Rata-Rata Sekolah
                </h3>
                <GaugeChart score={schoolData?.overallScore || 0} title="SMAN 28 Jakarta" size={230} />
              </div>

              {/* Distribusi Skor Sekolah */}
              <div className="lg:col-span-4 bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col justify-between">
                <div>
                  <h3 className="font-extrabold text-slate-900 text-sm sm:text-base mb-1">
                    Distribusi Skor Siswa Sekolah
                  </h3>
                  <p className="text-xs text-slate-500 mb-4">
                    Sebaran skor 7 KAIH se-SMAN 28
                  </p>
                </div>

                {schoolData?.distribution && (
                  <ScoreDistributionBar distribution={schoolData.distribution} />
                )}

                <div className="text-[11px] text-slate-400 text-right mt-2">
                  Rentang &lt;70 s.d. 96–100
                </div>
              </div>
            </div>

            {/* DAFTAR KELAS (Bisa melihat detail satu per satu kelasnya) */}
            <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4">
              <div>
                <h3 className="font-extrabold text-slate-900 text-base">
                  Daftar Kelas SMAN 28 Jakarta
                </h3>
                <p className="text-xs text-slate-500">
                  Klik pada salah satu kelas untuk membuka analitik kelas &amp; daftar muridnya secara mendalam
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                {(schoolData?.classes || ['XI-MIPA-1', 'XI-MIPA-2', 'XI-MIPA-3', 'XII-MIPA-1']).map((cls) => (
                  <button
                    key={cls}
                    type="button"
                    onClick={() => handleInspectClass(cls)}
                    className={`p-4 rounded-2xl border text-left cursor-pointer transition-all ${
                      selectedClassDetail === cls
                        ? 'border-[#0000fe] bg-indigo-50/60 ring-2 ring-[#0000fe]/20 shadow-sm'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <Building2 className={`w-5 h-5 mb-2 ${selectedClassDetail === cls ? 'text-[#0000fe]' : 'text-slate-400'}`} />
                    <span className="font-bold text-slate-900 text-sm block">{cls}</span>
                    <span className="text-[11px] text-[#1c5ddc] font-semibold mt-1 inline-flex items-center gap-0.5">
                      Lihat Detail <ChevronRight className="w-3 h-3" />
                    </span>
                  </button>
                ))}
              </div>

              {/* INSPECTED CLASS ANALYTICS & STUDENTS */}
              {selectedClassDetail && classDetailData && (
                <div className="pt-6 border-t border-slate-200 space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-black uppercase tracking-wider text-[#0000fe]">
                        Inspeksi Analitik Kelas
                      </span>
                      <h4 className="text-lg font-black text-slate-900">
                        Kelas {classDetailData.className}
                      </h4>
                    </div>
                    <button
                      type="button"
                      onClick={() => setSelectedClassDetail(null)}
                      className="text-xs font-bold text-slate-500 hover:text-slate-800"
                    >
                      Tutup Detail Kelas ✕
                    </button>
                  </div>

                  {/* 3 mini cards for the inspected class: Radar, Gauge, Distribution */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                      <span className="text-xs font-bold text-slate-700 block mb-2">Radar Kelas {classDetailData.className}</span>
                      <RadarChart
                        data={classDetailData.classRadar.map((r) => ({
                          habit: r.habit,
                          label: r.label,
                          score: r.avg_score,
                        }))}
                        size={210}
                      />
                    </div>
                    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex flex-col justify-center items-center">
                      <span className="text-xs font-bold text-slate-700 block mb-1">Rata-Rata Kelas</span>
                      <GaugeChart score={classDetailData.classAverage} title={classDetailData.className} size={180} />
                    </div>
                    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                      <span className="text-xs font-bold text-slate-700 block mb-2">Distribusi Skor Kelas</span>
                      <ScoreDistributionBar distribution={classDetailData.distribution} />
                    </div>
                  </div>

                  {/* Murid di kelas ini: bisa buka rapor individual satu per satu */}
                  <div className="border border-slate-200 rounded-2xl overflow-hidden">
                    <div className="bg-slate-50 p-3 text-xs font-bold text-slate-700 border-b border-slate-200">
                      Daftar Murid Kelas {classDetailData.className} ({classDetailData.students.length} Siswa)
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs text-left">
                        <thead className="bg-slate-50/60 text-slate-500 font-semibold border-b border-slate-200">
                          <tr>
                            <th className="py-2.5 px-3">Nama</th>
                            <th className="py-2.5 px-3">NISN</th>
                            <th className="py-2.5 px-3 text-center">Entri</th>
                            <th className="py-2.5 px-3 text-right">Rerata Skor</th>
                            <th className="py-2.5 px-3 text-center">Aksi</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {classDetailData.students.map((st) => (
                            <tr key={st.id} className="hover:bg-slate-50">
                              <td className="py-2.5 px-3 font-bold text-slate-800">{st.name}</td>
                              <td className="py-2.5 px-3 font-mono text-slate-500">{st.nisn}</td>
                              <td className="py-2.5 px-3 text-center font-medium text-slate-600">{st.total_entries || 0}</td>
                              <td className="py-2.5 px-3 text-right font-black text-[#1c5ddc]">
                                {st.avg_score ? st.avg_score.toFixed(1) : '0'} pt
                              </td>
                              <td className="py-2.5 px-3 text-center">
                                <button
                                  type="button"
                                  onClick={() => setSelectedStudentForReport(st.id)}
                                  className="btn-interactive px-2.5 py-1 bg-slate-800 hover:bg-slate-900 text-white rounded text-[11px] font-bold cursor-pointer"
                                >
                                  Buka Rapor
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: PAPAN PERINGKAT */}
        {activeTab === 'leaderboard' && (
          <div className="space-y-4">
            <LeaderboardTable
              students={allStudents}
              onSelectStudent={(s) => setSelectedStudentForReport(s.id)}
            />
          </div>
        )}

        {/* TAB 3: VALIDASI TOP 10 LEADERBOARD */}
        {activeTab === 'validasi' && (
          <div className="space-y-6">
            <div className="p-5 bg-gradient-to-r from-emerald-50 via-teal-50 to-blue-50 border border-emerald-200 rounded-3xl">
              <div className="flex items-center gap-2 mb-1">
                <ShieldCheck className="w-5 h-5 text-emerald-700" />
                <h3 className="font-extrabold text-slate-900 text-base">
                  Instrumen Validasi Observasi Lapangan SMAN 28 (Top 10 Leaderboard)
                </h3>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Fitur evaluasi faktual: Guru &amp; Admin dapat memvalidasi siswa peringkat teratas dengan skor kebenaran data (skala 1–10) berdasarkan pengamatan perilaku nyata di lingkungan sekolah SMAN 28 Jakarta.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Form Input Validasi */}
              <div className="lg:col-span-5 bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
                <h4 className="font-extrabold text-slate-900 text-sm">
                  Formulir Penilaian Verifikasi
                </h4>

                {validationSuccess && (
                  <div className="p-3 bg-emerald-100 text-emerald-900 rounded-xl text-xs font-bold flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                    Skor validasi lapangan berhasil disimpan ke database SQLite!
                  </div>
                )}

                <form onSubmit={handleSaveValidation} className="space-y-4 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      Pilih Siswa (Top 10 Leaderboard):
                    </label>
                    <select
                      value={validationForm.studentId}
                      onChange={(e) =>
                        setValidationForm((prev) => ({ ...prev, studentId: e.target.value }))
                      }
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-800"
                      required
                    >
                      <option value="">-- Pilih Siswa yang Diverifikasi --</option>
                      {top10Students.map((st, i) => (
                        <option key={st.id} value={st.id}>
                          #{i + 1} {st.name} ({st.class_name}) — Poin: {st.avg_score || 0}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <label className="font-bold text-slate-700">
                        Skor Kebenaran Data (Skala 1 – 10):
                      </label>
                      <span className="text-sm font-black text-emerald-700">
                        {validationForm.score} / 10
                      </span>
                    </div>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                        <button
                          key={num}
                          type="button"
                          onClick={() =>
                            setValidationForm((prev) => ({ ...prev, score: num }))
                          }
                          className={`flex-1 py-2 rounded-lg font-black text-xs cursor-pointer transition-all ${
                            validationForm.score === num
                              ? 'bg-[#19ae5d] text-white shadow-xs'
                              : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                          }`}
                        >
                          {num}
                        </button>
                      ))}
                    </div>
                    <span className="text-[10px] text-slate-400 block mt-1">
                      1 = Data fiktif/meragukan, 10 = Sangat akurat &amp; terbukti berkarakter teladan di sekolah
                    </span>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      Catatan Observasi Verifikator:
                    </label>
                    <textarea
                      rows={3}
                      value={validationForm.notes}
                      onChange={(e) =>
                        setValidationForm((prev) => ({ ...prev, notes: e.target.value }))
                      }
                      placeholder="Tuliskan bukti nyata pengamatan di sekolah (misal: aktif piket, sopan, rajin ibadah)..."
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-1 focus:ring-emerald-500"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    className="btn-interactive w-full py-2.5 bg-[#19ae5d] hover:bg-emerald-700 text-white font-bold rounded-xl shadow-xs cursor-pointer flex items-center justify-center gap-2"
                  >
                    <CheckCheck className="w-4 h-4" />
                    Simpan Validasi Resmi
                  </button>
                </form>
              </div>

              {/* Tabel Status Validasi Top 10 */}
              <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-3">
                <h4 className="font-extrabold text-slate-900 text-sm">
                  Daftar Murid Top 10 &amp; Status Validasi
                </h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200">
                      <tr>
                        <th className="py-2.5 px-3">Rank</th>
                        <th className="py-2.5 px-3">Nama Siswa</th>
                        <th className="py-2.5 px-3">Kelas</th>
                        <th className="py-2.5 px-3 text-right">Skor 7 KAIH</th>
                        <th className="py-2.5 px-3 text-center">Skor Kebenaran</th>
                        <th className="py-2.5 px-3 text-center">Aksi</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {top10Students.map((st, i) => (
                        <tr key={st.id} className="hover:bg-slate-50">
                          <td className="py-2.5 px-3 font-bold text-slate-700">#{i + 1}</td>
                          <td className="py-2.5 px-3 font-bold text-slate-900">{st.name}</td>
                          <td className="py-2.5 px-3 text-slate-600">{st.class_name}</td>
                          <td className="py-2.5 px-3 text-right font-black text-[#1c5ddc]">
                            {st.avg_score ? st.avg_score.toFixed(1) : '0'} pt
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            {st.verification_score !== null && st.verification_score !== undefined ? (
                              st.verification_score < 7 ? (
                                <span className="inline-flex items-center gap-1 bg-red-100 text-red-700 px-2.5 py-1 rounded-full font-black text-[11px] animate-pulse">
                                  <AlertCircle className="w-3.5 h-3.5 text-red-600" />
                                  Tindak Lanjut! ({st.verification_score}/10)
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                                  <Star className="w-3 h-3 fill-emerald-600 text-emerald-600" />
                                  {st.verification_score}/10
                                </span>
                              )
                            ) : (
                              <span className="text-slate-400 text-[10px]">Belum Validasi</span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            <div className="flex items-center justify-center gap-2">
                              {st.verification_score !== null && st.verification_score !== undefined && st.verification_score < 7 && (
                                <button
                                  type="button"
                                  onClick={() => setSelectedStudentForReport(st.id)}
                                  className="px-2 py-1 bg-red-600 hover:bg-red-700 text-white rounded-lg text-[10px] font-bold cursor-pointer shadow-xs"
                                >
                                  Buka Rapor
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => {
                                  setValidationForm((prev) => ({ ...prev, studentId: st.id }));
                                }}
                                className="text-xs font-bold text-emerald-700 hover:underline cursor-pointer"
                              >
                                Validasi Ini
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Rapor Modal */}
      {selectedStudentForReport && (
        <StudentReportModal
          studentId={selectedStudentForReport}
          canEditNotes={true}
          onClose={() => setSelectedStudentForReport(null)}
        />
      )}
    </div>
  );
};
