/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Form Gemar Belajar SMAN 28 Jakarta
 * Skema: Durasi (Maks 60 pt) + Bentuk Kegiatan (Maks 30 pt) + Akuntabilitas Output (Maks 10 pt)
 * Kontainer 1 screen (max-h-[90vh]), scrollable body, full-screen blur backdrop
 */

import React, { useState, useEffect } from 'react';
import { GraduationCap, CheckCircle2, Check, BookOpen, ShieldCheck } from 'lucide-react';
import { calculateGemarBelajarScore } from '../../utils/scoring';

interface GemarBelajarFormProps {
  onSuccess: (score: number, payload: any) => void;
  onCancel: () => void;
  isAlreadySubmitted?: boolean;
}

export const GemarBelajarForm: React.FC<GemarBelajarFormProps> = ({
  onSuccess,
  onCancel,
  isAlreadySubmitted = false,
}) => {
  const [activities, setActivities] = useState<string[]>([
    'Mengulang materi pelajaran sekolah / mengerjakan TP / PR',
  ]);
  const [duration, setDuration] = useState<'0' | '<15' | '15-30' | '30-60' | '1-2h' | '2-3h' | '>3h'>('1-2h');
  const [outputDescription, setOutputDescription] = useState('');
  const [isMissed, setIsMissed] = useState(false);
  const [showHonestyModal, setShowHonestyModal] = useState(false);

  // Lock scroll
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  const toggleActivity = (item: string) => {
    setActivities((prev) =>
      prev.includes(item) ? prev.filter((a) => a !== item) : [...prev, item]
    );
  };

  const currentScore = calculateGemarBelajarScore({
    duration,
    activities,
    outputDescription,
    isMissed,
  });

  const handleTriggerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!outputDescription.trim()) {
      alert('Tuliskan output ringkas materi apa yang dipelajari hari ini (minimal 10 karakter untuk skor maksimal).');
      return;
    }
    setShowHonestyModal(true);
  };

  const handleConfirmHonesty = () => {
    setShowHonestyModal(false);
    onSuccess(currentScore, {
      duration,
      activities,
      outputDescription,
      isMissed,
      timestamp: new Date().toLocaleTimeString('id-ID'),
    });
  };

  return (
    <div className="modal-backdrop-blur">
      <div className="w-full max-w-lg max-h-[90vh] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex-shrink-0 px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-purple-50/80 to-white">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-600 text-white flex items-center justify-center shadow-xs">
              <GraduationCap className="w-5 h-5 fill-white" />
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-purple-600">
                Formulir 7 KAIH SMAN 28
              </span>
              <h3 className="font-extrabold text-slate-900 text-base leading-tight">
                Gemar Belajar Mandiri
              </h3>
            </div>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 font-bold flex items-center justify-center cursor-pointer transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleTriggerSubmit} className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          <div className="flex items-center justify-between p-3 bg-purple-50/60 rounded-2xl border border-purple-200">
            <div>
              <span className="text-xs font-bold text-slate-900 block">
                Skor Durasi (60) + Ragam (30) + Output (10)
              </span>
              <span className="text-[11px] text-slate-500">
                Mendorong kemandirian belajar di luar jam sekolah SMAN 28
              </span>
            </div>
            <label className="flex items-center gap-2 text-xs font-bold text-purple-700 cursor-pointer bg-white px-2.5 py-1 rounded-xl border border-purple-200 shadow-2xs">
              <input
                type="checkbox"
                checked={isMissed}
                onChange={(e) => setIsMissed(e.target.checked)}
                className="w-4 h-4 text-purple-600 rounded"
              />
              Isi Terlewat (-5 pt)
            </label>
          </div>

          {/* Durasi Belajar */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1.5">
              Durasi Belajar Mandiri di Luar Jam Sekolah:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {[
                { key: '0', label: '0 Menit', pts: '0 pt' },
                { key: '<15', label: '< 15 Menit', pts: '10 pt' },
                { key: '15-30', label: '15 – 30 Menit', pts: '20 pt' },
                { key: '30-60', label: '30 – 60 Menit', pts: '30 pt' },
                { key: '1-2h', label: '1 – 2 Jam', pts: '40 pt' },
                { key: '2-3h', label: '2 – 3 Jam', pts: '50 pt' },
                { key: '>3h', label: '> 3 Jam', pts: '60 pt' },
              ].map((d) => (
                <button
                  key={d.key}
                  type="button"
                  onClick={() => setDuration(d.key as any)}
                  className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    duration === d.key
                      ? 'bg-purple-50 border-purple-600 ring-1 ring-purple-600'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <span className="text-xs font-bold text-slate-900">{d.label}</span>
                  <span className="text-[10px] font-black text-purple-600">{d.pts}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Bentuk Kegiatan */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1.5">
              Bentuk Kegiatan Belajar (1=10 pt, 2=20 pt, ≥3=30 pt):
            </label>
            <div className="space-y-2">
              {[
                'Mengulang materi pelajaran sekolah / mengerjakan TP / PR',
                'Membaca buku (Non-fiksi / Fiksi / Artikel Ilmiah)',
                'Belajar skill baru (Koding, bahasa asing, musik, desain, dll.)',
                'Mengikuti kelompok belajar / study club bareng teman',
              ].map((act) => {
                const isSelected = activities.includes(act);
                return (
                  <label
                    key={act}
                    onClick={() => toggleActivity(act)}
                    className={`flex items-center gap-2.5 p-2.5 rounded-xl border cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-purple-50 border-purple-500 ring-1 ring-purple-500'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded flex items-center justify-center border ${
                        isSelected ? 'bg-purple-600 border-purple-600 text-white' : 'border-slate-300 bg-white'
                      }`}
                    >
                      {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                    <span className="text-xs font-semibold text-slate-800">{act}</span>
                  </label>
                );
              })}
            </div>
          </div>

          {/* Output Hal yang Dipelajari */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1">
              Output / Hal yang Dipelajari Hari Ini (Wajib - Min 10 Karakter):
            </label>
            <textarea
              rows={2}
              value={outputDescription}
              onChange={(e) => setOutputDescription(e.target.value)}
              placeholder="Contoh: Menyelesaikan 15 soal fisika fluida dinamis & merangkum bab 3 sejarah"
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-purple-500"
              required
            />
            <span className="text-[10px] text-slate-400 block mt-0.5">
              {outputDescription.length >= 10
                ? '✓ Akuntabilitas spesifik (+10 Poin penuh)'
                : outputDescription.length > 0
                ? 'Terlalu singkat (< 10 karakter, hanya +5 poin)'
                : 'Kosong (0 poin)'}
            </span>
          </div>

          {/* Footer inside form */}
          <div className="pt-2 flex items-center justify-between border-t border-slate-100">
            <div>
              <span className="text-[10px] text-slate-400 font-bold block">Proyeksi Skor Diperoleh:</span>
              <span className="text-base font-black text-purple-600">
                {currentScore} / 100 pt
              </span>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={onCancel}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl text-xs font-black text-white bg-purple-600 hover:bg-purple-700 shadow-sm transition-all cursor-pointer"
              >
                Simpan &amp; Konfirmasi
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* FULL-SCREEN HONESTY CONFIRMATION MODAL WITH COMPLETE BLUR */}
      {showHonestyModal && (
        <div className="honesty-backdrop-blur">
          <div className="bg-white rounded-3xl p-6 sm:p-7 max-w-md w-full shadow-2xl border border-slate-200 space-y-4 text-center">
            <div className="w-14 h-14 rounded-2xl bg-purple-100 text-purple-600 flex items-center justify-center mx-auto shadow-inner">
              <ShieldCheck className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-lg font-black text-slate-900 tracking-tight">
                Pernyataan Kejujuran Belajar
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Karakter Jawara SMAN 28 dibentuk dari kejujuran dan tanggung jawab pribadi.
              </p>
            </div>

            <div className="p-3.5 bg-purple-50/70 border border-purple-200 rounded-xl text-xs text-purple-950 font-medium text-left">
              "Saya menyatakan dengan sejujur-jujurnya bahwa saya benar telah melakukan aktivitas belajar mandiri dengan output: '{outputDescription}'."
            </div>

            <div className="flex items-center justify-between text-xs font-bold text-slate-700 px-2">
              <span>Poin Dicatat:</span>
              <span className="text-purple-600 text-base">{currentScore} Poin</span>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowHonestyModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Koreksi
              </button>
              <button
                type="button"
                onClick={handleConfirmHonesty}
                className="flex-1 py-2.5 rounded-xl bg-[#19ae5d] hover:bg-emerald-700 text-white text-xs font-black shadow-sm cursor-pointer"
              >
                Saya Benar Mengisi Ini Jujur
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
