/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Form Makan Bergizi SMAN 28 Jakarta (4-Page Wizard):
 * Page 1: Deteksi waktu makan otomatis, status sesi harian (Sarapan/Siang/Malam), deteksi terlewat merah (-5 pt)
 * Page 2: Kelengkapan Gizi Isi Piringku (Karbo, Lauk, Sayur, Buah) & Menu opsional
 * Page 3: Asupan air minum (>=2 gelas, 1 gelas, 0/manis)
 * Page 4: Adiwiyata Eco Mandiri (Kotak makan + Tumbler) & Konfirmasi
 * Kontainer 1 screen (max-h-[90vh]), scrollable body, full-screen blur backdrop
 */

import React, { useState, useEffect } from 'react';
import {
  Utensils,
  Droplets,
  Check,
  Apple,
  Carrot,
  Wheat,
  Drumstick,
  Clock,
  ShieldCheck,
  Leaf,
  Calendar,
  ChevronRight,
  ChevronLeft,
  AlertCircle,
  Sparkles,
} from 'lucide-react';
import { calculateSingleMealScore } from '../../utils/scoring';
import { timeToMinutes } from '../../utils/timeClassifier';

interface MakanBergiziFormProps {
  onSuccess: (score: number, payload: any, isCounter?: boolean, subCategory?: string) => void;
  onCancel: () => void;
  todayLogs?: any[];
}

export const MakanBergiziForm: React.FC<MakanBergiziFormProps> = ({
  onSuccess,
  onCancel,
  todayLogs = [],
}) => {
  const [currentPage, setCurrentPage] = useState<1 | 2 | 3 | 4>(1);
  const [currentTimeStr, setCurrentTimeStr] = useState('');
  const [currentMinutes, setCurrentMinutes] = useState(0);
  const [selectedMeal, setSelectedMeal] = useState<'sarapan' | 'siang' | 'malam'>('siang');
  const [isMissedMeal, setIsMissedMeal] = useState(false);
  const [isPuasa, setIsPuasa] = useState(false);

  // Nutrition state
  const [gizi, setGizi] = useState({
    karbo: true,
    lauk: true,
    sayur: false,
    buah: false,
  });
  const [menuDescription, setMenuDescription] = useState('');

  // Water state
  const [waterGlasses, setWaterGlasses] = useState<'>=2' | '1' | '0_manis'>('>=2');

  // Eco state
  const [kotakMakanEco, setKotakMakanEco] = useState(false);
  const [tumblerEco, setTumblerEco] = useState(false);

  const [showHonestyModal, setShowHonestyModal] = useState(false);

  // Prevent background scrolling
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  // Update clock & auto detect current meal time
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hh = String(now.getHours()).padStart(2, '0');
      const mm = String(now.getMinutes()).padStart(2, '0');
      const timeStr = `${hh}:${mm}`;
      const min = timeToMinutes(timeStr);
      setCurrentTimeStr(timeStr);
      setCurrentMinutes(min);

      // Sesi makan:
      // Sarapan: 06.00 - 08.00 (min 360 - 480)
      // Siang: 11.30 - 13.00 (min 690 - 780)
      // Malam: 18.00 - 19.30 (min 1080 - 1170)
      if (min < 600) {
        setSelectedMeal('sarapan');
      } else if (min >= 600 && min < 960) {
        setSelectedMeal('siang');
      } else {
        setSelectedMeal('malam');
      }
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Check existing meal logs for today
  const completedMealsMap: Record<string, any> = {};
  todayLogs.forEach((log) => {
    if (log.sub_category) {
      completedMealsMap[log.sub_category.toLowerCase()] = log;
    }
  });

  // 3 Meal Sessions config
  const MEAL_SESSIONS: {
    key: 'sarapan' | 'siang' | 'malam';
    label: string;
    timeRange: string;
    startMin: number;
    endMin: number;
  }[] = [
    { key: 'sarapan', label: 'Sarapan Pagi', timeRange: '06.00 – 08.00 WIB', startMin: 360, endMin: 480 },
    { key: 'siang', label: 'Makan Siang', timeRange: '11.30 – 13.00 WIB', startMin: 690, endMin: 780 },
    { key: 'malam', label: 'Makan Malam', timeRange: '18.00 – 19.30 WIB', startMin: 1080, endMin: 1170 },
  ];

  // Helper to determine status of each session card
  const getMealSessionStatus = (session: typeof MEAL_SESSIONS[0]) => {
    if (completedMealsMap[session.key]) {
      return { status: 'done', score: completedMealsMap[session.key].score };
    }

    // If current time is past the end of the session, it's missed (RED)
    if (currentMinutes > session.endMin) {
      return { status: 'missed', score: null };
    }

    // If currently inside or close to window
    if (currentMinutes >= session.startMin && currentMinutes <= session.endMin) {
      return { status: 'active', score: null };
    }

    return { status: 'upcoming', score: null };
  };

  const toggleGizi = (k: keyof typeof gizi) => {
    setGizi((prev) => ({ ...prev, [k]: !prev[k] }));
  };

  const currentScore = calculateSingleMealScore({
    mealType: selectedMeal,
    timeStr: currentTimeStr,
    isPuasa,
    hasKarbo: gizi.karbo,
    hasLauk: gizi.lauk,
    hasSayur: gizi.sayur,
    hasBuah: gizi.buah,
    waterGlasses,
    kotakMakanEco,
    tumblerEco,
    isMissed: isMissedMeal,
  });

  const handleSelectMealSession = (key: 'sarapan' | 'siang' | 'malam', missed: boolean) => {
    setSelectedMeal(key);
    setIsMissedMeal(missed);
    setCurrentPage(2);
  };

  const handleConfirmHonesty = () => {
    setShowHonestyModal(false);
    onSuccess(
      currentScore,
      {
        mealType: selectedMeal,
        isPuasa,
        gizi,
        waterGlasses,
        kotakMakanEco,
        tumblerEco,
        menuDescription,
        timeRecorded: currentTimeStr,
        isMissed: isMissedMeal,
        timestamp: new Date().toLocaleTimeString('id-ID'),
      },
      true,
      selectedMeal
    );
  };

  return (
    <div className="modal-backdrop-blur">
      <div className="w-full max-w-lg max-h-[90vh] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200">
        {/* Header with Step Progress */}
        <div className="flex-shrink-0 px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-amber-50/80 to-white">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center shadow-xs">
              <Utensils className="w-5 h-5 fill-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-black uppercase tracking-wider text-amber-600">
                  Makan Bergizi • Halaman {currentPage} dari 4
                </span>
                <span className="w-1 h-1 rounded-full bg-amber-400" />
                <span className="text-[10px] font-bold text-slate-500">
                  {selectedMeal.toUpperCase()}
                </span>
              </div>
              <h3 className="font-extrabold text-slate-900 text-base leading-tight">
                {currentPage === 1 && 'Sesi Makan & Waktu Realtime'}
                {currentPage === 2 && 'Kelengkapan Gizi Isi Piringku'}
                {currentPage === 3 && 'Asupan Air Minum Pendamping'}
                {currentPage === 4 && 'Adiwiyata Ramah Lingkungan'}
              </h3>
            </div>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 font-bold flex items-center justify-center cursor-pointer transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Step Progress Dots */}
        <div className="flex-shrink-0 px-6 pt-3 flex gap-1.5">
          {[1, 2, 3, 4].map((step) => (
            <div
              key={step}
              className={`h-1.5 flex-1 rounded-full transition-all ${
                step === currentPage
                  ? 'bg-amber-500'
                  : step < currentPage
                  ? 'bg-emerald-500'
                  : 'bg-slate-200'
              }`}
            />
          ))}
        </div>

        {/* Body - Scrollable content per page */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          {/* PAGE 1: SESI MAKAN & WAKTU */}
          {currentPage === 1 && (
            <div className="space-y-4">
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-500" />
                  <div>
                    <span className="text-[10px] text-slate-500 font-bold block">Stempel Jam Sekarang:</span>
                    <span className="text-sm font-mono font-black text-slate-900">{currentTimeStr} WIB</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-bold text-slate-500 block">Sesi Terdeteksi:</span>
                  <span className="text-xs font-black text-amber-600 uppercase">
                    {selectedMeal}
                  </span>
                </div>
              </div>

              {/* Opsi Puasa Checkbox */}
              <label className="p-3 bg-amber-50/70 border border-amber-200 rounded-2xl flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isPuasa}
                  onChange={(e) => setIsPuasa(e.target.checked)}
                  className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
                />
                <div className="text-xs">
                  <span className="font-extrabold text-amber-950 block">
                    Saya Sedang Berpuasa Hari Ini (Sahur &amp; Berbuka)
                  </span>
                  <span className="text-[11px] text-amber-800">
                    Kombinasi penilaian disesuaikan untuk menu sahur dan berbuka.
                  </span>
                </div>
              </label>

              {/* 3 Meal Cards */}
              <div className="space-y-2.5">
                <h4 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider">
                  3 Sesi Makan Harian Siswa
                </h4>

                {MEAL_SESSIONS.map((session) => {
                  const status = getMealSessionStatus(session);
                  return (
                    <div
                      key={session.key}
                      className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                        status.status === 'done'
                          ? 'bg-emerald-50/80 border-emerald-200'
                          : status.status === 'active'
                          ? 'bg-amber-50/80 border-amber-400 ring-1 ring-amber-400/40 shadow-xs'
                          : status.status === 'missed'
                          ? 'bg-red-50/80 border-red-200'
                          : 'bg-slate-50 border-slate-200 opacity-60'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs ${
                            status.status === 'done'
                              ? 'bg-[#19ae5d] text-white'
                              : status.status === 'active'
                              ? 'bg-amber-500 text-white'
                              : status.status === 'missed'
                              ? 'bg-[#fc351c] text-white'
                              : 'bg-slate-300 text-slate-600'
                          }`}
                        >
                          {status.status === 'done' ? (
                            <Check className="w-4 h-4" />
                          ) : (
                            <Clock className="w-4 h-4" />
                          )}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-extrabold text-slate-900 text-sm">
                              {session.label}
                            </span>
                            <span className="text-[11px] text-slate-500 font-medium">
                              ({session.timeRange})
                            </span>
                          </div>
                          <span className="text-[10px] font-semibold block mt-0.5">
                            {status.status === 'done' && (
                              <span className="text-[#19ae5d]">✓ Sudah diisi • Skor: {status.score} pt</span>
                            )}
                            {status.status === 'active' && (
                              <span className="text-amber-700">Waktu makan saat ini • Tepat Waktu (+15 pt)</span>
                            )}
                            {status.status === 'missed' && (
                              <span className="text-[#fc351c]">Terlewat / Belum diisi • Pengurangan penalti -5 pt</span>
                            )}
                            {status.status === 'upcoming' && (
                              <span className="text-slate-400">Belum masuk waktu sesi</span>
                            )}
                          </span>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="shrink-0">
                        {status.status === 'done' && (
                          <span className="text-xs font-black text-[#19ae5d] bg-emerald-100 px-2.5 py-1 rounded-lg">
                            Tersimpan
                          </span>
                        )}

                        {status.status === 'active' && (
                          <button
                            type="button"
                            onClick={() => handleSelectMealSession(session.key, false)}
                            className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer"
                          >
                            Isi Sekarang →
                          </button>
                        )}

                        {status.status === 'missed' && (
                          <button
                            type="button"
                            onClick={() => handleSelectMealSession(session.key, true)}
                            className="px-3 py-1.5 bg-[#fc351c] hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer"
                          >
                            Isi Terlewat (-5 pt)
                          </button>
                        )}

                        {status.status === 'upcoming' && (
                          <button
                            type="button"
                            onClick={() => handleSelectMealSession(session.key, false)}
                            className="px-2.5 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-600 font-bold text-xs rounded-xl cursor-pointer"
                          >
                            Pilih Sesi
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* PAGE 2: KELENGKAPAN GIZI ISI PIRINGKU */}
          {currentPage === 2 && (
            <div className="space-y-4">
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl flex items-center justify-between text-xs text-amber-900 font-medium">
                <span>Panduan Gizi Seimbang: <strong>Isi Piringku (Maks 40 Poin)</strong></span>
                <span className="font-black text-amber-700">
                  {(gizi.karbo ? 10 : 0) + (gizi.lauk ? 10 : 0) + (gizi.sayur ? 10 : 0) + (gizi.buah ? 10 : 0)} / 40 pt
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => toggleGizi('karbo')}
                  className={`p-3.5 rounded-2xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    gizi.karbo ? 'bg-amber-50 border-amber-500 ring-1 ring-amber-500' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <Wheat className={`w-5 h-5 ${gizi.karbo ? 'text-amber-600' : 'text-slate-400'}`} />
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-white text-slate-600">10 pt</span>
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">Karbohidrat</span>
                    <span className="text-[10px] text-slate-500">Nasi, jagung, roti, ubi</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => toggleGizi('lauk')}
                  className={`p-3.5 rounded-2xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    gizi.lauk ? 'bg-amber-50 border-amber-500 ring-1 ring-amber-500' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <Drumstick className={`w-5 h-5 ${gizi.lauk ? 'text-amber-600' : 'text-slate-400'}`} />
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-white text-slate-600">10 pt</span>
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">Lauk Pauk</span>
                    <span className="text-[10px] text-slate-500">Ayam, ikan, telur, tahu, tempe</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => toggleGizi('sayur')}
                  className={`p-3.5 rounded-2xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    gizi.sayur ? 'bg-emerald-50 border-emerald-500 ring-1 ring-emerald-500' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <Carrot className={`w-5 h-5 ${gizi.sayur ? 'text-emerald-600' : 'text-slate-400'}`} />
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-white text-emerald-700">10 pt</span>
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">Sayur-sayuran</span>
                    <span className="text-[10px] text-slate-500">Bayam, kangkung, wortel, brokoli</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => toggleGizi('buah')}
                  className={`p-3.5 rounded-2xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    gizi.buah ? 'bg-emerald-50 border-emerald-500 ring-1 ring-emerald-500' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <Apple className={`w-5 h-5 ${gizi.buah ? 'text-emerald-600' : 'text-slate-400'}`} />
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-white text-emerald-700">10 pt</span>
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">Buah-buahan</span>
                    <span className="text-[10px] text-slate-500">Pisang, apel, jeruk, pepaya</span>
                  </div>
                </button>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Menu Makanan Hari Ini (Opsional):
                </label>
                <input
                  type="text"
                  value={menuDescription}
                  onChange={(e) => setMenuDescription(e.target.value)}
                  placeholder="Contoh: Nasi merah, dada ayam bakar, sayur bayam, pisang barangan"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>
            </div>
          )}

          {/* PAGE 3: ASUPAN AIR MINUM */}
          {currentPage === 3 && (
            <div className="space-y-4">
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-2xl flex items-center justify-between text-xs text-blue-900 font-medium">
                <span>Target Ideal Pendamping Makan: <strong>Minimal 2 Gelas (±500 ml)</strong></span>
                <span className="font-black text-[#1c5ddc]">
                  {waterGlasses === '>=2' ? '15 pt' : waterGlasses === '1' ? '5 pt' : '0 pt'}
                </span>
              </div>

              <div className="space-y-2.5">
                {[
                  {
                    val: '>=2',
                    label: '≥ 2 Gelas (±500 ml) atau Lebih',
                    score: 15,
                    desc: 'Target ideal pendamping makan sehat & hidrasi optimal',
                  },
                  {
                    val: '1',
                    label: '1 Gelas (±250 ml)',
                    score: 5,
                    desc: 'Cukup, disarankan menambah asupan air setelah jeda makan',
                  },
                  {
                    val: '0_manis',
                    label: '0 Gelas / Minuman Manis Berperisa',
                    score: 0,
                    desc: 'Gula berlebih tidak direkomendasikan dalam pola 7 KAIH SMAN 28',
                  },
                ].map((item) => (
                  <label
                    key={item.val}
                    className={`p-3.5 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ${
                      waterGlasses === item.val
                        ? 'bg-blue-50 border-[#1c5ddc] ring-1 ring-[#1c5ddc]'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="water_glasses"
                        checked={waterGlasses === item.val}
                        onChange={() => setWaterGlasses(item.val as any)}
                        className="w-4 h-4 text-[#1c5ddc] focus:ring-[#1c5ddc]"
                      />
                      <div>
                        <span className="text-xs font-bold text-slate-900 block">{item.label}</span>
                        <span className="text-[11px] text-slate-500">{item.desc}</span>
                      </div>
                    </div>
                    <span className="text-xs font-black text-[#1c5ddc]">+{item.score} pt</span>
                  </label>
                ))}
              </div>
            </div>
          )}

          {/* PAGE 4: ADIWIYATA ECO MANDIRI & SUMMARY */}
          {currentPage === 4 && (
            <div className="space-y-4">
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center justify-between text-xs text-emerald-900 font-medium">
                <span>Inisiatif Ramah Lingkungan: <strong>SMAN 28 Adiwiyata Mandiri</strong></span>
                <span className="font-black text-[#19ae5d]">
                  {(kotakMakanEco ? 5 : 0) + (tumblerEco ? 5 : 0)} / 10 pt
                </span>
              </div>

              <div className="space-y-2.5">
                <label className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50 flex items-center justify-between cursor-pointer">
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      checked={kotakMakanEco}
                      onChange={(e) => setKotakMakanEco(e.target.checked)}
                      className="w-4 h-4 rounded text-[#19ae5d] focus:ring-[#19ae5d]"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">
                        Membawa &amp; Memakai Kotak Makan Sendiri
                      </span>
                      <span className="text-[11px] text-slate-500">
                        Mengurangi sampah plastik / styrofoam sekali pakai di kantin 28
                      </span>
                    </div>
                  </div>
                  <span className="text-xs font-black text-[#19ae5d]">+5 pt</span>
                </label>

                <label className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50 flex items-center justify-between cursor-pointer">
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      checked={tumblerEco}
                      onChange={(e) => setTumblerEco(e.target.checked)}
                      className="w-4 h-4 rounded text-[#19ae5d] focus:ring-[#19ae5d]"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">
                        Membawa Tumbler / Botol Minum Sendiri
                      </span>
                      <span className="text-[11px] text-slate-500">
                        Mendukung stasiun isi ulang air minum higienis SMAN 28
                      </span>
                    </div>
                  </div>
                  <span className="text-xs font-black text-[#19ae5d]">+5 pt</span>
                </label>
              </div>

              {/* Score Projection Card */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 text-white shadow-md flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-amber-100 block">
                    Proyeksi Skor Sesi {selectedMeal.toUpperCase()}:
                  </span>
                  <span className="text-2xl font-black">{currentScore} / 100 pt</span>
                  {isMissedMeal && (
                    <span className="text-[10px] bg-red-600 text-white px-2 py-0.5 rounded-full block w-fit mt-1">
                      Termasuk penalti -5 pt (Terlewat)
                    </span>
                  )}
                </div>
                <Sparkles className="w-8 h-8 text-amber-200" />
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        <div className="flex-shrink-0 px-6 py-3.5 border-t border-slate-100 bg-slate-50/80 flex items-center justify-between">
          <div>
            {currentPage > 1 ? (
              <button
                type="button"
                onClick={() => setCurrentPage((p) => (p - 1) as any)}
                className="px-3.5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl cursor-pointer flex items-center gap-1"
              >
                <ChevronLeft className="w-3.5 h-3.5" /> Kembali
              </button>
            ) : (
              <button
                type="button"
                onClick={onCancel}
                className="px-3.5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
              >
                Batal
              </button>
            )}
          </div>

          <div>
            {currentPage < 4 ? (
              <button
                type="button"
                onClick={() => setCurrentPage((p) => (p + 1) as any)}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer flex items-center gap-1"
              >
                Lanjut <ChevronRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setShowHonestyModal(true)}
                className="px-5 py-2 bg-[#19ae5d] hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-md cursor-pointer flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" /> Simpan &amp; Konfirmasi
              </button>
            )}
          </div>
        </div>
      </div>

      {/* FULL-SCREEN HONESTY CONFIRMATION MODAL WITH COMPLETE BLUR */}
      {showHonestyModal && (
        <div className="honesty-backdrop-blur">
          <div className="bg-white rounded-3xl p-6 sm:p-7 max-w-md w-full shadow-2xl border border-slate-200 space-y-4 text-center">
            <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center mx-auto shadow-inner">
              <ShieldCheck className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-lg font-black text-slate-900 tracking-tight">
                Pernyataan Kejujuran Siswa
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Karakter Jawara SMAN 28 dibentuk dari kejujuran dan tanggung jawab pribadi.
              </p>
            </div>

            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-700 italic leading-relaxed text-left">
              "Saya menyatakan dengan sejujur-jujurnya bahwa data makan bergizi sesi {selectedMeal.toUpperCase()} ({currentTimeStr} WIB) ini diisi secara benar dan dapat dipertanggungjawabkan."
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowHonestyModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 font-bold text-xs hover:bg-slate-100 cursor-pointer"
              >
                Kembali / Koreksi
              </button>
              <button
                type="button"
                onClick={handleConfirmHonesty}
                className="flex-1 py-2.5 rounded-xl bg-[#19ae5d] hover:bg-emerald-700 text-white font-extrabold text-xs shadow-md cursor-pointer"
              >
                Saya Benar Mengisi Ini Jujur
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
