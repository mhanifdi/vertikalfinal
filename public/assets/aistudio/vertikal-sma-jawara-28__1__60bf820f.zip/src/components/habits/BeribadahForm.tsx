/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Form Beribadah SMAN 28 Jakarta (Islam, Kristen/Katolik, Hindu)
 * - Otomatis mendeteksi agama dari database siswa (tanpa tab manual)
 * - Menampilkan jam real-time & shalat yang sedang aktif (lewat berapa menit)
 * - 5 Card Shalat: Hijau (sudah diisi), Merah (terlewat), Aktif (bisa diisi sekarang), Abu-abu (belum waktunya)
 * - Formula toleransi: (Tsisa / Ttotal) * 100 dengan cap max 100, min 50
 * - Anti-overwhelm: Kontainer 1 screen (max-h-[90vh]), scrollable body, full-screen blur backdrop
 */

import React, { useState, useEffect } from 'react';
import {
  Heart,
  Check,
  Clock,
  ShieldCheck,
  BookOpen,
  Calendar,
  AlertCircle,
  Sparkles,
  Lock,
} from 'lucide-react';
import {
  calculateIslamScore,
  calculateKristenScore,
  calculateHinduScore,
  calculateShalatScoreDetailed,
} from '../../utils/scoring';
import { PRAYER_SCHEDULE, SCORING_RULES } from '../../config/scoringConfig';
import { timeToMinutes } from '../../utils/timeClassifier';

interface BeribadahFormProps {
  studentReligion?: string;
  studentGender?: string;
  todayLogs?: any[];
  onSuccess: (score: number, payload: any, isCounter?: boolean, subCategory?: string) => void;
  onCancel: () => void;
}

export const BeribadahForm: React.FC<BeribadahFormProps> = ({
  studentReligion = 'Islam',
  studentGender = 'L',
  todayLogs = [],
  onSuccess,
  onCancel,
}) => {
  // Normalize religion
  const isIslam = !studentReligion || studentReligion.toLowerCase().includes('islam');
  const isKristen = studentReligion?.toLowerCase().includes('kristen') || studentReligion?.toLowerCase().includes('katolik');
  const isHindu = studentReligion?.toLowerCase().includes('hindu');

  const [currentTimeStr, setCurrentTimeStr] = useState('');
  const [currentMinutes, setCurrentMinutes] = useState(0);
  const [showHonestyModal, setShowHonestyModal] = useState(false);
  const [pendingSubmission, setPendingSubmission] = useState<{
    score: number;
    payload: any;
    subCategory?: string;
  } | null>(null);

  // Islam State
  const [isHalangan, setIsHalangan] = useState(false);
  const [activePrayerKey, setActivePrayerKey] = useState<'subuh' | 'zuhur' | 'asar' | 'magrib' | 'isya'>('zuhur');
  const [quranPages, setQuranPages] = useState<number>(0);
  const [surahName, setSurahName] = useState('');

  // Kristen State
  const [kristenNotes, setKristenNotes] = useState<Record<string, string>>({
    bangun: '',
    makan: '',
    pergi: '',
    pulang: '',
    tidur: '',
  });
  const [kristenCompleted, setKristenCompleted] = useState<string[]>([]);
  const [kristenOther, setKristenOther] = useState(false);
  const [kristenOtherText, setKristenOtherText] = useState('');

  // Hindu State
  const [hinduNotes, setHinduNotes] = useState<Record<string, string>>({
    pagi: '',
    siang: '',
    sore: '',
  });
  const [hinduCompleted, setHinduCompleted] = useState<string[]>([]);
  const [hinduOther, setHinduOther] = useState(false);
  const [hinduOtherText, setHinduOtherText] = useState('');

  // Lock body scroll while modal is active
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  // Update clock & active prayer detection
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hh = String(now.getHours()).padStart(2, '0');
      const mm = String(now.getMinutes()).padStart(2, '0');
      const timeStr = `${hh}:${mm}`;
      const min = timeToMinutes(timeStr);
      setCurrentTimeStr(timeStr);
      setCurrentMinutes(min);

      if (min >= 240 && min < 330) {
        setActivePrayerKey('subuh');
      } else if (min >= 700 && min < 895) {
        setActivePrayerKey('zuhur');
      } else if (min >= 895 && min < 1070) {
        setActivePrayerKey('asar');
      } else if (min >= 1070 && min < 1145) {
        setActivePrayerKey('magrib');
      } else {
        setActivePrayerKey('isya');
      }
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Extract completed logs
  const completedPrayersMap: Record<string, any> = {};
  todayLogs.forEach((log) => {
    if (log.sub_category) {
      completedPrayersMap[log.sub_category.toLowerCase()] = log;
    }
    try {
      const p = typeof log.payload === 'string' ? JSON.parse(log.payload) : log.payload;
      if (p?.kristenPrayers) {
        p.kristenPrayers.forEach((k: string) => {
          completedPrayersMap[k.toLowerCase()] = log;
        });
      }
      if (p?.triSandhya) {
        p.triSandhya.forEach((k: string) => {
          completedPrayersMap[k.toLowerCase()] = log;
        });
      }
    } catch {}
  });

  // Prayer list definition
  const PRAYER_LIST: {
    key: 'subuh' | 'zuhur' | 'asar' | 'magrib' | 'isya';
    label: string;
    startMin: number;
    endMin: number;
    timeRange: string;
  }[] = [
    { key: 'subuh', label: 'Subuh', startMin: 240, endMin: 330, timeRange: '04.00 – 05.30 WIB' },
    { key: 'zuhur', label: 'Zuhur', startMin: 700, endMin: 895, timeRange: '11.40 – 14.55 WIB' },
    { key: 'asar', label: 'Asar', startMin: 895, endMin: 1070, timeRange: '14.55 – 17.50 WIB' },
    { key: 'magrib', label: 'Magrib', startMin: 1070, endMin: 1145, timeRange: '17.50 – 19.05 WIB' },
    { key: 'isya', label: 'Isya', startMin: 1145, endMin: 1680, timeRange: '19.05 – 04.00 WIB' },
  ];

  // Helper to determine status of a prayer card:
  // 'done' (green, locked)
  // 'active' (in time window, can check in now)
  // 'missed' (past time window and not done, red, -5 penalty)
  // 'upcoming' (future, gray, cannot check in before time)
  const getPrayerCardStatus = (p: typeof PRAYER_LIST[0]) => {
    if (completedPrayersMap[p.key]) {
      return { status: 'done', score: completedPrayersMap[p.key].score };
    }

    // Check time position
    let userMin = currentMinutes;
    if (p.key === 'isya' && userMin < 240) {
      userMin += 1440; // post midnight
    }

    if (userMin >= p.startMin && userMin <= p.endMin) {
      return { status: 'active', score: null };
    }

    if (userMin > p.endMin) {
      return { status: 'missed', score: null };
    }

    return { status: 'upcoming', score: null };
  };

  // Submit single prayer check-in
  const handlePrayerCheckIn = (
    key: 'subuh' | 'zuhur' | 'asar' | 'magrib' | 'isya',
    isMissed = false
  ) => {
    const calc = calculateShalatScoreDetailed(key, currentTimeStr || '12:00', isMissed);
    setPendingSubmission({
      score: calc.score,
      subCategory: key,
      payload: {
        prayer: key,
        checkInTime: currentTimeStr,
        isMissed,
        menitLewat: calc.menitLewat,
        waktuSisa: calc.waktuSisa,
        waktuToleransi: calc.waktuToleransi,
        formulaText: calc.formulaText,
        timestamp: new Date().toLocaleTimeString('id-ID'),
      },
    });
    setShowHonestyModal(true);
  };

  // Submit halangan (female student excuse)
  const handleSubmitHalangan = () => {
    setPendingSubmission({
      score: 100,
      subCategory: 'halangan',
      payload: {
        isHalangan: true,
        notes: 'Sedang berhalangan (haid) - Sesuai syariat Islam SMAN 28',
        timestamp: new Date().toLocaleTimeString('id-ID'),
      },
    });
    setShowHonestyModal(true);
  };

  // Submit Quran recitation
  const handleSubmitQuran = () => {
    if (quranPages <= 0 && !surahName) return;
    const bonus = quranPages * SCORING_RULES.shalat.quranPageBonus;
    setPendingSubmission({
      score: Math.min(100, bonus),
      subCategory: 'mengaji',
      payload: {
        quranPages,
        surahName,
        bonusScore: bonus,
        timestamp: new Date().toLocaleTimeString('id-ID'),
      },
    });
    setShowHonestyModal(true);
  };

  // Submit Christian Doa Harian
  const handleKristenDoaSubmit = (timeKey: string, isMissed = false) => {
    const note = kristenNotes[timeKey] || 'Doa harian';
    const base = isMissed ? 15 : 20;
    setPendingSubmission({
      score: base,
      subCategory: `kristen_${timeKey}`,
      payload: {
        doaTime: timeKey,
        doaNote: note,
        isMissed,
        timestamp: new Date().toLocaleTimeString('id-ID'),
      },
    });
    setShowHonestyModal(true);
  };

  // Submit Hindu Tri Sandhya
  const handleHinduSandhyaSubmit = (timeKey: string, isMissed = false) => {
    const note = hinduNotes[timeKey] || 'Mantram Puja Tri Sandhya';
    const base = isMissed ? 28.3 : 33.3;
    setPendingSubmission({
      score: Math.round(base * 10) / 10,
      subCategory: `hindu_${timeKey}`,
      payload: {
        sandhyaTime: timeKey,
        sandhyaNote: note,
        isMissed,
        timestamp: new Date().toLocaleTimeString('id-ID'),
      },
    });
    setShowHonestyModal(true);
  };

  const handleConfirmHonesty = () => {
    if (!pendingSubmission) return;
    setShowHonestyModal(false);
    onSuccess(
      pendingSubmission.score,
      pendingSubmission.payload,
      true,
      pendingSubmission.subCategory
    );
  };

  // Current active shalat details
  const currentActivePrayerObj = PRAYER_LIST.find((p) => p.key === activePrayerKey);
  const schedActive = PRAYER_SCHEDULE[activePrayerKey];
  const minutesPastAdzan = Math.max(
    0,
    currentMinutes - timeToMinutes(schedActive?.adzanTime || '12:00')
  );

  return (
    <div className="modal-backdrop-blur">
      <div className="w-full max-w-lg max-h-[90vh] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200">
        {/* Modal Header */}
        <div className="flex-shrink-0 px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-emerald-50/80 to-white">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#19ae5d] text-white flex items-center justify-center shadow-xs">
              <Heart className="w-5 h-5 fill-white" />
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-[#19ae5d]">
                Formulir 7 KAIH • Agama {studentReligion}
              </span>
              <h3 className="font-extrabold text-slate-900 text-base leading-tight">
                {isIslam ? 'Ibadah Shalat 5 Waktu & Mengaji' : isKristen ? 'Ibadah & Doa Harian Kristen' : 'Ibadah & Puja Tri Sandhya Hindu'}
              </h3>
            </div>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 font-bold flex items-center justify-center cursor-pointer transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Modal Body - Scrollable */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          {/* Header Real-time Stempel & Status Waktu */}
          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#19ae5d]" />
              <div>
                <span className="text-[10px] text-slate-500 font-bold block">Stempel Jam Sekarang:</span>
                <span className="text-sm font-mono font-black text-slate-900">{currentTimeStr} WIB</span>
              </div>
            </div>
            {isIslam && currentActivePrayerObj && (
              <div className="text-right">
                <span className="text-[10px] font-bold text-slate-500 block">Waktu Terdeteksi:</span>
                <span className="text-xs font-extrabold text-[#19ae5d]">
                  {currentActivePrayerObj.label} (+{minutesPastAdzan}m dari adzan)
                </span>
              </div>
            )}
          </div>

          {/* ISLAM VIEW */}
          {isIslam && (
            <div className="space-y-4">
              {/* Opsi Berhalangan untuk siswi */}
              {studentGender === 'P' && (
                <div className="p-3 bg-pink-50 border border-pink-200 rounded-2xl flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-pink-900 block">Sedang Berhalangan (Haid)</span>
                    <span className="text-[11px] text-pink-700">Tetap memperoleh poin penuh 100 pt sesuai syariat.</span>
                  </div>
                  <button
                    type="button"
                    onClick={handleSubmitHalangan}
                    className="px-3 py-1.5 rounded-xl bg-pink-600 hover:bg-pink-700 text-white font-bold text-xs cursor-pointer shadow-xs"
                  >
                    Klaim 100 pt
                  </button>
                </div>
              )}

              {/* 5 Shalat Cards */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider">
                    Daftar 5 Waktu Shalat Wajib
                  </h4>
                  <span className="text-[10px] text-slate-400 font-medium">Toleransi 15m • Cap maks 100 pt</span>
                </div>

                {PRAYER_LIST.map((p) => {
                  const card = getPrayerCardStatus(p);
                  return (
                    <div
                      key={p.key}
                      className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                        card.status === 'done'
                          ? 'bg-emerald-50/70 border-emerald-200'
                          : card.status === 'active'
                          ? 'bg-blue-50/80 border-[#1c5ddc] ring-1 ring-[#1c5ddc]/30 shadow-xs'
                          : card.status === 'missed'
                          ? 'bg-red-50/70 border-red-200'
                          : 'bg-slate-50 border-slate-200 opacity-60'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs ${
                            card.status === 'done'
                              ? 'bg-[#19ae5d] text-white'
                              : card.status === 'active'
                              ? 'bg-[#1c5ddc] text-white'
                              : card.status === 'missed'
                              ? 'bg-[#fc351c] text-white'
                              : 'bg-slate-300 text-slate-600'
                          }`}
                        >
                          {card.status === 'done' ? (
                            <Check className="w-4 h-4" />
                          ) : card.status === 'upcoming' ? (
                            <Lock className="w-3.5 h-3.5" />
                          ) : (
                            <Clock className="w-4 h-4" />
                          )}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-extrabold text-slate-900 text-sm">{p.label}</span>
                            <span className="text-[11px] text-slate-500 font-medium">({p.timeRange})</span>
                          </div>
                          <span className="text-[10px] font-semibold block mt-0.5">
                            {card.status === 'done' && (
                              <span className="text-[#19ae5d]">✓ Sudah diisi • Skor: {card.score} pt</span>
                            )}
                            {card.status === 'active' && (
                              <span className="text-[#1c5ddc]">Sedang berlangsung • Siap di-check in</span>
                            )}
                            {card.status === 'missed' && (
                              <span className="text-[#fc351c]">Waktu lewat &amp; belum diisi (Penalti -5 pt)</span>
                            )}
                            {card.status === 'upcoming' && (
                              <span className="text-slate-400">Belum masuk waktu (tidak dapat diisi)</span>
                            )}
                          </span>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="shrink-0">
                        {card.status === 'done' && (
                          <span className="text-xs font-black text-[#19ae5d] bg-emerald-100 px-2.5 py-1 rounded-lg">
                            Terkunci
                          </span>
                        )}

                        {card.status === 'active' && (
                          <button
                            type="button"
                            onClick={() => handlePrayerCheckIn(p.key, false)}
                            className="px-3.5 py-1.5 bg-[#19ae5d] hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer transition-all"
                          >
                            Check-in Sekarang
                          </button>
                        )}

                        {card.status === 'missed' && (
                          <button
                            type="button"
                            onClick={() => handlePrayerCheckIn(p.key, true)}
                            className="px-3 py-1.5 bg-[#fc351c] hover:bg-red-700 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer transition-all"
                          >
                            Isi Terlewat (-5 pt)
                          </button>
                        )}

                        {card.status === 'upcoming' && (
                          <button
                            type="button"
                            disabled
                            className="px-3 py-1.5 bg-slate-200 text-slate-400 rounded-xl text-xs font-bold cursor-not-allowed"
                          >
                            Belum Waktunya
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Mengaji / Murajaah Quran */}
              <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-200 space-y-3">
                <div className="flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-[#19ae5d]" />
                  <span className="text-xs font-extrabold text-slate-900">
                    Mengaji &amp; Murajaah Al-Qur'an (+1 Poin / Halaman)
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <input
                    type="text"
                    value={surahName}
                    onChange={(e) => setSurahName(e.target.value)}
                    placeholder="Nama Surah & Ayat..."
                    className="p-2 bg-white rounded-xl border border-emerald-200 focus:outline-none"
                  />
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min={0}
                      max={604}
                      value={quranPages}
                      onChange={(e) => setQuranPages(Number(e.target.value))}
                      className="w-20 p-2 bg-white rounded-xl border border-emerald-200 font-bold text-center focus:outline-none"
                    />
                    <span className="text-slate-500 font-medium">Halaman</span>
                    <button
                      type="button"
                      onClick={handleSubmitQuran}
                      disabled={quranPages <= 0 && !surahName}
                      className="flex-1 py-2 bg-[#19ae5d] hover:bg-emerald-700 text-white font-bold rounded-xl shadow-xs cursor-pointer disabled:opacity-40"
                    >
                      + Simpan
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* KRISTEN / KATOLIK VIEW */}
          {isKristen && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider">
                  5 Waktu Doa Harian (@ 20 Poin = 100 pt)
                </h4>
                <span className="text-[10px] text-slate-400 font-medium">SMAN 28</span>
              </div>

              {[
                { key: 'bangun', label: 'Doa Bangun Tidur', time: 'Pagi Hari' },
                { key: 'makan', label: 'Doa Saat Makan', time: 'Siang/Malam' },
                { key: 'pergi', label: 'Doa Pergi ke Sekolah', time: 'Pagi Hari' },
                { key: 'pulang', label: 'Doa Pulang Sekolah', time: 'Sore Hari' },
                { key: 'tidur', label: 'Doa Sebelum Tidur', time: 'Malam Hari' },
              ].map((item) => {
                const isDone = !!completedPrayersMap[`kristen_${item.key}`];
                return (
                  <div
                    key={item.key}
                    className={`p-3.5 rounded-2xl border transition-all ${
                      isDone ? 'bg-emerald-50 border-emerald-200' : 'bg-white border-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-lg bg-blue-100 text-[#1c5ddc] flex items-center justify-center font-bold text-xs">
                          {isDone ? '✓' : '+20'}
                        </span>
                        <div>
                          <span className="font-extrabold text-slate-900 text-xs block">{item.label}</span>
                          <span className="text-[10px] text-slate-400">{item.time}</span>
                        </div>
                      </div>
                      {isDone ? (
                        <span className="text-xs font-bold text-[#19ae5d]">Sudah Diisi</span>
                      ) : (
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleKristenDoaSubmit(item.key, true)}
                            className="px-2 py-1 rounded-lg text-[10px] font-bold bg-red-100 text-red-700 hover:bg-red-200 cursor-pointer"
                          >
                            Susulan (-5)
                          </button>
                          <button
                            type="button"
                            onClick={() => handleKristenDoaSubmit(item.key, false)}
                            className="px-3 py-1 rounded-lg text-xs font-bold bg-[#1c5ddc] text-white hover:bg-blue-700 cursor-pointer shadow-xs"
                          >
                            Check-in (+20)
                          </button>
                        </div>
                      )}
                    </div>
                    {!isDone && (
                      <input
                        type="text"
                        value={kristenNotes[item.key] || ''}
                        onChange={(e) =>
                          setKristenNotes((prev) => ({ ...prev, [item.key]: e.target.value }))
                        }
                        placeholder="Tuliskan catatan / isi doa singkat..."
                        className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                      />
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* HINDU VIEW */}
          {isHindu && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider">
                  Puja Tri Sandhya 3 Waktu (@ 33.3 Poin = 100 pt)
                </h4>
                <span className="text-[10px] text-slate-400 font-medium">SMAN 28</span>
              </div>

              {[
                { key: 'pagi', label: 'Tri Sandhya Pagi', time: '06.00 WIB' },
                { key: 'siang', label: 'Tri Sandhya Siang', time: '12.00 WIB' },
                { key: 'sore', label: 'Tri Sandhya Sore', time: '18.00 WIB' },
              ].map((item) => {
                const isDone = !!completedPrayersMap[`hindu_${item.key}`];
                return (
                  <div
                    key={item.key}
                    className={`p-3.5 rounded-2xl border transition-all ${
                      isDone ? 'bg-emerald-50 border-emerald-200' : 'bg-white border-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center font-bold text-xs">
                          {isDone ? '✓' : '+33'}
                        </span>
                        <div>
                          <span className="font-extrabold text-slate-900 text-xs block">{item.label}</span>
                          <span className="text-[10px] text-slate-400">{item.time}</span>
                        </div>
                      </div>
                      {isDone ? (
                        <span className="text-xs font-bold text-[#19ae5d]">Sudah Diisi</span>
                      ) : (
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleHinduSandhyaSubmit(item.key, true)}
                            className="px-2 py-1 rounded-lg text-[10px] font-bold bg-red-100 text-red-700 hover:bg-red-200 cursor-pointer"
                          >
                            Susulan (-5)
                          </button>
                          <button
                            type="button"
                            onClick={() => handleHinduSandhyaSubmit(item.key, false)}
                            className="px-3 py-1 rounded-lg text-xs font-bold bg-amber-600 text-white hover:bg-amber-700 cursor-pointer shadow-xs"
                          >
                            Check-in (+33.3)
                          </button>
                        </div>
                      )}
                    </div>
                    {!isDone && (
                      <input
                        type="text"
                        value={hinduNotes[item.key] || ''}
                        onChange={(e) =>
                          setHinduNotes((prev) => ({ ...prev, [item.key]: e.target.value }))
                        }
                        placeholder="Tuliskan bait Mantram / doa Tri Sandhya..."
                        className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                      />
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex-shrink-0 px-6 py-3 border-t border-slate-100 bg-slate-50/80 flex items-center justify-between">
          <span className="text-[11px] text-slate-500 font-medium">
            Rerata shalat dihitung otomatis dari 5 waktu shalat.
          </span>
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>

      {/* FULL-SCREEN HONESTY CONFIRMATION MODAL WITH COMPLETE BLUR (NO LEAKS) */}
      {showHonestyModal && (
        <div className="honesty-backdrop-blur">
          <div className="bg-white rounded-3xl p-6 sm:p-7 max-w-md w-full shadow-2xl border border-slate-200 space-y-4 text-center">
            <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-[#19ae5d] flex items-center justify-center mx-auto shadow-inner">
              <ShieldCheck className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-lg font-black text-slate-900 tracking-tight">
                Pernyataan Kejujuran Siswa
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Karakter Jawara SMAN 28 dibentuk dari kejujuran dan tanggung jawab pribadi di hadapan Tuhan Yang Maha Esa.
              </p>
            </div>

            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-700 italic leading-relaxed text-left">
              "Saya menyatakan dengan sejujur-jujurnya bahwa data ibadah ini ({pendingSubmission?.subCategory?.toUpperCase()}) diisi secara benar dan dapat dipertanggungjawabkan."
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowHonestyModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 font-bold text-xs hover:bg-slate-100 cursor-pointer"
              >
                Kembali / Koreksi
              </button>
              <button
                type="button"
                onClick={handleConfirmHonesty}
                className="flex-1 py-2.5 rounded-xl bg-[#19ae5d] hover:bg-emerald-700 text-white font-extrabold text-xs shadow-md cursor-pointer"
              >
                Saya Benar Mengisi Ini Jujur
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
