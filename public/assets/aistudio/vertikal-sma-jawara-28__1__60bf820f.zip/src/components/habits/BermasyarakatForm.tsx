/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Form Bermasyarakat & Aksi Sosial SMAN 28 Jakarta
 * Skema: Ragam Aksi Sosial (Maks 90 pt) + Piket Adiwiyata (+5 pt) + Kejelasan Deskripsi (Maks 10 pt)
 * Kontainer 1 screen (max-h-[90vh]), scrollable body, full-screen blur backdrop
 */

import React, { useState, useEffect } from 'react';
import { Users, CheckCircle2, Check, Sparkles, Leaf, ShieldCheck } from 'lucide-react';
import { calculateBermasyarakatScore } from '../../utils/scoring';

interface BermasyarakatFormProps {
  onSuccess: (score: number, payload: any) => void;
  onCancel: () => void;
  isAlreadySubmitted?: boolean;
}

export const BermasyarakatForm: React.FC<BermasyarakatFormProps> = ({
  onSuccess,
  onCancel,
  isAlreadySubmitted = false,
}) => {
  const [actions, setActivities] = useState<string[]>(['piket']);
  const [description, setDescription] = useState('');
  const [isMissed, setIsMissed] = useState(false);
  const [showHonestyModal, setShowHonestyModal] = useState(false);

  // Lock scroll
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  const toggleAction = (itemKey: string) => {
    setActivities((prev) =>
      prev.includes(itemKey) ? prev.filter((a) => a !== itemKey) : [...prev, itemKey]
    );
  };

  const currentScore = calculateBermasyarakatScore({
    actions,
    description,
    isMissed,
  });

  const handleTriggerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (actions.length === 0) {
      alert('Pilih minimal satu bentuk aksi bermasyarakat / kepedulian sosial.');
      return;
    }
    setShowHonestyModal(true);
  };

  const handleConfirmHonesty = () => {
    setShowHonestyModal(false);
    onSuccess(currentScore, {
      actions,
      description,
      isMissed,
      timestamp: new Date().toLocaleTimeString('id-ID'),
    });
  };

  return (
    <div className="modal-backdrop-blur">
      <div className="w-full max-w-lg max-h-[90vh] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex-shrink-0 px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-teal-50/80 to-white">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-xs">
              <Users className="w-5 h-5 fill-white" />
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-teal-600">
                Formulir 7 KAIH SMAN 28
              </span>
              <h3 className="font-extrabold text-slate-900 text-base leading-tight">
                Bermasyarakat &amp; Kepedulian Sosial
              </h3>
            </div>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 font-bold flex items-center justify-center cursor-pointer transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleTriggerSubmit} className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          <div className="flex items-center justify-between p-3 bg-teal-50/60 rounded-2xl border border-teal-200">
            <div>
              <span className="text-xs font-bold text-slate-900 block">
                Skor Aksi Sosial (60–90) + Piket (+5) + Deskripsi (10)
              </span>
              <span className="text-[11px] text-slate-500">
                Menumbuhkan empati, gotong royong, dan kepedulian lingkungan
              </span>
            </div>
            <label className="flex items-center gap-2 text-xs font-bold text-teal-700 cursor-pointer bg-white px-2.5 py-1 rounded-xl border border-teal-200 shadow-2xs">
              <input
                type="checkbox"
                checked={isMissed}
                onChange={(e) => setIsMissed(e.target.checked)}
                className="w-4 h-4 text-teal-600 rounded"
              />
              Isi Terlewat (-5 pt)
            </label>
          </div>

          {/* Bentuk Aksi Sosial */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-2">
              Bentuk Aksi Sosial / Bermasyarakat yang Dilakukan (Pilih yang sesuai):
            </label>
            <div className="space-y-2">
              {[
                {
                  key: 'piket',
                  label: 'Piket kelas / menjaga kebersihan lingkungan SMAN 28 (Adiwiyata)',
                  badge: '+Piket Bonus',
                },
                {
                  key: 'bantuTeman',
                  label: 'Membantu teman yang kesulitan belajar / permasalahan di sekolah',
                  badge: 'Solidaritas',
                },
                {
                  key: 'organisasi',
                  label: 'Aktif dalam organisasi sekolah (OSIS, MPK, Ekskul, Kepanitiaan 28)',
                  badge: 'Kepemimpinan',
                },
                {
                  key: 'lingkunganRumah',
                  label: 'Mengikuti kegiatan sosial lingkungan RT/RW / Karang Taruna / Tempat Ibadah',
                  badge: 'Masyarakat',
                },
              ].map((act) => {
                const isSelected = actions.includes(act.key);
                return (
                  <label
                    key={act.key}
                    onClick={() => toggleAction(act.key)}
                    className={`flex items-center justify-between p-3 rounded-2xl border cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-teal-50/80 border-teal-500 ring-1 ring-teal-500'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div
                        className={`w-4 h-4 rounded flex items-center justify-center border ${
                          isSelected ? 'bg-teal-600 border-teal-600 text-white' : 'border-slate-300 bg-white'
                        }`}
                      >
                        {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                      <span className="text-xs font-semibold text-slate-800">{act.label}</span>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-100 text-teal-800 shrink-0 ml-2">
                      {act.badge}
                    </span>
                  </label>
                );
              })}
            </div>
          </div>

          {/* Deskripsi Aksi Sosial */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1">
              Deskripsi Ringkas Kegiatan (Min 10 Karakter untuk Skor Maksimal):
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Contoh: Membersihkan area taman kelas XI-MIPA-1 dan memilah sampah botol plastik"
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
            <span className="text-[10px] text-slate-400 block mt-0.5">
              {description.length >= 10
                ? '✓ Deskripsi jelas & akuntabel (+10 Poin)'
                : description.length > 0
                ? 'Terlalu singkat (< 10 karakter, +5 poin)'
                : 'Kosong (0 poin)'}
            </span>
          </div>

          {/* Footer inside form */}
          <div className="pt-2 flex items-center justify-between border-t border-slate-100">
            <div>
              <span className="text-[10px] text-slate-400 font-bold block">Proyeksi Skor Diperoleh:</span>
              <span className="text-base font-black text-teal-600">
                {currentScore} / 100 pt
              </span>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={onCancel}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl text-xs font-black text-white bg-teal-600 hover:bg-teal-700 shadow-sm transition-all cursor-pointer"
              >
                Simpan &amp; Konfirmasi
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* FULL-SCREEN HONESTY CONFIRMATION MODAL WITH COMPLETE BLUR */}
      {showHonestyModal && (
        <div className="honesty-backdrop-blur">
          <div className="bg-white rounded-3xl p-6 sm:p-7 max-w-md w-full shadow-2xl border border-slate-200 space-y-4 text-center">
            <div className="w-14 h-14 rounded-2xl bg-teal-100 text-teal-600 flex items-center justify-center mx-auto shadow-inner">
              <ShieldCheck className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-lg font-black text-slate-900 tracking-tight">
                Pernyataan Kejujuran Aksi Sosial
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Karakter Jawara SMAN 28 dibentuk dari kejujuran dan tanggung jawab pribadi.
              </p>
            </div>

            <div className="p-3.5 bg-teal-50/70 border border-teal-200 rounded-xl text-xs text-teal-950 font-medium text-left">
              "Saya menyatakan dengan sejujur-jujurnya bahwa saya benar telah melakukan kegiatan aksi sosial bermasyarakat: '{description}'."
            </div>

            <div className="flex items-center justify-between text-xs font-bold text-slate-700 px-2">
              <span>Poin Dicatat:</span>
              <span className="text-teal-600 text-base">{currentScore} Poin</span>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowHonestyModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Koreksi
              </button>
              <button
                type="button"
                onClick={handleConfirmHonesty}
                className="flex-1 py-2.5 rounded-xl bg-[#19ae5d] hover:bg-emerald-700 text-white text-xs font-black shadow-sm cursor-pointer"
              >
                Saya Benar Mengisi Ini Jujur
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
