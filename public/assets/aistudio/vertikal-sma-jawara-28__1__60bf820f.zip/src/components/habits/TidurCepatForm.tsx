/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Form Tidur Cepat SMAN 28 Jakarta
 * Skema: Waktu Tidur (Maks 75 pt) + Eco-Friendly Matikan Lampu (+5 pt) + Kualitas Tidur (Maks 25 pt)
 * Termasuk Fitur Stempel Waktu (Timestamp) Langsung & Mode Terlewat (-5 pt)
 * Kontainer 1 screen (max-h-[90vh]), scrollable body, full-screen blur backdrop
 */

import React, { useState, useEffect } from 'react';
import { Moon, CheckCircle2, BedDouble, AlertCircle, ShieldCheck, Clock, Lightbulb, Calendar } from 'lucide-react';
import { calculateTidurCepatScore, classifyTidurTime } from '../../utils/scoring';

interface TidurCepatFormProps {
  onSuccess: (score: number, payload: any) => void;
  onCancel: () => void;
  isAlreadySubmitted?: boolean;
}

export const TidurCepatForm: React.FC<TidurCepatFormProps> = ({
  onSuccess,
  onCancel,
  isAlreadySubmitted = false,
}) => {
  const [entryMode, setEntryMode] = useState<'realtime' | 'terlewat'>('realtime');
  const [currentTimeStr, setCurrentTimeStr] = useState('');
  const [bedtimeSlot, setBedtimeSlot] = useState<'<21.30' | '21.30-22.30' | '22.31-23.30' | '>23.30'>('21.30-22.30');
  const [sleepQuality, setSleepQuality] = useState<number>(5);
  const [turnOffLightsEco, setTurnOffLightsEco] = useState(true);
  const [lateReason, setLateReason] = useState<string>('Tidak Begadang / Tepat Waktu');
  const [reflection, setReflection] = useState('');
  const [showHonestyModal, setShowHonestyModal] = useState(false);

  // Lock scroll
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  // Live clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hh = String(now.getHours()).padStart(2, '0');
      const mm = String(now.getMinutes()).padStart(2, '0');
      const timeStr = `${hh}:${mm}`;
      setCurrentTimeStr(timeStr);
      if (entryMode === 'realtime') {
        const detected = classifyTidurTime(timeStr);
        setBedtimeSlot(detected.slot);
      }
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [entryMode]);

  const currentScore = calculateTidurCepatScore({
    bedtimeSlot,
    timeStr: entryMode === 'realtime' ? currentTimeStr : undefined,
    turnOffLightsEco,
    sleepQuality,
    reasonOrReport: reflection || lateReason,
    isMissed: entryMode === 'terlewat',
  });

  const handleTriggerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowHonestyModal(true);
  };

  const handleConfirmHonesty = () => {
    setShowHonestyModal(false);
    onSuccess(currentScore, {
      entryMode,
      timeRecorded: entryMode === 'realtime' ? currentTimeStr : undefined,
      bedtimeSlot,
      turnOffLightsEco,
      sleepQuality,
      reasonOrReport: reflection || lateReason,
      isMissed: entryMode === 'terlewat',
      timestamp: new Date().toLocaleTimeString('id-ID'),
    });
  };

  return (
    <div className="modal-backdrop-blur">
      <div className="w-full max-w-lg max-h-[90vh] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex-shrink-0 px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-indigo-50/80 to-white">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
              <Moon className="w-5 h-5 fill-white" />
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-indigo-600">
                Formulir 7 KAIH SMAN 28
              </span>
              <h3 className="font-extrabold text-slate-900 text-base leading-tight">
                Tidur Cepat &amp; Kualitas Istirahat
              </h3>
            </div>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 font-bold flex items-center justify-center cursor-pointer transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleTriggerSubmit} className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          {/* Mode Selector */}
          <div className="flex bg-slate-100 p-1 rounded-xl">
            <button
              type="button"
              onClick={() => setEntryMode('realtime')}
              className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                entryMode === 'realtime'
                  ? 'bg-white text-indigo-600 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              Check-in Sebelum Tidur (Stempel Jam)
            </button>
            <button
              type="button"
              onClick={() => setEntryMode('terlewat')}
              className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                entryMode === 'terlewat'
                  ? 'bg-white text-[#fc351c] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              Isi yang Terlewat (Penalti -5 pt)
            </button>
          </div>

          {/* Jam Realtime atau Pilihan Slot */}
          {entryMode === 'realtime' ? (
            <div className="p-4 bg-gradient-to-r from-indigo-50/70 to-blue-50/70 border border-indigo-200 rounded-2xl text-center space-y-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 block">
                Stempel Jam Tidur Sekarang:
              </span>
              <div className="text-3xl font-black text-slate-900 font-mono">
                {currentTimeStr} <span className="text-xs font-semibold text-slate-500">WIB</span>
              </div>
              <span className="inline-block px-3 py-1 bg-white rounded-full border border-indigo-200 text-xs font-bold text-indigo-700">
                Kategori: {bedtimeSlot}
              </span>
            </div>
          ) : (
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-800">
                Pilih Jam Tidur Anda (Terlewat -5 pt):
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { key: '<21.30', label: '< 21.30 WIB', pts: '75 pt' },
                  { key: '21.30-22.30', label: '21.30 – 22.30 WIB', pts: '65 pt' },
                  { key: '22.31-23.30', label: '22.31 – 23.30 WIB', pts: '55 pt' },
                  { key: '>23.30', label: '> 23.30 WIB', pts: '45 pt' },
                ].map((s) => (
                  <button
                    key={s.key}
                    type="button"
                    onClick={() => setBedtimeSlot(s.key as any)}
                    className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                      bedtimeSlot === s.key
                        ? 'bg-indigo-50 border-indigo-600 ring-1 ring-indigo-600'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <span className="text-xs font-bold text-slate-900">{s.label}</span>
                    <span className="text-[11px] font-black text-indigo-600 mt-1">{s.pts}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Eco Adiwiyata: Matikan Lampu */}
          <label className="p-3.5 bg-emerald-50/70 border border-emerald-200 rounded-2xl flex items-center justify-between cursor-pointer">
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                checked={turnOffLightsEco}
                onChange={(e) => setTurnOffLightsEco(e.target.checked)}
                className="w-4 h-4 rounded text-[#19ae5d] focus:ring-[#19ae5d]"
              />
              <div>
                <span className="text-xs font-bold text-slate-900 block">
                  Mematikan Lampu Saat Tidur (Adiwiyata Eco)
                </span>
                <span className="text-[11px] text-slate-500">
                  Hemat energi listrik &amp; memicu produksi melatonin alami
                </span>
              </div>
            </div>
            <span className="text-xs font-black text-[#19ae5d]">+5 pt</span>
          </label>

          {/* Kualitas Tidur (Skala 1 - 5) */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="text-xs font-bold text-slate-800">
                Skala Kualitas Tidur / Kebugaran Bangun:
              </label>
              <span className="text-xs font-black text-indigo-600">
                {sleepQuality} / 5 Bintang ({(sleepQuality * 5)} pt)
              </span>
            </div>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((lvl) => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => setSleepQuality(lvl)}
                  className={`flex-1 py-2.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    sleepQuality === lvl
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {lvl}★
                </button>
              ))}
            </div>
            <span className="text-[10px] text-slate-400 block mt-1">
              1 = Kurang lelap/sering terbangun, 5 = Sangat nyenyak &amp; bangun bugar
            </span>
          </div>

          {/* Footer inside form */}
          <div className="pt-2 flex items-center justify-between border-t border-slate-100">
            <div>
              <span className="text-[10px] text-slate-400 font-bold block">Proyeksi Skor Diperoleh:</span>
              <span className="text-base font-black text-indigo-600">
                {currentScore} / 100 pt
              </span>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={onCancel}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl text-xs font-black text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition-all cursor-pointer"
              >
                Simpan &amp; Konfirmasi
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* FULL-SCREEN HONESTY CONFIRMATION MODAL WITH COMPLETE BLUR */}
      {showHonestyModal && (
        <div className="honesty-backdrop-blur">
          <div className="bg-white rounded-3xl p-6 sm:p-7 max-w-md w-full shadow-2xl border border-slate-200 space-y-4 text-center">
            <div className="w-14 h-14 rounded-2xl bg-indigo-100 text-indigo-600 flex items-center justify-center mx-auto shadow-inner">
              <ShieldCheck className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-lg font-black text-slate-900 tracking-tight">
                Pernyataan Kejujuran Istirahat
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Karakter Jawara SMAN 28 dibentuk dari kejujuran dan tanggung jawab pribadi.
              </p>
            </div>

            <div className="p-3.5 bg-indigo-50/70 border border-indigo-200 rounded-xl text-xs text-indigo-950 font-medium text-left">
              "Saya menyatakan dengan sejujur-jujurnya bahwa data waktu dan kualitas tidur ini diisi secara benar dan dapat dipertanggungjawabkan."
            </div>

            <div className="flex items-center justify-between text-xs font-bold text-slate-700 px-2">
              <span>Poin Dicatat:</span>
              <span className="text-indigo-600 text-base">{currentScore} Poin</span>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowHonestyModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Koreksi
              </button>
              <button
                type="button"
                onClick={handleConfirmHonesty}
                className="flex-1 py-2.5 rounded-xl bg-[#19ae5d] hover:bg-emerald-700 text-white text-xs font-black shadow-sm cursor-pointer"
              >
                Saya Benar Mengisi Ini Jujur
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
