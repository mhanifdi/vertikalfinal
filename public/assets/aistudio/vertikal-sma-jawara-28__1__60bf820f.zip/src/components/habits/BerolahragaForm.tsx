/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Form Berolahraga SMAN 28 Jakarta
 * Skema: Aktivitas (10 pt per unsur) + Durasi (25/35/45/60 pt)
 * Termasuk Eco-Friendly Bersepeda/Jalan Kaki ke Sekolah (+10 pt) & Mode Terlewat (-5 pt)
 * Kontainer 1 screen (max-h-[90vh]), scrollable body, full-screen blur backdrop
 */

import React, { useState, useEffect } from 'react';
import { Activity, Check, CheckCircle2, Flame, ShieldCheck, Bike, Calendar } from 'lucide-react';
import { calculateOlahragaScore } from '../../utils/scoring';

interface BerolahragaFormProps {
  onSuccess: (score: number, payload: any) => void;
  onCancel: () => void;
  isAlreadySubmitted?: boolean;
}

export const BerolahragaForm: React.FC<BerolahragaFormProps> = ({
  onSuccess,
  onCancel,
  isAlreadySubmitted = false,
}) => {
  const [duration, setDuration] = useState<'<15' | '15-30' | '31-60' | '>60'>('15-30');
  const [activities, setActivities] = useState<string[]>(['jalanTangga']);
  const [notes, setNotes] = useState('');
  const [isMissed, setIsMissed] = useState(false);
  const [showHonestyModal, setShowHonestyModal] = useState(false);

  // Lock scroll
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  const toggleActivity = (actKey: string) => {
    setActivities((prev) =>
      prev.includes(actKey) ? prev.filter((a) => a !== actKey) : [...prev, actKey]
    );
  };

  const currentScore = calculateOlahragaScore({
    duration,
    activities,
    notes,
    isMissed,
  });

  const handleTriggerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (activities.length === 0) {
      alert('Pilih minimal satu aktivitas olahraga yang dilakukan hari ini.');
      return;
    }
    setShowHonestyModal(true);
  };

  const handleConfirmHonesty = () => {
    setShowHonestyModal(false);
    onSuccess(currentScore, {
      duration,
      activities,
      notes,
      isMissed,
      timestamp: new Date().toLocaleTimeString('id-ID'),
    });
  };

  return (
    <div className="modal-backdrop-blur">
      <div className="w-full max-w-lg max-h-[90vh] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex-shrink-0 px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-red-50/80 to-white">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#fc351c] text-white flex items-center justify-center shadow-xs">
              <Activity className="w-5 h-5 fill-white" />
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-[#fc351c]">
                Formulir 7 KAIH SMAN 28
              </span>
              <h3 className="font-extrabold text-slate-900 text-base leading-tight">
                Berolahraga &amp; Kebugaran Jasmani
              </h3>
            </div>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 font-bold flex items-center justify-center cursor-pointer transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleTriggerSubmit} className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          <div className="flex items-center justify-between p-3 bg-red-50/60 rounded-2xl border border-red-200">
            <div>
              <span className="text-xs font-bold text-slate-900 block">
                Skor Aktivitas + Durasi (Cap 100 pt)
              </span>
              <span className="text-[11px] text-slate-500">
                Pilih variasi kegiatan &amp; waktu olahraga hari ini
              </span>
            </div>
            <label className="flex items-center gap-2 text-xs font-bold text-rose-600 cursor-pointer bg-white px-2.5 py-1 rounded-xl border border-red-200 shadow-2xs">
              <input
                type="checkbox"
                checked={isMissed}
                onChange={(e) => setIsMissed(e.target.checked)}
                className="w-4 h-4 text-rose-600 rounded"
              />
              Isi Terlewat (-5 pt)
            </label>
          </div>

          {/* Aktivitas yang Dilakukan */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-2">
              Aktivitas Fisik yang Dilakukan (Pilih minimal 1):
            </label>
            <div className="space-y-2">
              {[
                {
                  key: 'mandiri',
                  label: 'Olahraga mandiri (Jogging, gym, bersepeda, skipping, dll.)',
                  pts: '+10 pt',
                },
                {
                  key: 'kelompok',
                  label: 'Olahraga kelompok / ekskul (Futsal, basket, badminton, tari, dll.)',
                  pts: '+10 pt',
                },
                {
                  key: 'jalanTangga',
                  label: 'Jalan kaki aktif / naik-turun tangga di lingkungan sekolah 28 / rumah',
                  pts: '+10 pt',
                },
                {
                  key: 'pemanasan',
                  label: 'Pemanasan / stretching ringan di sela jam belajar',
                  pts: '+10 pt',
                },
                {
                  key: 'bersepedaAdiwiyata',
                  label: 'Berjalan kaki / bersepeda ke sekolah (Aksi Adiwiyata)',
                  pts: '+10 pt',
                },
              ].map((act) => {
                const isSelected = activities.includes(act.key);
                return (
                  <label
                    key={act.key}
                    onClick={() => toggleActivity(act.key)}
                    className={`flex items-center justify-between p-3 rounded-2xl border cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-red-50/80 border-[#fc351c] ring-1 ring-[#fc351c]'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div
                        className={`w-4 h-4 rounded flex items-center justify-center border ${
                          isSelected ? 'bg-[#fc351c] border-[#fc351c] text-white' : 'border-slate-300 bg-white'
                        }`}
                      >
                        {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                      <span className="text-xs font-semibold text-slate-800">{act.label}</span>
                    </div>
                    <span className="text-[11px] font-black text-[#fc351c] shrink-0 ml-2">{act.pts}</span>
                  </label>
                );
              })}
            </div>
          </div>

          {/* Durasi Olahraga */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-2">
              Durasi Total Olahraga:
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { key: '<15', label: '< 15 Menit', score: '25 Poin' },
                { key: '15-30', label: '15 – 30 Menit', score: '35 Poin' },
                { key: '31-60', label: '31 – 60 Menit', score: '45 Poin' },
                { key: '>60', label: '> 60 Menit', score: '60 Poin' },
              ].map((d) => (
                <button
                  key={d.key}
                  type="button"
                  onClick={() => setDuration(d.key as any)}
                  className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    duration === d.key
                      ? 'bg-red-50 border-[#fc351c] ring-1 ring-[#fc351c]'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <span className="text-xs font-bold text-slate-900">{d.label}</span>
                  <span className="text-[11px] font-black text-[#fc351c] mt-1">{d.score}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Keterangan Ringkas */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1">
              Keterangan Ringkas (Opsional):
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Contoh: Lari pagi di Ragunan / Latihan ekskul basket 28"
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-red-500"
            />
          </div>

          {/* Footer inside form */}
          <div className="pt-2 flex items-center justify-between border-t border-slate-100">
            <div>
              <span className="text-[10px] text-slate-400 font-bold block">Proyeksi Skor Diperoleh:</span>
              <span className="text-base font-black text-[#fc351c]">
                {currentScore} / 100 pt
              </span>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={onCancel}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl text-xs font-black text-white bg-[#fc351c] hover:bg-red-700 shadow-sm transition-all cursor-pointer"
              >
                Simpan &amp; Konfirmasi
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* FULL-SCREEN HONESTY CONFIRMATION MODAL WITH COMPLETE BLUR */}
      {showHonestyModal && (
        <div className="honesty-backdrop-blur">
          <div className="bg-white rounded-3xl p-6 sm:p-7 max-w-md w-full shadow-2xl border border-slate-200 space-y-4 text-center">
            <div className="w-14 h-14 rounded-2xl bg-red-100 text-[#fc351c] flex items-center justify-center mx-auto shadow-inner">
              <ShieldCheck className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-lg font-black text-slate-900 tracking-tight">
                Pernyataan Kejujuran Olahraga
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Kesehatan dan sportivitas dibangun dari ketulusan beraktivitas fisik.
              </p>
            </div>

            <div className="p-3.5 bg-red-50/70 border border-red-200 rounded-xl text-xs text-red-950 font-medium text-left">
              "Saya menyatakan dengan sejujur-jujurnya bahwa saya benar telah melakukan aktivitas olahraga dengan durasi yang telah saya pilih."
            </div>

            <div className="flex items-center justify-between text-xs font-bold text-slate-700 px-2">
              <span>Poin Dicatat:</span>
              <span className="text-[#fc351c] text-base">{currentScore} Poin</span>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowHonestyModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Koreksi
              </button>
              <button
                type="button"
                onClick={handleConfirmHonesty}
                className="flex-1 py-2.5 rounded-xl bg-[#19ae5d] hover:bg-emerald-700 text-white text-xs font-black shadow-sm cursor-pointer"
              >
                Saya Benar Mengisi Ini Jujur
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
