/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Form Bangun Pagi dengan Fitur Live Stempel Waktu (Timestamp) & Mode Terlewat (-5 pt)
 * SMAN 28 Jakarta
 */

import React, { useState, useEffect } from 'react';
import { Sun, CheckCircle2, Clock, Info, ShieldCheck, AlertCircle, Calendar } from 'lucide-react';
import { calculateBangunPagiScore, classifyBangunPagiTime } from '../../utils/scoring';
import { SCORING_RULES } from '../../config/scoringConfig';

interface BangunPagiFormProps {
  onSuccess: (score: number, payload: any) => void;
  onCancel: () => void;
  isAlreadySubmitted?: boolean;
}

export const BangunPagiForm: React.FC<BangunPagiFormProps> = ({
  onSuccess,
  onCancel,
  isAlreadySubmitted = false,
}) => {
  const [entryMode, setEntryMode] = useState<'realtime' | 'terlewat'>('realtime');
  const [currentTimeStr, setCurrentTimeStr] = useState('');
  const [selectedSlot, setSelectedSlot] = useState<string>('04.00-04.20');
  const [customTime, setCustomTime] = useState('04:15');
  const [notes, setNotes] = useState('');
  const [showHonestyModal, setShowHonestyModal] = useState(false);

  // Lock scroll
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  // Update live clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hh = String(now.getHours()).padStart(2, '0');
      const mm = String(now.getMinutes()).padStart(2, '0');
      setCurrentTimeStr(`${hh}:${mm}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const activeTimeStr = entryMode === 'realtime' ? currentTimeStr : customTime;
  const realtimeClassification = classifyBangunPagiTime(activeTimeStr);

  const finalScore = entryMode === 'realtime'
    ? calculateBangunPagiScore({ timeStr: activeTimeStr })
    : calculateBangunPagiScore({ timeSlot: selectedSlot, isMissed: true });

  const handleTriggerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowHonestyModal(true);
  };

  const handleConfirmHonesty = () => {
    setShowHonestyModal(false);
    onSuccess(finalScore, {
      entryMode,
      timeStr: activeTimeStr,
      timeSlot: selectedSlot,
      notes,
      score: finalScore,
      timestamp: new Date().toLocaleTimeString('id-ID'),
    });
  };

  return (
    <div className="modal-backdrop-blur">
      <div className="w-full max-w-lg max-h-[90vh] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex-shrink-0 px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-blue-50/80 to-white">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#1c5ddc] text-white flex items-center justify-center shadow-xs">
              <Sun className="w-5 h-5 fill-white" />
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-[#1c5ddc]">
                Formulir 7 KAIH SMAN 28
              </span>
              <h3 className="font-extrabold text-slate-900 text-base leading-tight">
                Bangun Pagi
              </h3>
            </div>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 font-bold flex items-center justify-center cursor-pointer transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleTriggerSubmit} className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          {/* Mode Selector */}
          <div className="flex bg-slate-100 p-1 rounded-xl">
            <button
              type="button"
              onClick={() => setEntryMode('realtime')}
              className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                entryMode === 'realtime'
                  ? 'bg-white text-[#1c5ddc] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              Check-in Realtime (Stempel Waktu)
            </button>
            <button
              type="button"
              onClick={() => setEntryMode('terlewat')}
              className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                entryMode === 'terlewat'
                  ? 'bg-white text-[#fc351c] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              Isi yang Terlewat (Penalti -5 pt)
            </button>
          </div>

          {/* Info Panduan Baku */}
          <div className="flex items-center gap-2.5 p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-xs">
            <Info className="w-4 h-4 text-amber-600 shrink-0" />
            <p>
              <strong>Panduan Baku SMAN 28:</strong> Jam bangun pagi ideal adalah pukul <strong>04.00 – 06.00 WIB</strong> untuk kedisiplinan dan spiritualitas Jawara.
            </p>
          </div>

          {/* Realtime Mode Display */}
          {entryMode === 'realtime' ? (
            <div className="p-4 bg-gradient-to-r from-blue-50/70 to-indigo-50/70 border border-blue-200 rounded-2xl text-center space-y-3">
              <div className="flex items-center justify-center gap-2 text-xs font-bold uppercase tracking-wider text-[#1c5ddc]">
                <Clock className="w-4 h-4 animate-pulse" />
                Stempel Jam Sekarang (WIB)
              </div>
              <div className="text-4xl font-black text-slate-900 tracking-tight font-mono">
                {currentTimeStr || '04:15'} <span className="text-sm font-semibold text-slate-500">WIB</span>
              </div>
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-white rounded-full border border-blue-200 text-xs">
                <span className="text-slate-500">Kategori Terdeteksi:</span>
                <strong className="text-[#1c5ddc]">{realtimeClassification.label}</strong>
                <span className="w-1.5 h-1.5 rounded-full bg-[#19ae5d]" />
                <strong className="text-[#19ae5d]">{realtimeClassification.score} Poin</strong>
              </div>
            </div>
          ) : (
            /* Mode Terlewat */
            <div className="space-y-3">
              <label className="text-xs font-bold text-slate-800 block">
                Pilih Kategori Jam Bangun Anda (Dikenakan Penalti -5 pt):
              </label>
              <div className="grid grid-cols-1 gap-2">
                {SCORING_RULES.bangunPagi.brackets.map((b) => (
                  <label
                    key={b.id}
                    className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                      selectedSlot === b.id
                        ? 'bg-red-50/80 border-[#fc351c] ring-1 ring-[#fc351c]'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <input
                        type="radio"
                        name="bangun_slot"
                        checked={selectedSlot === b.id}
                        onChange={() => setSelectedSlot(b.id)}
                        className="w-4 h-4 text-[#fc351c] focus:ring-[#fc351c]"
                      />
                      <span className="text-xs font-bold text-slate-800">{b.label}</span>
                    </div>
                    <span className="text-xs font-black text-[#fc351c]">
                      {Math.max(0, b.score - SCORING_RULES.bangunPagi.missedPenalty)} pt
                    </span>
                  </label>
                ))}
              </div>
            </div>
          )}

          {/* Notes Input */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Catatan / Refleksi Bangun Pagi (Opsional):
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Misal: Bangun shalat subuh berjamaah & persiapan sekolah"
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          {/* Footer inside form */}
          <div className="pt-2 flex items-center justify-between border-t border-slate-100">
            <div>
              <span className="text-[10px] text-slate-400 font-bold block">Proyeksi Poin Diperoleh:</span>
              <span className="text-base font-black text-[#1c5ddc]">
                {finalScore} / 100 pt
              </span>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={onCancel}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl text-xs font-black text-white bg-[#1c5ddc] hover:bg-blue-700 shadow-sm transition-all cursor-pointer"
              >
                Simpan &amp; Konfirmasi
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* FULL-SCREEN HONESTY CONFIRMATION MODAL WITH COMPLETE BLUR */}
      {showHonestyModal && (
        <div className="honesty-backdrop-blur">
          <div className="bg-white rounded-3xl p-6 sm:p-7 max-w-md w-full shadow-2xl border border-slate-200 space-y-4 text-center">
            <div className="w-14 h-14 rounded-2xl bg-blue-100 text-[#1c5ddc] flex items-center justify-center mx-auto shadow-inner">
              <ShieldCheck className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-lg font-black text-slate-900 tracking-tight">
                Pernyataan Kejujuran Siswa
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Karakter Jawara SMAN 28 dibentuk dari kejujuran dan tanggung jawab pribadi.
              </p>
            </div>

            <div className="p-3.5 bg-blue-50/70 border border-blue-200 rounded-xl text-xs text-blue-950 font-medium text-left">
              "Saya menyatakan dengan sejujur-jujurnya bahwa data waktu bangun pagi ({activeTimeStr} WIB) ini diisi secara benar dan dapat dipertanggungjawabkan."
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowHonestyModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Kembali / Koreksi
              </button>
              <button
                type="button"
                onClick={handleConfirmHonesty}
                className="flex-1 py-2.5 rounded-xl bg-[#19ae5d] hover:bg-emerald-700 text-white text-xs font-black shadow-sm cursor-pointer"
              >
                Saya Benar Mengisi Ini Jujur
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
