/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * HonestyCheckInModal: Router for Habit Forms with Live Timestamps & Missed Entry Support
 * SMAN 28 Jakarta
 */

import React from 'react';
import { HabitLog } from '../../types';
import { BangunPagiForm } from '../habits/BangunPagiForm';
import { BeribadahForm } from '../habits/BeribadahForm';
import { MakanBergiziForm } from '../habits/MakanBergiziForm';
import { BerolahragaForm } from '../habits/BerolahragaForm';
import { GemarBelajarForm } from '../habits/GemarBelajarForm';
import { BermasyarakatForm } from '../habits/BermasyarakatForm';
import { TidurCepatForm } from '../habits/TidurCepatForm';

interface HonestyCheckInModalProps {
  habitId: string;
  studentReligion?: string;
  studentGender?: string;
  todayLogs?: Record<string, HabitLog[]> | any;
  onSuccess: (score: number, payload: any, isMulti?: boolean, subCategory?: string) => void;
  onCancel: () => void;
  isAlreadySubmitted?: boolean;
}

export const HonestyCheckInModal: React.FC<HonestyCheckInModalProps> = ({
  habitId,
  studentReligion = 'Islam',
  studentGender = 'L',
  todayLogs = {},
  onSuccess,
  onCancel,
  isAlreadySubmitted = false,
}) => {
  const currentLogsList = Array.isArray(todayLogs)
    ? todayLogs
    : todayLogs[habitId] || [];

  switch (habitId) {
    case 'bangun':
      return (
        <BangunPagiForm
          onSuccess={(score, payload) => onSuccess(score, payload, false)}
          onCancel={onCancel}
          isAlreadySubmitted={isAlreadySubmitted}
        />
      );

    case 'ibadah':
      return (
        <BeribadahForm
          studentReligion={studentReligion}
          studentGender={studentGender}
          todayLogs={currentLogsList}
          onSuccess={(score, payload, isMulti, subCat) =>
            onSuccess(score, payload, isMulti ?? true, subCat)
          }
          onCancel={onCancel}
        />
      );

    case 'makan':
      return (
        <MakanBergiziForm
          todayLogs={currentLogsList}
          onSuccess={(score, payload, isMulti, subCat) =>
            onSuccess(score, payload, isMulti ?? true, subCat)
          }
          onCancel={onCancel}
        />
      );

    case 'olahraga':
      return (
        <BerolahragaForm
          onSuccess={(score, payload) => onSuccess(score, payload, false)}
          onCancel={onCancel}
          isAlreadySubmitted={isAlreadySubmitted}
        />
      );

    case 'belajar':
      return (
        <GemarBelajarForm
          onSuccess={(score, payload) => onSuccess(score, payload, false)}
          onCancel={onCancel}
          isAlreadySubmitted={isAlreadySubmitted}
        />
      );

    case 'masyarakat':
      return (
        <BermasyarakatForm
          onSuccess={(score, payload) => onSuccess(score, payload, false)}
          onCancel={onCancel}
          isAlreadySubmitted={isAlreadySubmitted}
        />
      );

    case 'tidur':
      return (
        <TidurCepatForm
          onSuccess={(score, payload) => onSuccess(score, payload, false)}
          onCancel={onCancel}
          isAlreadySubmitted={isAlreadySubmitted}
        />
      );

    default:
      return (
        <div className="p-4 text-center text-slate-500 text-sm">
          Kebiasaan tidak ditemukan.
        </div>
      );
  }
};
