/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Home,
  CheckSquare,
  Trophy,
  User,
  Sun,
  Moon,
  Activity,
  Utensils,
  GraduationCap,
  Users,
  Heart,
  ChevronRight,
  Flame,
  Award,
  Sparkles,
  ArrowRight,
  Clock,
  ShieldCheck,
  Plus,
  Minus,
  CheckCircle2,
  Lock,
  Calendar,
} from 'lucide-react';
import { Student, HabitLog } from '../../types';
import { api } from '../../utils/api';
import { HonestyCheckInModal } from '../common/HonestyCheckInModal';
import { LeaderboardTable } from '../common/LeaderboardTable';
import { RadarChart } from '../charts/RadarChart';
import { TrendLineChart } from '../charts/TrendLineChart';
import { GaugeChart } from '../charts/GaugeChart';

interface StudentDashboardProps {
  student: Student;
  allStudents: Student[];
  onLogout: () => void;
  onOpenReport?: (studentId: string) => void;
}

type TabType = 'beranda' | 'kebiasaanku' | 'terlewat' | 'leaderboard' | 'profil';

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  student,
  allStudents,
  onLogout,
  onOpenReport,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('beranda');
  const [todayLogs, setTodayLogs] = useState<Record<string, HabitLog[]>>({
    bangun: [],
    ibadah: [],
    olahraga: [],
    makan: [],
    belajar: [],
    masyarakat: [],
    tidur: [],
  });
  const [activeFormModal, setActiveFormModal] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [studentStats, setStudentStats] = useState<any>(null);
  const [missedDate, setMissedDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() - 1);
    return d.toISOString().split('T')[0];
  });

  // Load today's logs from SQLite
  const fetchTodayHabits = async () => {
    try {
      const data = await api.getTodayHabits(student.id);
      if (data?.habitsByType) {
        setTodayLogs(data.habitsByType);
      }
      const report = await api.getStudentReport(student.id);
      setStudentStats(report);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchTodayHabits();
  }, [student.id]);

  // 7 KAIH master definition
  const HABIT_CARDS = [
    {
      id: 'bangun',
      title: 'Bangun Pagi',
      subtitle: 'Pukul 04.00 – 06.00 WIB',
      icon: Sun,
      color: '#1c5ddc',
      bgLight: 'bg-blue-50',
      borderLight: 'border-blue-200',
      isMulti: false,
      desc: 'Kedisiplinan mengawali hari dengan segar',
    },
    {
      id: 'ibadah',
      title: 'Beribadah',
      subtitle: 'Shalat / Doa Harian / Tri Sandhya',
      icon: Heart,
      color: '#19ae5d',
      bgLight: 'bg-emerald-50',
      borderLight: 'border-emerald-200',
      isMulti: true,
      desc: 'Ketaatan spiritual & penguatan nilai keimanan',
    },
    {
      id: 'olahraga',
      title: 'Berolahraga',
      subtitle: 'Minimal 15 – 60 Menit',
      icon: Activity,
      color: '#fc351c',
      bgLight: 'bg-red-50',
      borderLight: 'border-red-200',
      isMulti: false,
      desc: 'Kebugaran fisik, peregangan & stamina tubuh',
    },
    {
      id: 'makan',
      title: 'Makan Bergizi',
      subtitle: 'Isi Piringku & Air Putih',
      icon: Utensils,
      color: '#feb52b',
      bgLight: 'bg-amber-50',
      borderLight: 'border-amber-200',
      isMulti: true,
      desc: 'Nutrisi seimbang karbo, lauk, sayur & buah',
    },
    {
      id: 'belajar',
      title: 'Gemar Belajar',
      subtitle: 'Mandiri di luar jam sekolah',
      icon: GraduationCap,
      color: '#0000fe',
      bgLight: 'bg-indigo-50',
      borderLight: 'border-indigo-200',
      isMulti: false,
      desc: 'Membaca, review pelajaran & skill eksploratif',
    },
    {
      id: 'masyarakat',
      title: 'Bermasyarakat',
      subtitle: 'Piket, gotong royong & Adiwiyata',
      icon: Users,
      color: '#19ae5d',
      bgLight: 'bg-emerald-50',
      borderLight: 'border-emerald-200',
      isMulti: false,
      desc: 'Aksi sosial nyata di sekolah dan lingkungan 28',
    },
    {
      id: 'tidur',
      title: 'Tidur Cepat',
      subtitle: 'Sebelum 22.30 WIB',
      icon: Moon,
      color: '#0000fe',
      bgLight: 'bg-indigo-50',
      borderLight: 'border-indigo-200',
      isMulti: false,
      desc: 'Pemulihan tubuh & ritme sirkadia bugar',
    },
  ];

  // Check which habits have NOT been completed today
  const uncompletedHabits = HABIT_CARDS.filter((h) => {
    const logs = todayLogs[h.id] || [];
    return logs.length === 0;
  });

  // Calculate my rank in all students
  const myRank =
    allStudents.findIndex((s) => s.id === student.id) !== -1
      ? allStudents.findIndex((s) => s.id === student.id) + 1
      : 1;

  // Handle submit habit log
  const handleHabitSubmit = async (
    habitType: string,
    score: number,
    payload: any,
    isCounter = false,
    subCategory?: string
  ) => {
    try {
      setLoading(true);
      const isMissed = activeTab === 'terlewat' || payload?.isMissed;
      const targetDate = isMissed ? missedDate : undefined;
      await api.submitHabit({
        student_id: student.id,
        habit_type: habitType,
        score,
        payload,
        sub_category: subCategory || payload?.detectedPrayer || payload?.subCategory,
        is_counter_entry: isCounter ? 1 : 0,
        log_date: targetDate,
      });
      setActiveFormModal(null);
      await fetchTodayHabits();
    } catch (err: any) {
      alert(err.message || 'Gagal menyimpan kebiasaan');
    } finally {
      setLoading(false);
    }
  };

  // Handle counter decrement
  const handleDecrementCounter = async (habitType: string) => {
    try {
      await api.decrementCounter(student.id, habitType);
      await fetchTodayHabits();
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="min-h-screen bg-kebaya-pattern flex flex-col pb-20 md:pb-6">
      {/* Top Header */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 sm:px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#1c5ddc] to-[#0000fe] text-white flex items-center justify-center font-black text-sm shadow-sm">
            28
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-sm sm:text-base text-slate-900 tracking-tight">
                VERTIKAL SMA JAWARA 28
              </span>
              <span className="w-2 h-2 rounded-full bg-[#eb30a2]" title="Aksen Betawi" />
            </div>
            <span className="text-[11px] text-slate-500 hidden sm:block">
              Instrumen Siswa • 7 Kebiasaan Anak Indonesia Hebat
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <span className="text-xs font-bold text-slate-900 block">{student.name}</span>
            <span className="text-[10px] text-slate-500 font-semibold">{student.class_name} • NISN {student.nisn}</span>
          </div>
          <button
            type="button"
            onClick={onLogout}
            className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors cursor-pointer"
          >
            Keluar
          </button>
        </div>
      </header>

      {/* Main 3-Column / Responsive Layout */}
      <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 flex-1 grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Left Fixed / Collapsible Sidebar (Col 1-3 on Desktop) */}
        <aside className="hidden md:block md:col-span-3 lg:col-span-3">
          <div className="sticky top-20 bg-white rounded-2xl border border-slate-200 p-3 shadow-xs space-y-1">
            <div className="px-3 py-2 text-[11px] font-black uppercase tracking-wider text-slate-400">
              Menu Siswa
            </div>

            {[
              { id: 'beranda' as const, label: 'Beranda', icon: Home },
              { id: 'kebiasaanku' as const, label: 'Kebiasaanku (Realtime)', icon: CheckSquare, badge: uncompletedHabits.length > 0 ? `${uncompletedHabits.length}` : null },
              { id: 'terlewat' as const, label: 'Isi yang Terlewat', icon: Calendar, badge: 'Penalti -5' },
              { id: 'leaderboard' as const, label: 'Leaderboard', icon: Trophy },
              { id: 'profil' as const, label: 'Profil Siswa', icon: User },
            ].map((menu) => {
              const Icon = menu.icon;
              const isActive = activeTab === menu.id;
              return (
                <button
                  key={menu.id}
                  type="button"
                  onClick={() => setActiveTab(menu.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                    isActive
                      ? 'bg-[#1c5ddc] text-white shadow-sm'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className="w-4 h-4" />
                    <span>{menu.label}</span>
                  </div>
                  {menu.badge && (
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded-full font-black ${
                        isActive ? 'bg-white text-[#1c5ddc]' : 'bg-[#eb30a2] text-white'
                      }`}
                    >
                      {menu.badge}
                    </span>
                  )}
                </button>
              );
            })}

            {/* Quick SMAN 28 Identity card in sidebar */}
            <div className="pt-4 mt-4 border-t border-slate-100 px-3">
              <span className="text-[10px] text-slate-400 block font-semibold uppercase tracking-wider">
                Wali Kelas Anda
              </span>
              <span className="text-xs font-bold text-slate-800 block mt-0.5">
                {student.walas_name}
              </span>
              <span className="text-[10px] text-slate-500 block">
                NIP {student.walas_nip}
              </span>
            </div>
          </div>
        </aside>

        {/* Center Main Content (Col 4-9 on Desktop, full on tablet/mobile) */}
        <main className="md:col-span-9 lg:col-span-6 space-y-6">
          {/* TAB 1: BERANDA */}
          {activeTab === 'beranda' && (
            <div className="space-y-6">
              {/* Profile Card (Nama, NISN, Streak, Leaderboard, Poin Hebat) */}
              <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-sm relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-[#feb52b]/15 via-[#1c5ddc]/10 to-transparent rounded-bl-full pointer-events-none" />
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5">
                  <div className="flex items-center gap-3.5">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#1c5ddc] to-[#0000fe] text-white flex items-center justify-center font-black text-2xl shadow-md ring-4 ring-blue-50">
                      {student.name.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight">
                          {student.name}
                        </h2>
                        <span className="text-[10px] bg-blue-100 text-[#1c5ddc] px-2 py-0.5 rounded-full font-black">
                          {student.class_name}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 font-medium">
                        NISN: {student.nisn} • SMAN 28 Jakarta • Angkatan {student.angkatan}
                      </p>
                    </div>
                  </div>
                </div>

                {/* KPI metrics in Profile Card: Streak, Leaderboard, Poin Hebat */}
                <div className="grid grid-cols-3 gap-2.5 pt-4 border-t border-slate-100">
                  <div className="p-3 bg-amber-50/70 rounded-2xl border border-amber-100/80 text-center">
                    <span className="text-[10px] sm:text-xs font-semibold text-amber-800 flex items-center justify-center gap-1">
                      <Flame className="w-3.5 h-3.5 text-amber-500" /> Hari Aktif
                    </span>
                    <span className="text-xl sm:text-2xl font-black text-amber-950 block mt-0.5">
                      {studentStats?.totalEntries > 0 ? Math.max(1, student.active_days || 1) : 0}
                    </span>
                    <span className="text-[9px] text-amber-700 font-medium">Streak Rutinitas</span>
                  </div>

                  <div className="p-3 bg-blue-50/70 rounded-2xl border border-blue-100/80 text-center">
                    <span className="text-[10px] sm:text-xs font-semibold text-[#1c5ddc] flex items-center justify-center gap-1">
                      <Trophy className="w-3.5 h-3.5 text-[#1c5ddc]" /> Peringkat
                    </span>
                    <span className="text-xl sm:text-2xl font-black text-blue-950 block mt-0.5">
                      #{myRank}
                    </span>
                    <span className="text-[9px] text-blue-700 font-medium">Leaderboard Sekolah</span>
                  </div>

                  <div className="p-3 bg-emerald-50/70 rounded-2xl border border-emerald-100/80 text-center">
                    <span className="text-[10px] sm:text-xs font-semibold text-emerald-800 flex items-center justify-center gap-1">
                      <Award className="w-3.5 h-3.5 text-emerald-500" /> Poin Hebat
                    </span>
                    <span className="text-xl sm:text-2xl font-black text-emerald-950 block mt-0.5">
                      {studentStats?.overallScore !== undefined ? studentStats.overallScore.toFixed(1) : (student.avg_score ? student.avg_score.toFixed(1) : '0')}
                    </span>
                    <span className="text-[9px] text-emerald-700 font-medium">Rerata 7 KAIH</span>
                  </div>
                </div>
              </div>

              {/* Container Kebiasaan (Memuat kebiasaan yg belum terisi, MAKSIMAL 2 AJA, jika lebih sebelahnya fadeout. CTA: Selebihnya → Kebiasaanku) */}
              <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-sm sm:text-base tracking-tight flex items-center gap-2">
                      <span>Kebiasaan Belum Terisi Hari Ini</span>
                      {uncompletedHabits.length > 0 && (
                        <span className="w-2 h-2 rounded-full bg-[#eb30a2]" />
                      )}
                    </h3>
                    <p className="text-xs text-slate-500 font-medium">
                      {uncompletedHabits.length > 0
                        ? `Ada ${uncompletedHabits.length} kebiasaan yang belum kamu laporkan hari ini.`
                        : 'Luar biasa! Seluruh kebiasaan hari ini sudah tercatat.'}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveTab('kebiasaanku')}
                    className="text-xs font-bold text-[#1c5ddc] hover:underline flex items-center gap-1 shrink-0 cursor-pointer"
                  >
                    Selebihnya → Kebiasaanku
                  </button>
                </div>

                {/* 2-Card Container with Fadeout edge if more than 2 */}
                {uncompletedHabits.length > 0 ? (
                  <div className="relative">
                    <div
                      className={`grid grid-cols-1 sm:grid-cols-2 gap-3 ${
                        uncompletedHabits.length > 2 ? 'fade-out-edge' : ''
                      }`}
                    >
                      {uncompletedHabits.slice(0, 2).map((habit) => {
                        const Icon = habit.icon;
                        return (
                          <div
                            key={habit.id}
                            onClick={() => setActiveFormModal(habit.id)}
                            className="habit-card p-4 rounded-2xl border border-slate-200 bg-white hover:border-[#1c5ddc] cursor-pointer group shadow-xs"
                          >
                            <div className="flex items-center justify-between mb-2">
                              <div
                                className="w-8 h-8 rounded-xl flex items-center justify-center text-white"
                                style={{ backgroundColor: habit.color }}
                              >
                                <Icon className="w-4 h-4" />
                              </div>
                              <span className="text-[11px] font-bold text-[#1c5ddc] group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5">
                                Isi <ChevronRight className="w-3.5 h-3.5" />
                              </span>
                            </div>
                            <h4 className="font-bold text-slate-900 text-sm">{habit.title}</h4>
                            <p className="text-xs text-slate-500 font-medium line-clamp-1 mt-0.5">
                              {habit.subtitle}
                            </p>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  <div className="p-6 text-center bg-green-50/60 rounded-2xl border border-green-200">
                    <CheckCircle2 className="w-8 h-8 text-[#19ae5d] mx-auto mb-1.5" />
                    <span className="font-bold text-green-900 text-sm block">
                      Semua Kebiasaan Telah Dilaporkan!
                    </span>
                    <span className="text-xs text-green-700">
                      Pertahankan kedisiplinan Jawara 28 hingga esok hari.
                    </span>
                  </div>
                )}
              </div>

              {/* Container Ringkasan Rapor memuat: Ulasan guru & Capaian Skor Keseluruhan (%) */}
              <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <h3 className="font-extrabold text-slate-900 text-sm sm:text-base tracking-tight">
                    Ringkasan Rapor Pembiasaan
                  </h3>
                  <button
                    type="button"
                    onClick={() => setActiveTab('profil')}
                    className="text-xs font-bold text-[#1c5ddc] hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    Buka Rapor Lengkap <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {/* Capaian Skor Keseluruhan (%) */}
                  <div className="sm:col-span-1 p-4 rounded-2xl bg-gradient-to-b from-blue-50/80 to-white border border-blue-100 text-center flex flex-col justify-center items-center">
                    <span className="text-xs text-slate-500 font-semibold">Capaian Keseluruhan</span>
                    <span className="text-3xl font-black text-[#1c5ddc] my-1">
                      {studentStats?.overallScore ? `${studentStats.overallScore}%` : '0%'}
                    </span>
                    <span className="text-[11px] font-bold text-blue-700 bg-blue-100/60 px-2 py-0.5 rounded-full">
                      Target 100%
                    </span>
                  </div>

                  {/* Ulasan Guru */}
                  <div className="sm:col-span-2 p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                        Ulasan Wali Kelas ({student.walas_name}):
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 italic">
                      "{student.walas_notes || 'Belum ada ulasan catatan dari wali kelas.'}"
                    </p>
                    {student.walas_recommendation && (
                      <p className="text-[11px] text-[#1c5ddc] font-medium pt-1 border-t border-slate-200">
                        <strong>Rekomendasi:</strong> {student.walas_recommendation}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: KEBIASAANKU (7 Cards Grid -> Form when clicked) */}
          {activeTab === 'kebiasaanku' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-black text-slate-900 tracking-tight">
                    Isi Kebiasaanku (7 KAIH)
                  </h2>
                  <p className="text-xs text-slate-500 font-medium">
                    Bebas mengisi kapan saja tanpa urutan tertentu. Limit 1x sehari untuk kebiasaan harian tunggal.
                  </p>
                </div>
              </div>

              {/* 7 Habit Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4">
                {HABIT_CARDS.map((habit) => {
                  const Icon = habit.icon;
                  const logs = todayLogs[habit.id] || [];
                  const isSubmitted = logs.length > 0;
                  const isDisabled = !habit.isMulti && isSubmitted;

                  return (
                    <div
                      key={habit.id}
                      className={`habit-card rounded-3xl p-5 border transition-all ${
                        isDisabled
                          ? 'bg-slate-50/80 border-slate-200 opacity-80'
                          : 'bg-white border-slate-200 hover:border-[#1c5ddc]'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div
                          className="w-10 h-10 rounded-2xl flex items-center justify-center text-white shadow-xs"
                          style={{ backgroundColor: habit.color }}
                        >
                          <Icon className="w-5 h-5" />
                        </div>

                        {/* Status Badge */}
                        <div>
                          {isDisabled ? (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-500 bg-slate-200 px-2 py-0.5 rounded-full">
                              <Lock className="w-3 h-3" /> Sudah Diisi
                            </span>
                          ) : habit.isMulti && isSubmitted ? (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-green-700 bg-green-100 px-2 py-0.5 rounded-full">
                              <CheckCircle2 className="w-3 h-3" /> {logs.length}x Entri
                            </span>
                          ) : (
                            <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full">
                              Belum Diisi
                            </span>
                          )}
                        </div>
                      </div>

                      <h4 className="font-extrabold text-slate-900 text-base">{habit.title}</h4>
                      <p className="text-xs font-medium text-slate-500 mb-1">{habit.subtitle}</p>
                      <p className="text-[11px] text-slate-400 mb-4 line-clamp-1">{habit.desc}</p>

                      {/* Action buttons */}
                      <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                        {habit.isMulti ? (
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-700">Counter:</span>
                            <div className="inline-flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg">
                              <button
                                type="button"
                                onClick={() => handleDecrementCounter(habit.id)}
                                disabled={logs.length <= 0}
                                className="w-6 h-6 rounded bg-white text-slate-700 flex items-center justify-center font-bold text-xs hover:bg-slate-200 disabled:opacity-40 cursor-pointer"
                                title="Kurangi 1 entri"
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <span className="px-2 font-black text-xs text-slate-900">
                                {logs.length}
                              </span>
                              <button
                                type="button"
                                onClick={() => setActiveFormModal(habit.id)}
                                className="w-6 h-6 rounded bg-[#1c5ddc] text-white flex items-center justify-center font-bold text-xs hover:bg-blue-700 cursor-pointer"
                                title="Tambah entri"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        ) : (
                          <span className="text-[11px] text-slate-400 font-medium">
                            Limit 1x per hari
                          </span>
                        )}

                        <button
                          type="button"
                          onClick={() => setActiveFormModal(habit.id)}
                          disabled={isDisabled}
                          className={`btn-interactive px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                            isDisabled
                              ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                              : 'bg-[#1c5ddc] text-white hover:bg-blue-700 shadow-xs'
                          }`}
                        >
                          {isDisabled ? 'Terkunci Hari Ini' : 'Buka Formulir'}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB: ISI YANG TERLEWAT (SUSULAN DENGAN PENALTI -5 POIN) */}
          {activeTab === 'terlewat' && (
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-red-50 to-orange-50 border border-red-200 rounded-3xl p-5 sm:p-6 shadow-xs">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="w-2 h-2 rounded-full bg-[#fc351c] animate-ping" />
                      <span className="text-[10px] font-black uppercase tracking-wider text-[#fc351c] bg-red-100 px-2 py-0.5 rounded-full">
                        Menu Kompensasi / Susulan
                      </span>
                    </div>
                    <h2 className="text-xl font-black text-slate-900 tracking-tight">
                      Isi Kebiasaan yang Terlewat
                    </h2>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Pilih tanggal pelaksanaan yang terlewat. Opsi penilaian dipilih langsung dan skor otomatis dikurangi 5 poin penalti.
                    </p>
                  </div>

                  {/* Date Picker */}
                  <div className="bg-white p-3 rounded-2xl border border-red-200 shadow-xs flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-[#fc351c]" />
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 block">Tanggal Terlewat:</span>
                      <input
                        type="date"
                        value={missedDate}
                        max={new Date().toISOString().split('T')[0]}
                        onChange={(e) => setMissedDate(e.target.value)}
                        className="text-xs font-bold text-slate-900 focus:outline-none cursor-pointer"
                      />
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-white/90 border border-red-200 rounded-xl text-xs text-red-950 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#fc351c] shrink-0" />
                  <span>
                    <strong>Aturan Penalti Terlewat:</strong> Seluruh kebiasaan yang dilaporkan melalui menu ini akan dikenakan penalti <strong>-5 poin</strong> untuk menjaga integritas dan ketepatan waktu Jawara 28.
                  </span>
                </div>
              </div>

              {/* 7 Habit Cards for Missed Entries */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4">
                {HABIT_CARDS.map((habit) => {
                  const Icon = habit.icon;
                  return (
                    <div
                      key={`missed-${habit.id}`}
                      className="habit-card bg-white rounded-3xl p-5 border border-slate-200 hover:border-[#fc351c] shadow-xs transition-all flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-start justify-between mb-3">
                          <div
                            className="w-10 h-10 rounded-2xl flex items-center justify-center text-white shadow-xs"
                            style={{ backgroundColor: habit.color }}
                          >
                            <Icon className="w-5 h-5" />
                          </div>
                          <span className="text-[10px] font-black text-[#fc351c] bg-red-50 border border-red-200 px-2 py-0.5 rounded-full">
                            Penalti -5 pt
                          </span>
                        </div>

                        <h4 className="font-extrabold text-slate-900 text-base">{habit.title}</h4>
                        <p className="text-xs font-medium text-slate-500 mb-1">{habit.subtitle}</p>
                        <p className="text-[11px] text-slate-400 mb-4">{habit.desc}</p>
                      </div>

                      <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                        <span className="text-[10px] text-slate-400 font-medium">
                          Tanggal: {missedDate}
                        </span>
                        <button
                          type="button"
                          onClick={() => setActiveFormModal(habit.id)}
                          className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#fc351c] hover:bg-red-700 shadow-xs cursor-pointer transition-all"
                        >
                          Isi Susulan (-5 pt)
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: LEADERBOARD */}
          {activeTab === 'leaderboard' && (
            <LeaderboardTable
              students={allStudents}
              currentUserId={student.id}
              onSelectStudent={(s) => onOpenReport?.(s.id)}
            />
          )}

          {/* TAB 4: PROFIL SISWA */}
          {activeTab === 'profil' && (
            <div className="space-y-6">
              {/* Profile Card Header */}
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center gap-5">
                <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-[#1c5ddc] to-[#0000fe] text-white flex items-center justify-center font-black text-3xl shadow-md">
                  {student.name.charAt(0)}
                </div>
                <div className="text-center sm:text-left flex-1">
                  <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mb-1">
                    <h2 className="text-xl font-black text-slate-900">{student.name}</h2>
                    <span className="text-xs bg-blue-100 text-[#1c5ddc] px-2.5 py-0.5 rounded-full font-bold">
                      {student.class_name}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 font-medium">
                    NISN: {student.nisn} • Agama: {student.religion} • Angkatan: {student.angkatan}
                  </p>
                  <p className="text-xs text-slate-600 mt-1">
                    Wali Kelas: <strong>{student.walas_name}</strong> (NIP {student.walas_nip})
                  </p>
                </div>
              </div>

              {/* Radar & Gauge */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs">
                  <h4 className="font-extrabold text-xs uppercase tracking-wider text-slate-700 mb-2">
                    Grafik Jaring 7 KAIH
                  </h4>
                  <RadarChart
                    data={(studentStats?.habitMetrics || []).map((m: any) => ({
                      habit: m.habit,
                      label: m.label,
                      score: m.studentScore,
                    }))}
                    size={280}
                  />
                </div>

                <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex flex-col justify-center">
                  <GaugeChart
                    score={studentStats?.overallScore || 0}
                    title="Capaian Skor Keseluruhan"
                    size={240}
                  />
                </div>
              </div>

              {/* Trend Garis Komparasi */}
              <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs">
                <h4 className="font-extrabold text-xs uppercase tracking-wider text-slate-700 mb-1">
                  Grafik Garis Tren Capaian 7 KAIH
                </h4>
                <p className="text-xs text-slate-500 mb-3">
                  Perbandingan Capaian Siswa vs Rata-Rata Kelas vs Rata-Rata Angkatan vs Rata-Rata Sekolah
                </p>
                <TrendLineChart metrics={studentStats?.habitMetrics || []} />
              </div>

              {/* Tabel Rincian Metrik Lengkap 7 KAIH */}
              <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
                <div className="p-4 bg-slate-50 border-b border-slate-200 font-bold text-xs text-slate-700">
                  Rincian Metrik Lengkap 7 KAIH
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50/60 text-slate-500 font-semibold border-b border-slate-100">
                      <tr>
                        <th className="py-2.5 px-4">Kebiasaan</th>
                        <th className="py-2.5 px-4 text-center">Skor Saya</th>
                        <th className="py-2.5 px-4 text-center">Rata-rata Kelas</th>
                        <th className="py-2.5 px-4 text-center">Rata-rata Sekolah</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {(studentStats?.habitMetrics || []).map((m: any) => (
                        <tr key={m.habit}>
                          <td className="py-2.5 px-4 font-bold text-slate-800">{m.label}</td>
                          <td className="py-2.5 px-4 text-center font-black text-[#1c5ddc]">
                            {m.studentScore} pt
                          </td>
                          <td className="py-2.5 px-4 text-center text-slate-600">{m.classAvg} pt</td>
                          <td className="py-2.5 px-4 text-center text-slate-600">{m.schoolAvg} pt</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Catatan & Rekomendasi Walas */}
              <div className="bg-amber-50/60 rounded-3xl p-5 border border-amber-200/80 space-y-3">
                <h4 className="font-extrabold text-sm text-amber-950 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  Catatan &amp; Rekomendasi Wali Kelas ({student.walas_name})
                </h4>
                <div className="p-3 bg-white rounded-2xl border border-amber-200 text-xs text-slate-700">
                  <strong className="block text-slate-900 mb-0.5">Catatan Evaluasi:</strong>
                  {student.walas_notes || 'Belum ada catatan tertulis dari wali kelas.'}
                </div>
                <div className="p-3 bg-white rounded-2xl border border-amber-200 text-xs text-slate-700">
                  <strong className="block text-slate-900 mb-0.5">Rekomendasi Tindak Lanjut:</strong>
                  {student.walas_recommendation || 'Belum ada rekomendasi tertulis dari wali kelas.'}
                </div>
              </div>
            </div>
          )}
        </main>

        {/* Right Info / Stats Column (Desktop >1024px) */}
        <aside className="hidden lg:block lg:col-span-3 space-y-5">
          {/* Ringkasan Hari Ini */}
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-700">
              Jadwal Shalat Jakarta
            </h4>
            <div className="space-y-1.5 text-xs">
              {[
                { name: 'Subuh', time: '04.30 WIB' },
                { name: 'Zuhur', time: '11.55 WIB' },
                { name: 'Asar', time: '15.10 WIB' },
                { name: 'Magrib', time: '17.55 WIB' },
                { name: 'Isya', time: '19.05 WIB' },
              ].map((s) => (
                <div key={s.name} className="flex justify-between py-1 border-b border-slate-100 last:border-none">
                  <span className="text-slate-600 font-medium">{s.name}</span>
                  <span className="font-bold text-slate-800">{s.time}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Tips Pembiasaan 28 */}
          <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-3xl p-5 border border-amber-200 shadow-xs">
            <span className="text-[10px] font-black text-amber-800 uppercase tracking-wider block mb-1">
              Prinsip Jawara 28
            </span>
            <h5 className="font-extrabold text-xs text-amber-950 mb-1">
              "Karakter Unggul Dibentuk dari Kebiasaan Kecil yang Konsisten"
            </h5>
            <p className="text-[11px] text-amber-800/80 leading-relaxed">
              Disiplin bangun pagi, menjaga asupan serat sayur buah, serta tidur sebelum pukul 22.30 menjaga kejernihan fokus belajar siswa SMAN 28 Jakarta.
            </p>
          </div>
        </aside>
      </div>

      {/* MOBILE BOTTOM NAVIGATION BAR (Strict rule 3.C: Mobile First UI for screens < 768px) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-2 flex items-center justify-around shadow-lg">
        {[
          { id: 'beranda' as const, label: 'Beranda', icon: Home },
          { id: 'kebiasaanku' as const, label: 'Kebiasaan', icon: CheckSquare, badge: uncompletedHabits.length > 0 ? `${uncompletedHabits.length}` : null },
          { id: 'terlewat' as const, label: 'Terlewat', icon: Calendar, badge: '-5 pt' },
          { id: 'leaderboard' as const, label: 'Peringkat', icon: Trophy },
          { id: 'profil' as const, label: 'Profil', icon: User },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center justify-center min-w-[56px] min-h-[48px] rounded-xl text-[10px] font-bold transition-all relative ${
                isActive ? 'text-[#1c5ddc]' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Icon className={`w-5 h-5 mb-0.5 ${isActive ? 'stroke-[2.5]' : ''}`} />
              <span>{tab.label}</span>
              {tab.badge && (
                <span className="absolute top-1 right-2 w-4 h-4 bg-[#eb30a2] text-white text-[9px] rounded-full flex items-center justify-center font-black">
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Form Modal when habit card clicked */}
      {activeFormModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl w-full max-w-xl shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="h-2 w-full bg-gradient-to-r from-[#fc351c] via-[#feb52b] to-[#1c5ddc]" />
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-[#1c5ddc]">
                  Formulir 7 KAIH SMAN 28
                </span>
                <h3 className="text-lg font-black text-slate-900">
                  {HABIT_CARDS.find((h) => h.id === activeFormModal)?.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setActiveFormModal(null)}
                className="text-slate-400 hover:text-slate-700 p-2 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-5 sm:p-6">
              <HonestyCheckInModal
                habitId={activeFormModal}
                studentReligion={student.religion}
                studentGender={student.gender}
                todayLogs={todayLogs}
                onSuccess={(score, payload, isMulti, subCategory) =>
                  handleHabitSubmit(activeFormModal, score, payload, isMulti, subCategory)
                }
                onCancel={() => setActiveFormModal(null)}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
