/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Users,
  Award,
  CheckCircle2,
  Trophy,
  Filter,
  BarChart3,
  Radar,
  ChevronRight,
  Sparkles,
  AlertTriangle,
  UserCheck,
  Search,
} from 'lucide-react';
import { Teacher, Student, ClassAnalytics } from '../../types';
import { api } from '../../utils/api';
import { RadarChart } from '../charts/RadarChart';
import { GaugeChart } from '../charts/GaugeChart';
import { ScoreDistributionBar } from '../charts/ScoreDistributionBar';
import { LeaderboardTable } from '../common/LeaderboardTable';
import { StudentReportModal } from '../common/StudentReportModal';

interface TeacherDashboardProps {
  teacher: Teacher;
  allStudents: Student[];
  onLogout: () => void;
}

export const TeacherDashboard: React.FC<TeacherDashboardProps> = ({
  teacher,
  allStudents,
  onLogout,
}) => {
  const [activeTab, setActiveTab] = useState<'beranda' | 'leaderboard'>('beranda');
  const [chartMode, setChartMode] = useState<'radar' | 'progress'>('radar');
  const [filterStudentStatus, setFilterStudentStatus] = useState<'all' | 'needsAttention' | 'notFilled'>('all');
  const [selectedStudentForReport, setSelectedStudentForReport] = useState<string | null>(null);
  const [classData, setClassData] = useState<ClassAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchStudent, setSearchStudent] = useState('');

  const loadClassAnalytics = async () => {
    try {
      setLoading(true);
      const data = await api.getClassAnalytics(teacher.class_name);
      setClassData(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadClassAnalytics();
  }, [teacher.class_name]);

  const studentsInClass = classData?.students || [];

  const filteredStudents = studentsInClass.filter((st) => {
    const matchesSearch =
      st.name.toLowerCase().includes(searchStudent.toLowerCase()) ||
      st.nisn.includes(searchStudent);

    if (filterStudentStatus === 'needsAttention') {
      return matchesSearch && ((st.avg_score || 0) < 75 && (st.total_entries || 0) > 0);
    }
    if (filterStudentStatus === 'notFilled') {
      return matchesSearch && (!st.today_entries || st.today_entries === 0);
    }
    return matchesSearch;
  });

  return (
    <div className="min-h-screen bg-kebaya-pattern flex flex-col pb-12">
      {/* Teacher Top Navigation */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 sm:px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#19ae5d] to-[#1c5ddc] text-white flex items-center justify-center font-black text-sm shadow-sm">
            28
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-sm sm:text-base text-slate-900 tracking-tight">
                VERTIKAL SMA JAWARA 28
              </span>
              <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                Instrumen Guru
              </span>
            </div>
            <span className="text-[11px] text-slate-500">
              SMAN 28 Jakarta • Pendampingan Karakter 7 KAIH
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <span className="text-xs font-bold text-slate-900 block">{teacher.name}</span>
            <span className="text-[10px] text-slate-500">
              {teacher.subject} • NIP {teacher.nip}
            </span>
          </div>
          <button
            type="button"
            onClick={onLogout}
            className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors cursor-pointer"
          >
            Keluar
          </button>
        </div>
      </header>

      {/* Main Container */}
      <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6 flex-1">
        {/* Profile Card & KPI Header */}
        <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-sm relative overflow-hidden">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-[#19ae5d] text-white flex items-center justify-center font-black text-2xl shadow-md ring-4 ring-emerald-50">
                {teacher.name.charAt(4) || 'G'}
              </div>
              <div>
                <h2 className="text-lg sm:text-xl font-extrabold text-slate-900">{teacher.name}</h2>
                <p className="text-xs text-slate-500 font-medium">
                  NIP: {teacher.nip} • Wali Kelas <strong>{teacher.class_name}</strong>
                </p>
                <span className="text-[11px] text-emerald-700 font-semibold bg-emerald-50 px-2.5 py-0.5 rounded-full inline-block mt-1">
                  {teacher.role}
                </span>
              </div>
            </div>

            {/* View Switcher: Beranda Kelas vs Papan Peringkat */}
            <div className="flex bg-slate-100 p-1 rounded-xl">
              <button
                type="button"
                onClick={() => setActiveTab('beranda')}
                className={`px-4 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  activeTab === 'beranda'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Analitik &amp; Murid Kelas
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('leaderboard')}
                className={`px-4 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  activeTab === 'leaderboard'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Papan Peringkat
              </button>
            </div>
          </div>

          {/* 3 KPI Cards: Siswa berpartisipasi, Rata-rata skor, Rata-rata respon terverifikasi */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 bg-blue-50/70 border border-blue-100 rounded-2xl">
              <span className="text-xs font-bold text-slate-600 block">Siswa Berpartisipasi</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-3xl font-black text-[#1c5ddc]">
                  {classData?.participatingCount || 0}
                </span>
                <span className="text-xs font-bold text-slate-500">
                  / {classData?.studentCount || 0} siswa
                </span>
              </div>
              <span className="text-[11px] text-blue-700 font-medium block mt-1">
                {classData?.studentCount
                  ? Math.round(((classData.participatingCount || 0) / classData.studentCount) * 100)
                  : 0}
                % keaktifan kelas {teacher.class_name}
              </span>
            </div>

            <div className="p-4 bg-emerald-50/70 border border-emerald-100 rounded-2xl">
              <span className="text-xs font-bold text-slate-600 block">Rata-Rata Skor Kelas</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-3xl font-black text-[#19ae5d]">
                  {classData?.classAverage ? classData.classAverage.toFixed(1) : '0'}
                </span>
                <span className="text-xs font-bold text-slate-500">/ 100 pt</span>
              </div>
              <span className="text-[11px] text-emerald-700 font-medium block mt-1">
                Indeks Pembiasaan 7 KAIH
              </span>
            </div>

            <div className="p-4 bg-amber-50/70 border border-amber-100 rounded-2xl">
              <span className="text-xs font-bold text-slate-600 block">Respon Terverifikasi</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-3xl font-black text-amber-900">
                  {studentsInClass.filter((s) => s.verification_score).length}
                </span>
                <span className="text-xs font-bold text-slate-500">siswa</span>
              </div>
              <span className="text-[11px] text-amber-700 font-medium block mt-1">
                Sudah dicek kebenaran observasi
              </span>
            </div>
          </div>
        </div>

        {/* TAB 1: BERANDA KELAS */}
        {activeTab === 'beranda' && (
          <div className="space-y-6">
            {/* Analitik Kelas: Radar/Progress Switch + Distribusi Batang + Gauge */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Capaian 7 KAIH (Toggle Radar / Progress Bar) */}
              <div className="lg:col-span-5 bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col justify-between">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-sm sm:text-base">
                      Capaian 7 KAIH Kelas {teacher.class_name}
                    </h3>
                    <p className="text-xs text-slate-500">Rerata tiap pilar karakter</p>
                  </div>

                  {/* Toggle Radar / Progress Bar */}
                  <div className="flex bg-slate-100 p-0.5 rounded-lg text-xs">
                    <button
                      type="button"
                      onClick={() => setChartMode('radar')}
                      className={`px-2.5 py-1 rounded font-bold cursor-pointer transition-all ${
                        chartMode === 'radar'
                          ? 'bg-white text-[#1c5ddc] shadow-xs'
                          : 'text-slate-600'
                      }`}
                    >
                      Radar
                    </button>
                    <button
                      type="button"
                      onClick={() => setChartMode('progress')}
                      className={`px-2.5 py-1 rounded font-bold cursor-pointer transition-all ${
                        chartMode === 'progress'
                          ? 'bg-white text-[#1c5ddc] shadow-xs'
                          : 'text-slate-600'
                      }`}
                    >
                      Bar
                    </button>
                  </div>
                </div>

                {chartMode === 'radar' ? (
                  <RadarChart
                    data={(classData?.classRadar || []).map((r) => ({
                      habit: r.habit,
                      label: r.label,
                      score: r.avg_score,
                    }))}
                    size={270}
                  />
                ) : (
                  <div className="space-y-2.5 my-2">
                    {(classData?.classRadar || []).map((r) => (
                      <div key={r.habit} className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="font-bold text-slate-700">{r.label}</span>
                          <span className="font-black text-[#1c5ddc]">{r.avg_score} pt</span>
                        </div>
                        <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-[#1c5ddc] to-[#19ae5d] rounded-full transition-all duration-500"
                            style={{ width: `${Math.min(100, Math.max(0, r.avg_score))}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <div className="text-[11px] text-slate-400 text-center mt-2">
                  Dihitung real-time dari data entri SQL murid {teacher.class_name}
                </div>
              </div>

              {/* Gauge Rata-rata Skor Kelas */}
              <div className="lg:col-span-3 bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col justify-center items-center">
                <h3 className="font-extrabold text-slate-900 text-sm mb-2 text-center">
                  Gauge Rata-Rata Kelas
                </h3>
                <GaugeChart score={classData?.classAverage || 0} title={teacher.class_name} size={230} />
              </div>

              {/* Distribusi Skor Kelas Diagram Batang */}
              <div className="lg:col-span-4 bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col justify-between">
                <div>
                  <h3 className="font-extrabold text-slate-900 text-sm sm:text-base mb-1">
                    Distribusi Skor Kelas
                  </h3>
                  <p className="text-xs text-slate-500 mb-4">
                    Kategori rentang skor murid
                  </p>
                </div>

                {classData?.distribution && (
                  <ScoreDistributionBar distribution={classData.distribution} />
                )}

                <div className="text-[11px] text-slate-400 text-right mt-2">
                  Total {classData?.studentCount || 0} Siswa Terdaftar
                </div>
              </div>
            </div>

            {/* Daftar Murid di Kelasnya (Bisa buka rapor individual, kelihatan yang nilainya kurang/belum isi) */}
            <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="font-extrabold text-slate-900 text-base">
                    Daftar Murid Kelas {teacher.class_name}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Buka rapor individual untuk memberikan evaluasi & rekomendasi walas
                  </p>
                </div>

                {/* Filter Status: Semua, Nilai Kurang (<75), Belum Isi */}
                <div className="flex flex-wrap items-center gap-2">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={searchStudent}
                      onChange={(e) => setSearchStudent(e.target.value)}
                      placeholder="Cari murid..."
                      className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:ring-1 focus:ring-[#19ae5d]"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={() => setFilterStudentStatus('all')}
                    className={`px-3 py-1.5 text-xs font-bold rounded-lg cursor-pointer ${
                      filterStudentStatus === 'all'
                        ? 'bg-slate-800 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    Semua ({studentsInClass.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setFilterStudentStatus('needsAttention')}
                    className={`px-3 py-1.5 text-xs font-bold rounded-lg cursor-pointer flex items-center gap-1 ${
                      filterStudentStatus === 'needsAttention'
                        ? 'bg-amber-600 text-white'
                        : 'bg-amber-50 text-amber-800 hover:bg-amber-100'
                    }`}
                  >
                    <AlertTriangle className="w-3 h-3" /> Nilai &lt; 75
                  </button>
                  <button
                    type="button"
                    onClick={() => setFilterStudentStatus('notFilled')}
                    className={`px-3 py-1.5 text-xs font-bold rounded-lg cursor-pointer ${
                      filterStudentStatus === 'notFilled'
                        ? 'bg-rose-600 text-white'
                        : 'bg-rose-50 text-rose-800 hover:bg-rose-100'
                    }`}
                  >
                    Belum Isi Hari Ini
                  </button>
                </div>
              </div>

              {/* Table of Students in Teacher's Class */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">Nama Siswa</th>
                      <th className="py-3 px-4">NISN</th>
                      <th className="py-3 px-4 text-center">Status Hari Ini</th>
                      <th className="py-3 px-4 text-center">Total Entri</th>
                      <th className="py-3 px-4 text-right">Rata-Rata Skor</th>
                      <th className="py-3 px-4 text-center">Catatan Walas</th>
                      <th className="py-3 px-4 text-center">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredStudents.map((st) => {
                      const hasFilledToday = (st.today_entries || 0) > 0;
                      const isLowScore = (st.avg_score || 0) < 75 && (st.total_entries || 0) > 0;

                      return (
                        <tr key={st.id} className="hover:bg-slate-50 transition-colors">
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-2.5">
                              <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-xs">
                                {st.name.charAt(0)}
                              </div>
                              <div>
                                <span className="font-bold text-slate-900 block">{st.name}</span>
                                <span className="text-[10px] text-slate-400">{st.religion} • {st.gender === 'L' ? 'Laki-laki' : 'Perempuan'}</span>
                              </div>
                            </div>
                          </td>
                          <td className="py-3 px-4 font-mono text-slate-600">{st.nisn}</td>
                          <td className="py-3 px-4 text-center">
                            {hasFilledToday ? (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-green-700 bg-green-50 border border-green-200 px-2 py-0.5 rounded-full">
                                <CheckCircle2 className="w-3 h-3" /> {st.today_entries} Entri
                              </span>
                            ) : (
                              <span className="text-[10px] font-semibold text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded-full">
                                Belum Isi
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-4 text-center font-semibold text-slate-700">
                            {st.total_entries || 0}
                          </td>
                          <td className="py-3 px-4 text-right">
                            <span
                              className={`font-black text-sm ${
                                isLowScore
                                  ? 'text-rose-600'
                                  : (st.avg_score || 0) >= 90
                                  ? 'text-emerald-600'
                                  : 'text-[#1c5ddc]'
                              }`}
                            >
                              {st.avg_score ? st.avg_score.toFixed(1) : '0'}
                            </span>
                            <span className="text-[10px] text-slate-400 ml-0.5">pt</span>
                          </td>
                          <td className="py-3 px-4 text-center">
                            {st.walas_notes ? (
                              <span className="text-emerald-700 text-[11px] font-medium" title={st.walas_notes}>
                                Ada Catatan
                              </span>
                            ) : (
                              <span className="text-slate-400 text-[10px]">Belum Ada</span>
                            )}
                          </td>
                          <td className="py-3 px-4 text-center">
                            <button
                              type="button"
                              onClick={() => setSelectedStudentForReport(st.id)}
                              className="btn-interactive px-3 py-1.5 bg-[#19ae5d] hover:bg-emerald-700 text-white font-bold rounded-lg text-xs cursor-pointer shadow-xs"
                            >
                              Buka Rapor
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: PAPAN PERINGKAT KELAS & SEKOLAH */}
        {activeTab === 'leaderboard' && (
          <div className="space-y-4">
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-amber-900 block">
                  Peringkat Keseluruhan Siswa SMAN 28 Jakarta
                </span>
                <span className="text-xs text-amber-700">
                  Murid kelas binaan Anda ({teacher.class_name}) otomatis di-highlight dengan label kuning/oranye.
                </span>
              </div>
            </div>
            <LeaderboardTable
              students={allStudents}
              highlightClass={teacher.class_name}
              onSelectStudent={(s) => setSelectedStudentForReport(s.id)}
            />
          </div>
        )}
      </div>

      {/* Rapor Individual Modal with Teacher Edit capability */}
      {selectedStudentForReport && (
        <StudentReportModal
          studentId={selectedStudentForReport}
          canEditNotes={true}
          onClose={() => {
            setSelectedStudentForReport(null);
            loadClassAnalytics();
          }}
        />
      )}
    </div>
  );
};
