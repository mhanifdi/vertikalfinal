/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * ============================================================================
 * DIRECTORY ATURAN & FORMULASI PENILAIAN 7 KAIH SMAN 28 JAKARTA (SKEMA TERBARU)
 * Lokasi File: /src/config/scoringConfig.ts
 * ============================================================================
 */

export const PRAYER_SCHEDULE = {
  subuh: {
    name: 'Subuh',
    adzanTime: '04:00',
    nextPrayerTime: '05:30', // Total interval = 90 menit
    totalMinutes: 90,
  },
  zuhur: {
    name: 'Zuhur',
    adzanTime: '11:40',
    nextPrayerTime: '14:55', // Total interval = 195 menit
    totalMinutes: 195,
  },
  asar: {
    name: 'Asar',
    adzanTime: '14:55',
    nextPrayerTime: '17:50', // Total interval = 175 menit
    totalMinutes: 175,
  },
  magrib: {
    name: 'Magrib',
    adzanTime: '17:50',
    nextPrayerTime: '19:05', // Total interval = 75 menit
    totalMinutes: 75,
  },
  isya: {
    name: 'Isya',
    adzanTime: '19:05',
    nextPrayerTime: '04:00', // Total interval = 535 menit
    totalMinutes: 535,
  },
};

export const SCORING_RULES = {
  // 1. Shalat Islam
  // (T total = Waktu Adzan - Waktu Shalat Berikutnya - 15 menit)
  // Poin = (Tsisa / Ttotal) * 100, Cap terendah 50, Tidak isi = 0
  // Mengaji/Murajaah: Additional Poin +1 / halaman
  shalat: {
    toleranceDeductionMinutes: 15,
    minCapScore: 50,
    maxScore: 100,
    quranPageBonus: 1.0, // +1 per halaman
    missedPenalty: 5, // -5 jika isi terlewat
  },

  // 2. Bangun Pagi:
  // 04.00 - 04.20 = 100
  // 04.21 - 04.40 = 90
  // 04.41 - 05.00 = 80
  // 05.01 - 06.20 = 70
  // 06.21 - 06.40 = 60
  // > 06.40 = 50
  bangunPagi: {
    brackets: [
      { id: '04.00-04.20', label: '04.00 – 04.20 WIB', minMin: 240, maxMin: 260, score: 100 },
      { id: '04.21-04.40', label: '04.21 – 04.40 WIB', minMin: 261, maxMin: 280, score: 90 },
      { id: '04.41-05.00', label: '04.41 – 05.00 WIB', minMin: 281, maxMin: 300, score: 80 },
      { id: '05.01-06.20', label: '05.01 – 06.20 WIB', minMin: 301, maxMin: 380, score: 70 },
      { id: '06.21-06.40', label: '06.21 – 06.40 WIB', minMin: 381, maxMin: 400, score: 60 },
      { id: '>06.40', label: '> 06.40 WIB', minMin: 401, maxMin: 1440, score: 50 },
    ],
    missedPenalty: 5,
  },

  // 3. Makan Bergizi
  // Waktu:
  // Sarapan pagi: 06.00 - 08.00 = 15 (jika > 08.00 = 5)
  // Makan siang: 11.30 - 13.00 = 15 (jika > 13.00 = 5)
  // Makan malam: 18.00 - 19.30 = 15 (jika > 19.30 = 5)
  // Isi piringku (Max 40): Karbo 10, Lauk 10, Sayur 10, Buah 10
  // Air minum: >=2 gelas (15), 1 gelas (5), 0 gelas/manis (0)
  // Eco-Friendly: Kotak makan (+5), Tumbler (+5)
  makan: {
    sarapan: { onTimeMin: 360, onTimeMax: 480, onTimeScore: 15, lateScore: 5 },
    siang: { onTimeMin: 690, onTimeMax: 780, onTimeScore: 15, lateScore: 5 },
    malam: { onTimeMin: 1080, onTimeMax: 1170, onTimeScore: 15, lateScore: 5 },
    karbo: 10,
    lauk: 10,
    sayur: 10,
    buah: 10,
    air2Gelas: 15,
    air1Gelas: 5,
    air0Gelas: 0,
    kotakMakanEco: 5,
    tumblerEco: 5,
    missedPenalty: 5,
  },

  // 4. Berolahraga
  // Aktivitas (Checkbox):
  // Mandiri: 10
  // Kelompok/ekskul: 10
  // Jalan kaki/tangga: 10
  // Pemanasan ringan: 10
  // Bersepeda/jalan kaki ke sekolah: +10
  // Durasi: <15 (25), 15-30 (35), 31-60 (45), >60 (60)
  olahraga: {
    actMandiri: 10,
    actKelompok: 10,
    actJalanTangga: 10,
    actStretching: 10,
    actKeSekolahEco: 10,
    durLess15: 25,
    dur15to30: 35,
    dur31to60: 45,
    durOver60: 60,
    missedPenalty: 5,
  },

  // 5. Gemar Belajar
  // Durasi (Max 60): >3h (60), 2-3h (50), 1-2h (40), 30-60m (30), 15-30m (20), <15m (10), 0m (0)
  // Bentuk kegiatan (Max 30): 3 kegiatan (30), 2 kegiatan (20), 1 kegiatan (10), 0 (0)
  // Output (Max 10): >= 10 char (10), < 10 char (5), kosong (0)
  belajar: {
    durOver3h: 60,
    dur2to3h: 50,
    dur1to2h: 40,
    dur30to60m: 30,
    dur15to30m: 20,
    durLess15m: 10,
    dur0m: 0,
    act3OrMore: 30,
    act2: 20,
    act1: 10,
    act0: 0,
    descDetailed: 10,
    descShort: 5,
    descEmpty: 0,
    missedPenalty: 5,
  },

  // 6. Bermasyarakat
  // Aksi (Max 90): >=4 aksi (90), 3 aksi (80), 2 aksi (70), 1 aksi (60), 0 (0)
  // Piket / kebersihan lingkungan: additional +5
  // Deskripsi (Max 10): >=10 char (10), <10 char (5), kosong (0)
  masyarakat: {
    act4OrMore: 90,
    act3: 80,
    act2: 70,
    act1: 60,
    act0: 0,
    piketEcoBonus: 5,
    descDetailed: 10,
    descShort: 5,
    descEmpty: 0,
    missedPenalty: 5,
  },

  // 7. Tidur Cepat
  // Waktu (Max 75): <21.30 (75), 21.30-22.30 (65), 22.31-23.30 (55), >23.30 (45)
  // Eco-Friendly: Matikan lampu (+5)
  // Kualitas tidur (Max 25): 5 (25), 4 (20), 3 (15), 2 (10), 1 (5)
  tidur: {
    before2130: 75,
    between2130_2230: 65,
    between2231_2330: 55,
    after2330: 45,
    matikanLampuEco: 5,
    quality5: 25,
    quality4: 20,
    quality3: 15,
    quality2: 10,
    quality1: 5,
    missedPenalty: 5,
  },
};
