/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * ============================================================================
 * DIRECTORY KONFIGURASI AKUN LOGIN (VERTIKAL SMA JAWARA 28)
 * Lokasi File: /src/config/accounts.ts
 * ============================================================================
 * Hanya ada 1 akun demo per role sesuai instruksi user:
 * - Siswa: username "siswa", password "123"
 * - Guru: username "guru", password "123"
 * - Admin: username "admin", password "123"
 */

export interface UserAccountConfig {
  id: string;
  username: string; // Bisa berupa NISN / NIP / Username yang diketik saat login
  password: string; // Kata sandi untuk login
  name: string;
  role: 'siswa' | 'guru' | 'admin';
  class_name: string;
  angkatan?: string;
  religion?: 'Islam' | 'Kristen' | 'Katolik' | 'Hindu';
  gender?: 'L' | 'P';
  walas_name?: string;
  walas_nip?: string;
}

export const USER_ACCOUNTS: UserAccountConfig[] = [
  {
    id: 'std-siswa',
    username: 'siswa',
    password: '123',
    name: 'Siswa Jawara 28 (Default)',
    role: 'siswa',
    class_name: 'XI-MIPA-1',
    angkatan: '2025/2026',
    religion: 'Islam',
    gender: 'L',
    walas_name: 'Dra. Hj. Nurhidayah, M.Pd.',
    walas_nip: '197405101999032001',
  },
  {
    id: 'std-siswai',
    username: 'siswai',
    password: '123',
    name: 'Siti Rahmawati (Islam)',
    role: 'siswa',
    class_name: 'XI-MIPA-1',
    angkatan: '2025/2026',
    religion: 'Islam',
    gender: 'P',
    walas_name: 'Dra. Hj. Nurhidayah, M.Pd.',
    walas_nip: '197405101999032001',
  },
  {
    id: 'std-siswak',
    username: 'siswak',
    password: '123',
    name: 'Daniel Pratama (Kristen)',
    role: 'siswa',
    class_name: 'XI-MIPA-1',
    angkatan: '2025/2026',
    religion: 'Kristen',
    gender: 'L',
    walas_name: 'Dra. Hj. Nurhidayah, M.Pd.',
    walas_nip: '197405101999032001',
  },
  {
    id: 'std-siswah',
    username: 'siswah',
    password: '123',
    name: 'I Wayan Aditya (Hindu)',
    role: 'siswa',
    class_name: 'XI-MIPA-1',
    angkatan: '2025/2026',
    religion: 'Hindu',
    gender: 'L',
    walas_name: 'Dra. Hj. Nurhidayah, M.Pd.',
    walas_nip: '197405101999032001',
  },
  {
    id: 'tch-guru',
    username: 'guru',
    password: '123',
    name: 'Dra. Hj. Nurhidayah, M.Pd.',
    role: 'guru',
    class_name: 'XI-MIPA-1',
    walas_nip: '197405101999032001',
  },
  {
    id: 'adm-admin',
    username: 'admin',
    password: '123',
    name: 'Drs. H. Ubaidillah, M.M.',
    role: 'admin',
    class_name: 'Semua Kelas',
    walas_nip: '196904121995031004',
  },
];
